# IoT Battery Analytics Platform

## Problem Statement and Business Context

Jio Energenie manages **100K+ IoT battery devices** (stationary batteries at telecom towers, smart batteries in vehicles) from multiple OEMs (BMS, NMT, Coslight, Rethium, Zabbix). Each OEM sends telemetry in a different payload format via a REST API.

**Business Need:**
- Compute daily battery health KPIs: C-rate, State-of-Charge patterns, voltage anomalies, temperature breaches
- Generate operational feeds (safety alerts for overcharging, voltage breaches, temperature anomalies)
- Normalize heterogeneous OEM payloads into a unified analytics schema
- Migrate from single-node Python processing to distributed Spark for scalability
- Orchestrate the multi-stage pipeline (ingest → normalize → aggregate → feed) automatically

**Before:** Single-node Python scripts processed one OEM at a time, taking 6+ hours for the full fleet. Manual execution, no fault tolerance.

**After:** Distributed PySpark with `applyInPandas` for per-device analytics, Marshmallow for schema validation, Airflow for orchestration. Full fleet processed in ~3.5 hours with automated retry.

---

## Architecture

```mermaid
flowchart TD
    subgraph sources [Data Sources]
        API["Energenie REST API\n(MongoDB-backed)"]
        Hadoop["HDFS / Hive\n(battery_readings table)"]
    end

    subgraph ingestion [Ingestion Layer]
        Deserialize["Marshmallow Schema\nDeserialization"]
        Preprocess["Preprocessing\n(OEM normalization)"]
    end

    subgraph processing [Spark Processing]
        SparkETL["Spark ETL\n(bms_spark_etl.py)"]
        ApplyPandas["applyInPandas\n(Per-device KPI computation)"]
        Aggregation["Daily Aggregation\n(Metrics engine)"]
    end

    subgraph feeds [Output Feeds]
        Safety["Safety Feed\n(overcharge/voltage/temp alerts)"]
        Operational["Operational Feed\n(daily health summary)"]
        Warranty["Warranty Feed\n(cycle count, SoH degradation)"]
    end

    subgraph orchestration [Orchestration]
        Airflow["Apache Airflow\n(Docker deployment)"]
        DAG["battery_analytics_dag"]
    end

    API --> Deserialize
    Hadoop --> Preprocess
    Deserialize --> SparkETL
    Preprocess --> SparkETL
    SparkETL --> ApplyPandas
    ApplyPandas --> Aggregation
    Aggregation --> Safety
    Aggregation --> Operational
    Aggregation --> Warranty
    Airflow --> DAG
    DAG --> SparkETL
```

---

## Tech Stack and Why Each Was Chosen

| Technology | Role | Why |
|---|---|---|
| **PySpark** | Distributed processing | 100K+ devices × 30 days = 50+ GB telemetry; single-node infeasible |
| **applyInPandas** | Per-device analytics | Complex KPI logic (C-rate, rolling windows) easier in Pandas per group |
| **Marshmallow** | Schema validation | Multiple OEM formats normalized via declarative schemas with `@pre_load` hooks |
| **Apache Airflow** | Orchestration | Multi-stage DAG with retries, scheduling, Docker deployment |
| **Docker Compose** | Deployment | Reproducible Airflow environment with webserver, scheduler, PostgreSQL |
| **MongoDB** | Raw data source | Energenie platform stores device readings in MongoDB |
| **HDFS / Hive** | Data lake | Historical data stored as Parquet in Hive warehouse |
| **PyArrow** | Parquet I/O | High-performance Parquet read/write in non-Spark components |

---

## Data Flow (End-to-End)

### Stage 1: Data Ingestion

**From REST API (bms_spark_etl.py):**
1. Query Energenie API with date range and device IDs
2. Receive JSON responses with nested battery telemetry
3. Deserialize using OEM-specific Marshmallow schema
4. Write normalized records to PySpark DataFrame

**From HDFS/Hive (fetching_hadoop.py):**
1. Read Parquet from `hdfs://*/smart_battery.db/battery_readings/eid={eid}/year={}/month={}/day={}`
2. Transform nested columns (cell_voltages_mv, cell_temperatures) using UDFs
3. Handle Zabbix-specific module explosion (multi-module batteries)

### Stage 2: Schema-Agnostic Normalization

Marshmallow schemas handle heterogeneous OEM payloads:
- `StationarySchema` — BMS standard format
- `CombinedStationarySchema` — Legacy + new field names with `@pre_load` mapping
- `RethiumSchema` — Rethium-specific fields
- `NMTSchema` — NMT-specific fields
- `CoslightSchema` — Coslight-specific fields
- `BmsSchema` — Generic BMS format

Each schema normalizes vendor-specific field names to a unified column set.

### Stage 3: Distributed Analytics

Using `applyInPandas` grouped by device:
1. **Per-device KPI computation:** C-rate, voltage trends, temperature anomalies
2. **Rolling window analysis:** SoC patterns, charge/discharge cycles
3. **Anomaly detection:** Overcharge, under-voltage, temperature breach thresholds

### Stage 4: Feed Generation

Three output feeds written daily:
- **Safety Feed:** Devices exceeding safety thresholds (immediate action)
- **Operational Feed:** Daily health summary per device
- **Warranty Feed:** Cycle count, SoH degradation trends

### Stage 5: Airflow Orchestration

DAG runs daily with tasks:
1. `ingest_data` → Pull from API/HDFS
2. `normalize_schemas` → Marshmallow validation
3. `spark_aggregation` → KPI computation
4. `generate_feeds` → Safety/Operational/Warranty outputs

---

## Key Code Snippets with Explanations

### Marshmallow Schema — OEM Normalization

```python
class CombinedStationarySchema(Schema):
    uid = fields.String(data_key="meterId")
    eid = fields.String(data_key="eid")
    event_time = fields.DateTime(format="timestamp_ms", data_key="time")
    pack_voltage = fields.Float(allow_none=True)
    soc = fields.Int(data_key="soc")
    soh = fields.Int(allow_none=True)
    battery_status = fields.String(allow_none=True)
    cell_voltages_mv = fields.Dict(keys=fields.String(), values=fields.Integer())
    
    class Meta:
        unknown = EXCLUDE  # Ignore unknown fields from different OEMs

    @pre_load
    def preprocess_data(self, data, **kwargs):
        # Handle multiple possible field names across OEM versions
        if data.get("pack_voltage", data.get("voltage")):
            data["pack_voltage"] = data.get("pack_voltage", data.get("voltage"))
        if data.get("soH", data.get("soh")):
            data["soh"] = data.get("soH", data.get("soh"))
        if data.get("status", data.get("battery_status")):
            data["battery_status"] = data.get("status", data.get("battery_status"))
        if data.get("cumulative_charging_time", data.get("moduleCumulativeChargingTime")):
            data["module_cumulative_charging_time"] = data.get(
                "cumulative_charging_time", data.get("moduleCumulativeChargingTime")
            )
        return data
```

**Why Marshmallow:**
- **Declarative:** Schema defines the contract; validation is automatic
- **`@pre_load` hooks:** Handles field name evolution across OEM firmware versions without code duplication
- **`EXCLUDE` unknown:** New fields from OEMs don't break the pipeline
- **Type coercion:** `timestamp_ms` format handles epoch-millisecond timestamps

### Zabbix Preprocessing (Multi-Module Batteries)

```python
def zabbix_preprocess(df):
    # Explode pack_readings map into individual module rows
    exploded_pack_df = df.select(
        col("sapid"), col("event_time"),
        col("smps_bms_readings.active_modules").alias("active_modules"),
        explode("pack_readings").alias("slaveId", "pack_reading"),
    )
    
    # Extract per-module metrics
    opened_spark_df = exploded_pack_df.select(
        col("pack_reading.charging_current").alias("charging_current"),
        col("pack_reading.discharging_current").alias("discharging_current"),
        col("pack_reading.soc").alias("soc"),
        col("pack_reading.voltage").alias("voltage"),
    )
    
    # Derive battery status from current direction
    opened_spark_df = opened_spark_df.withColumn("battery_status",
        when(col("current") > 0.0, "Charging")
        .when(col("current") < 0.0, "Discharging")
        .when(col("current") == 0.0, "Stand by")
    )
    
    # Drop inactive modules (beyond active_modules count)
    num_active_modules = int(opened_spark_df.select(
        functions.first("active_modules", ignorenulls=True)
    ).first()[0])
    module_to_remove = num_active_modules + 1
    while module_to_remove <= modules_present_columns_count:
        opened_spark_df = opened_spark_df.filter(col('slaveId') != 'mod' + str(module_to_remove))
        module_to_remove += 1
```

**Key insight:** Zabbix batteries have multiple modules (mod1-mod10), but only some are active. The pipeline explodes the module map, filters to active modules only, and treats each module as a virtual device (uid = sapid + "_" + slaveId).

### HDFS Data Fetch with Schema Handling

```python
def get_one_day_data(spark, eid, date):
    def transform_coloumn(df, eid):
        def parse_map_string(map_string):
            if map_string is None or map_string == "":
                return None
            return ast.literal_eval(map_string)  # Convert string repr to dict

        if eid == 'bms':
            # BMS stores cell voltages as string-encoded dicts in Hive
            nested_1D_int_udf = functions.udf(
                parse_map_string, MapType(StringType(), IntegerType())
            )
            for nested_col in ['cell_voltages_mv', 'cell_temperatures_celsius']:
                df = df.withColumn(nested_col, nested_1D_int_udf(df[nested_col]))
        return df

    spark_df = spark.read.parquet(
        f"hdfs://{HADOOP_URI}:8020/user/hive/warehouse/smart_battery.db/"
        f"battery_readings/eid={eid}/year={date.year}/month={date.month}/day={date.day}"
    )
    spark_df = transform_coloumn(spark_df, eid)
    return spark_df
```

**Why UDF for nested columns:** Hive stores complex types (MapType) as string representations in some partitions. The UDF parses these back into proper Spark MapType for downstream analytics.

### REST API Client

```python
class EnergenieProdApi:
    def __init__(self, base_url, token):
        self.base_url = base_url
        self.headers = {"Authorization": f"Bearer {token}"}
    
    def get_device_readings(self, device_ids, start_date, end_date):
        payload = {
            "deviceIds": device_ids,
            "startTime": start_date.isoformat(),
            "endTime": end_date.isoformat(),
        }
        response = requests.post(
            f"{self.base_url}/api/v1/readings/batch",
            json=payload, headers=self.headers, timeout=30
        )
        response.raise_for_status()
        return response.json()
```

### Airflow DAG Structure

```python
from airflow import DAG
from airflow.operators.bash import BashOperator
from datetime import datetime, timedelta

default_args = {
    'owner': 'data_engineering',
    'retries': 2,
    'retry_delay': timedelta(minutes=5),
    'depends_on_past': False,
}

with DAG(
    'battery_analytics_daily',
    default_args=default_args,
    schedule_interval='0 3 * * *',  # Daily at 3 AM
    start_date=datetime(2024, 1, 1),
    catchup=False,
) as dag:
    
    ingest = BashOperator(
        task_id='ingest_data',
        bash_command='python /app/src/core/data_collector.py {{ ds }}',
    )
    
    aggregate = BashOperator(
        task_id='spark_aggregation',
        bash_command='spark-submit /app/src/aggregations/daily_aggregation_metrics.py {{ ds }}',
    )
    
    generate_feeds = BashOperator(
        task_id='generate_feeds',
        bash_command='python /app/src/feeds/feed_generation_interface.py {{ ds }}',
    )
    
    ingest >> aggregate >> generate_feeds
```

---

## The Python-to-Spark Migration Story

### Before (Single-node Python)
- Pandas DataFrames loaded entire OEM dataset into memory
- Sequential processing: one device at a time
- 6+ hours for 100K devices
- OOM failures on large OEMs
- No fault tolerance; manual restart required

### After (Distributed Spark)
- `spark.read.parquet()` with partition pruning
- `applyInPandas` for per-device grouped computation
- ~3.5 hours for full fleet (40% reduction)
- Dynamic allocation handles varying OEM sizes
- Airflow retries on transient failures

### Migration Approach
1. Kept Pandas KPI logic intact (domain experts validated it)
2. Wrapped in `applyInPandas` for distributed execution per device group
3. Moved I/O to Spark (Parquet reads, Cassandra writes)
4. Schema validation remained Marshmallow (runs in driver for API ingestion)

---

## Scale, Performance, and Optimization

| Metric | Value |
|---|---|
| Devices | 100K+ across 5 OEMs |
| Daily telemetry volume | 50+ GB |
| Processing time (before) | 6+ hours |
| Processing time (after) | ~3.5 hours (40% reduction) |
| OEM schemas supported | 6 (Stationary, Combined, Rethium, NMT, Coslight, BMS) |
| Output feeds | 3 (Safety, Operational, Warranty) |
| Airflow retries | 2 per task with 5-min delay |

---

## Design Decisions and Trade-offs

| Decision | Reasoning | Trade-off |
|---|---|---|
| `applyInPandas` over pure Spark | Complex per-device logic (rolling windows, C-rate) easier in Pandas | Data must fit in memory per group; solved by per-device grouping |
| Marshmallow for validation | Declarative, testable, handles OEM evolution | Runs in Python driver; not distributed (acceptable for API ingestion) |
| Docker-based Airflow | Reproducible deployment, easy scaling | Overhead of container management |
| Per-OEM schema classes | Clear separation; each OEM maintainable independently | More code files; but eliminates fragile if/else chains |
| Hive-partitioned storage | Enables partition pruning (eid, year, month, day) | Requires strict naming convention in writers |

---

## Interview Talking Points (2-minute explanation)

> "I migrated the IoT Battery Analytics platform from single-node Python to distributed Spark, processing telemetry from 100K+ devices across 5 OEMs. The key challenge was handling heterogeneous payload formats — each OEM sends different field names for the same metric.
>
> I solved this with Marshmallow schemas that use `@pre_load` hooks to normalize vendor-specific field names into a unified schema. This eliminated vendor-specific code paths and reduced new OEM onboarding from days to hours.
>
> For distributed KPI computation, I used `applyInPandas` grouped by device — this preserved existing Pandas analytics logic while distributing across the cluster. The migration achieved a 40% runtime reduction.
>
> The pipeline is orchestrated by Airflow running in Docker, with a daily DAG that handles ingestion, Spark aggregation, and feed generation with automatic retries."

---

## Common Follow-up Questions

1. **"Why `applyInPandas` instead of pure Spark UDFs?"** → The KPI logic involves rolling windows, conditional accumulations, and C-rate calculations that are much more readable/maintainable in Pandas. Since we group by device (each device has ~96-288 records/day), the per-group memory footprint is small.

2. **"How do you handle a new OEM onboarding?"** → Create a new Marshmallow schema class mapping their field names to our unified columns. Add the schema to the deserializer registry. No changes to downstream aggregation code.

3. **"What if Marshmallow validation fails?"** → `EXCLUDE` unknown fields means partial data is still processed. For critical missing fields (uid, event_time), the record is logged as failed and excluded from aggregation.

4. **"How does the Zabbix multi-module handling scale?"** → `explode()` on the pack_readings map creates separate rows per module. The `uid` becomes `sapid_moduleId`, so downstream processing treats each module as an independent device — no special-casing needed.

5. **"What's the Airflow failure recovery strategy?"** → 2 retries with 5-minute delay. If all retries fail, Airflow alerts. The pipeline is idempotent (overwrite mode), so manual re-runs don't create duplicates.

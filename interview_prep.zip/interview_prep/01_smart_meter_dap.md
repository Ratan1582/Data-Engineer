# Smart Meter Data Analytics Pipeline (DAP)

## Problem Statement and Business Context

Jio's smart metering division collects energy consumption data from **4M+ smart meters** deployed across India, spanning multiple vendors (MVVNL, PVVNL, DVC, IPCL, JioUrja, etc.). The raw data arrives on HDFS as Parquet files organized by vendor and profile type.

**Business Need:** Compute aggregated energy metrics (active/reactive energy import/export, max demand, voltage) at block (15/30 min), daily, and monthly granularity for:
- Billing reconciliation
- SLA compliance monitoring
- Energy analytics dashboards
- Regulatory reporting

**Before this pipeline:** Legacy Python/Pandas scripts processed data sequentially, taking hours for a single vendor and unable to scale to 4M+ meters.

**After this pipeline:** Distributed PySpark jobs on YARN process all vendors in parallel, completing daily aggregation in minutes with 3x throughput improvement.

---

## Architecture

```mermaid
flowchart TD
    subgraph ingestion [Data Landing Zone]
        HDFS_Raw["HDFS Parquet Files\n/SM/{Vendor}/{Profile}/{Date}"]
    end

    subgraph pipeline [PySpark Aggregation Pipeline]
        LRP["Last Read Path (LRP)\nTracking on HDFS"]
        Fetch["DataFetch\n(Incremental reads)"]
        Agg["Aggregate\n(Block/Daily/Monthly)"]
        Push["DataPush\n(Cassandra writes)"]
        Logs["Logging\n(HDFS log upload)"]
    end

    subgraph storage [Serving Layer]
        Cassandra["Apache Cassandra\n(dap_aggregation keyspace)"]
        HDFS_Processed["HDFS\n(Processed data + device lists)"]
    end

    subgraph scheduling [Orchestration]
        Cron["Cron + Shell Schedulers\n(daily_scheduler.sh)"]
        YARN["YARN Cluster\n(spark3-submit)"]
    end

    HDFS_Raw --> Fetch
    LRP --> Fetch
    Fetch --> Agg
    Agg --> Push
    Push --> Cassandra
    Agg --> HDFS_Processed
    Fetch --> LRP
    Logs --> HDFS_Processed
    Cron --> YARN
    YARN --> pipeline
```

---

## Tech Stack and Why Each Was Chosen

| Technology | Role | Why |
|---|---|---|
| **PySpark** | Distributed processing | 4M+ meters cannot be processed on single node; Spark parallelizes across YARN cluster |
| **HDFS** | Raw data storage + outputs | On-prem Hadoop cluster already hosts meter data; Parquet format for columnar efficiency |
| **Apache Cassandra** | Serving layer | Low-latency reads for dashboards; time-series optimized with partition keys (device + date) |
| **Parquet** | File format | Columnar, compressed, schema-embedded; supports predicate pushdown |
| **YARN** | Resource management | Cluster-mode deployment with dynamic allocation (2-6 executors) |
| **Shell/Cron** | Scheduling | Lightweight orchestration for production jobs; vendor-parallel execution |

---

## Data Flow (End-to-End)

### 1. Scheduling
Shell scripts (`daily_scheduler.sh`) run via cron at 3AM, 6AM, 9AM daily. Each invokes `spark3-submit` with:
- `--master yarn --deploy-mode cluster`
- 8GB driver/executor memory, 4 cores
- AQE enabled (`spark.sql.adaptive.enabled=true`)
- Dynamic allocation (2-6 executors)

### 2. Data Fetch (Incremental Ingestion)
The `SuperDataFetch.get_hdfs_data()` method:
1. Reads the **Last Read Path (LRP)** — a Parquet file tracking the latest processed file per vendor/date
2. Lists all Parquet files under `/SM/{Vendor}/{Profile}/{Date}/`
3. Filters to only **new files** (file path > last_read_path)
4. Returns a DataFrame with only unprocessed data
5. Updates the LRP tracking DataFrame

This reduces redundant reads by **60%** on re-runs.

### 3. Data Parsing and Pivot
Raw data has nested structure: `header.tenant`, `data[].mi` (meter ID), `data[].rv[]` (register values).

The pipeline:
1. Explodes nested arrays (`data`, `data.rv`)
2. Extracts IMEI, Vendor, Timestamp, Profile, Register, Value
3. Pivots register codes to columns (e.g., `1-0.1.8.0.255` → Active Energy Import)
4. Validates timestamps and casts types

### 4. Aggregation
Three aggregation types:

**Block (15/30 min intervals):**
- Groups by IMEI, Vendor, Date, Hour
- Sums energy values per hour
- Writes directly to Cassandra `dap_block` table

**Daily:**
- Fetches today + yesterday data
- Computes delta (today cumulative - yesterday cumulative)
- Filters negative values (meter resets)
- Handles both meter readings (type R) and consumption data (type C)
- Deduplicates using device list tracking

**Monthly (Billing):**
- Fetches billing profile data
- Prioritizes midnight readings; falls back to latest non-midnight
- Computes month-over-month delta from Cassandra cumulative table

### 5. Data Push
`DataPush.push_to_cassandra()`:
- Uses Spark Cassandra connector
- Repartitions by (device, date) for optimal write distribution
- Configures batch size (25 rows), concurrent writes (6), LOCAL_ONE consistency
- Appends to existing tables

### 6. Cleanup and Logging
- Logs uploaded to HDFS per date folder
- Old logs/data files deleted after 31 days
- LRP persisted back to HDFS with 180-second minimum processing time guard

---

## Key Code Snippets with Explanations

### Incremental Ingestion (LRP Tracking)

```python
def get_hdfs_data(self, last_read_path_df, formatted_date, logger, profile):
    vendor_lrp = last_read_path_df.filter(
        (col("Vendor") == vendor) & (col("Date") == formatted_date)
    )
    vendor_path = f"{self.hdfs_data_folder}/{vendor}/{profile}/{formatted_date}"
    
    all_files_df = self.spark.read.format("parquet").load(vendor_path)
    all_files = all_files_df.inputFiles()
    
    if vendor_lrp.limit(1).count() < 1:
        # First time reading — process entire folder
        valid_paths.append(vendor_path)
    else:
        last_path = vendor_lrp.select("FilePath").first()["FilePath"]
        # Only read files newer than last processed
        new_files = [f for f in all_files if f > last_path]
        valid_paths.extend(new_files)
```

**Why this matters:** Without LRP, every run re-reads ALL Parquet files for the date. With LRP, only new files since last run are processed. On a vendor getting 20 file uploads/day, this reduces I/O by 60% on the 6AM and 9AM runs.

### Spark Optimization (from scheduler)

```bash
--conf spark.sql.adaptive.enabled=true
--conf spark.sql.adaptive.coalescePartitions.enabled=true
--conf spark.sql.adaptive.skewJoin.enabled=true
--conf spark.sql.shuffle.partitions=128
--conf spark.dynamicAllocation.enabled=true
--conf spark.dynamicAllocation.minExecutors=2
--conf spark.dynamicAllocation.maxExecutors=6
--conf spark.memory.fraction=0.6
--conf spark.memory.storageFraction=0.3
```

**Key optimizations:**
- **AQE (Adaptive Query Execution):** Auto-coalesces shuffle partitions and handles skew
- **Dynamic allocation:** Scales executors based on load (2 min, 6 max)
- **Memory tuning:** 60% execution, 30% storage — optimized for aggregation workloads with persistence

### Daily Aggregation Logic

```python
def hdfs_daily_data(self, df_row1, df_row2, df_consumer, req_date, logger):
    # Join today and yesterday on (IMEI, Vendor) to compute delta
    final_df = df1_r.alias('df1').join(df2_r.alias('df2'), on=['IMEI', 'Vendor'], how='inner')
    
    # Delta = today cumulative - yesterday cumulative
    final_df = final_df.withColumn(
        "Active energy Import",
        F.col('df1.`1-0.1.8.0.255`') - F.col('df2.`1-0.1.8.0.255`')
    )
    
    # Filter out meter resets (negative deltas)
    final_df = final_df.withColumn('min_val', F.least(...)).filter(F.col('min_val') >= 0)
    
    # Deduplicate using device list (avoid double-counting on re-runs)
    daily_agg_df = self.filter_cassandra_data(daily_agg_df, prev_day, logger)
```

**Why delta approach:** Smart meters report cumulative readings. Daily consumption = today's reading - yesterday's reading. Negative values indicate meter replacement/reset and are filtered out.

### Cassandra Write with Repartitioning

```python
def push_block_data_to_cassandra(self, spark_df, table, req_date, logger):
    result_df = spark_df.withColumn("Vendor", upper(col("Vendor")))
    result_df = result_df.repartition("device", "date")
    
    result_df.write \
        .format("org.apache.spark.sql.cassandra") \
        .mode("append") \
        .options(table=table, keyspace=self.keyspace) \
        .option("spark.cassandra.output.batch.size.rows", "25") \
        .option("spark.cassandra.output.concurrent.writes", "6") \
        .option("spark.cassandra.output.consistency.level", "LOCAL_ONE") \
        .save()
```

**Why repartition by (device, date):** Cassandra partition key is (device, date). Repartitioning aligns Spark partitions with Cassandra token ranges, minimizing coordinator hops and enabling batch inserts to the same partition.

---

## Scale, Performance, and Optimization

| Metric | Value |
|---|---|
| Meters processed | 4M+ across 11 vendors |
| Profiles | Block (15/30 min), Daily, Monthly/Billing |
| Daily data volume | ~200-500 GB Parquet per day (all vendors) |
| Processing time (daily) | ~10-15 min per vendor (down from 45+ min with Python) |
| LRP reduction | 60% fewer redundant reads |
| Throughput improvement | 3x vs legacy Python scripts |
| Cluster config | 8GB driver, 8GB executor, 4 cores, 2-6 dynamic executors |
| Shuffle partitions | 128 (tuned for workload) |

**Key optimizations applied:**
1. **Incremental ingestion (LRP)** — Only process new files
2. **AQE** — Auto-coalesce and skew handling
3. **Broadcast joins** — Metadata DataFrames are small enough to broadcast
4. **Persistence** — LRP DataFrame persisted to MEMORY_AND_DISK to avoid recomputation
5. **Repartition before write** — Aligns with Cassandra partition keys
6. **Filter pushdown** — Parquet predicate pushdown on date/profile filters

---

## Design Decisions and Trade-offs

| Decision | Reasoning | Trade-off |
|---|---|---|
| LRP as Parquet on HDFS | Simple, no external DB dependency | Risk of corruption if two jobs write simultaneously (mitigated by 180s sleep) |
| Vendor-parallel scheduling | Each vendor runs as separate Spark job | More cluster resource usage but better fault isolation |
| Delta-based daily aggregation | Handles cumulative meter readings correctly | Requires exactly 2 days of data; gaps cause missing aggregations |
| Cassandra as serving layer | Low-latency time-series reads | No complex joins; denormalized schema |
| YARN cluster mode | Production stability, log aggregation | Harder to debug vs client mode |
| 180-second LRP wait | Prevents race condition between LRP read and write | Adds latency to short-running jobs |

---

## Interview Talking Points (2-minute explanation)

> "I built the Smart Meter Data Analytics Pipeline at Jio, processing data from 4 million+ smart meters across India. The core challenge was replacing legacy Python scripts that couldn't scale beyond a single vendor.
>
> I designed a PySpark pipeline that runs on YARN with three aggregation types: block (15/30 min intervals), daily, and monthly billing. The key innovation was an incremental ingestion framework using Last-Read-Path tracking on HDFS — it tracks the latest processed Parquet file per vendor/date, so re-runs only process new data, reducing redundant reads by 60%.
>
> For daily aggregation, I compute deltas between consecutive days' cumulative readings, filter out meter resets, and deduplicate using a device list. The results push to Cassandra with repartitioning aligned to the partition key for optimal write performance.
>
> The pipeline runs via shell schedulers on cron at 3 scheduled times daily, with AQE and dynamic allocation for resource efficiency. This achieved a 3x throughput improvement over the legacy approach."

---

## Common Follow-up Questions

1. **"How do you handle late-arriving data?"** → The LRP mechanism handles this naturally. If new files arrive after the first run, the 6AM/9AM runs pick them up because they only process files newer than LRP.

2. **"What happens if a Spark job fails mid-way?"** → The LRP is only updated AFTER successful processing. If a job fails, the next run re-processes from the last successful LRP. The 180-second wait ensures LRP isn't written prematurely.

3. **"Why not use Airflow instead of cron?"** → For this project, the scheduling needs were simple (3 fixed times, vendor-parallel). Airflow was introduced later for the Battery Analytics project where DAG dependencies were complex.

4. **"How do you handle schema changes across vendors?"** → `match_columns()` adds missing columns as nulls with correct types. The pipeline handles heterogeneous schemas from 11+ vendors without vendor-specific code paths.

5. **"What's the partition strategy for HDFS reads?"** → Data is already partitioned by vendor/profile/date on HDFS. The pipeline reads exactly the needed partition path, leveraging HDFS directory structure as a partition scheme.

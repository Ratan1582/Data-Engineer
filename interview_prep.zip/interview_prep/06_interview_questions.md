# Comprehensive Interview Questions

## 1. Project Deep-Dive Questions

### Smart Meter Data Analytics Pipeline

**Q: Walk me through the Smart Meter aggregation pipeline end-to-end.**
> Start with data landing on HDFS as Parquet (per vendor/profile/date). The pipeline uses Last-Read-Path tracking to identify only new files. Data is parsed (nested JSON exploded → pivoted to columns), then aggregated at block (hourly sums), daily (delta between consecutive days), or monthly (billing profile delta from previous month cumulative). Results push to Cassandra via the Spark connector with repartitioning aligned to the partition key. Scheduled via cron-triggered shell scripts that invoke `spark3-submit` in YARN cluster mode with AQE enabled.

**Q: How does your incremental ingestion (LRP) work? What happens if it gets corrupted?**
> LRP is a Parquet file on HDFS storing (Vendor, Date, FilePath) — the latest processed Parquet file path per vendor/date. On each run, only files with paths lexicographically greater than LRP are read. If corrupted: the pipeline falls back to processing the entire date folder (no LRP filter found → `vendor_lrp.limit(1).count() < 1`). The 180-second wait before writing prevents premature LRP updates on short jobs.

**Q: Why did you choose Cassandra over a relational database for the serving layer?**
> Smart meter data is time-series with high write volume (millions of inserts/day). Cassandra excels at: (1) write-heavy workloads with tunable consistency, (2) partition-key-based reads (device + date), (3) linear horizontal scalability. We don't need complex joins at the serving layer — those happen in Spark during aggregation.

**Q: What would you do differently if redesigning this pipeline today?**
> I'd consider: (1) Delta Lake for ACID guarantees and schema evolution on HDFS, (2) Databricks Workflows instead of cron for better dependency management, (3) Spark Structured Streaming for near-real-time daily aggregation, (4) a metadata catalog (like Hive Metastore or Unity Catalog) for better data discovery.

---

### Kafka Event Pipeline

**Q: Explain your BufferedConsumer architecture and why you chose manual offset management.**
> The BufferedConsumer accumulates messages in memory until a flush threshold is hit (count, bytes, or time). On flush: records are enriched, serialized as NDJSON, and written to HDFS. Only after successful HDFS write do we commit offsets. Manual commit (`enable_auto_commit=False`) is essential because auto-commit would advance offsets even if the HDFS write failed, causing data loss.

**Q: How do you handle exactly-once delivery? What about duplicates?**
> We achieve at-least-once delivery: if consumer crashes after HDFS write but before commit, messages are re-consumed and re-written. Downstream deduplication handles this: the ETL Spark job uses `dropDuplicates()` on (device_id, event_time), and HDFS append is inherently idempotent for the same batch. True exactly-once would require Kafka transactions + 2PC, which adds complexity we didn't need.

**Q: What happens during a Kafka rebalance? How do you prevent data loss?**
> Session timeout (60s) is set higher than typical HDFS write latency (5-30s). If rebalance occurs: (1) current buffer is flushed in the `shutdown()` method, (2) committed offsets are preserved, (3) rebalanced partitions restart from committed offset. Uncommitted buffer data from crashed consumers is re-consumed by the new assignee.

**Q: Why NDJSON as intermediate format instead of writing Parquet directly?**
> NDJSON is appendable — the BufferedConsumer can append to existing files without rewriting. Parquet isn't appendable (it requires writing the footer). NDJSON also enables easy debugging (`cat file.ndjson | head`). The trade-off is the downstream ETL conversion step, but this also gives us a raw replay capability.

**Q: How would you scale this to 10x the current throughput?**
> (1) Increase Kafka partitions and run more consumer instances (same group), (2) Increase buffer thresholds for larger batch writes, (3) Consider Spark Structured Streaming for the ETL layer to replace the batch Janitor, (4) Move to a columnar landing format like Delta Lake with append mode.

---

### Battery Analytics Platform

**Q: Describe the Python-to-Spark migration. What was the hardest part?**
> Hardest part: the KPI computation logic was in Pandas with complex rolling windows and conditional accumulations. We couldn't rewrite 1400+ lines of domain logic in pure Spark SQL. Solution: `applyInPandas` — group by device, apply Pandas function per group. This preserved validated logic while distributing across the cluster. The trade-off is a shuffle to group by device, but each group is small (96-288 records/day).

**Q: How does Marshmallow handle schema evolution when an OEM changes their API?**
> `@pre_load` hooks check multiple possible field names (old and new). `Meta.unknown = EXCLUDE` ignores newly added fields. This means: (1) old field names still work, (2) new names are handled by the same schema, (3) new unexpected fields don't crash the pipeline. To support a genuinely new metric, we add a field to the schema and set `allow_none=True` for backward compatibility.

**Q: Why applyInPandas instead of pure PySpark window functions?**
> The KPI logic involves: (1) rolling means with variable windows, (2) conditional state machines (charging → discharging transitions), (3) iterative C-rate calculations that depend on previous rows. These are straightforward in Pandas (`df.rolling()`, `iterrows()`) but extremely complex in Spark SQL. Since each device has only 96-288 rows/day, the per-group memory is trivial.

---

### Energy Disaggregation

**Q: How does pandas_udf work for PyTorch inference? Walk me through the data flow.**
> (1) Spark partitions the DataFrame, (2) for each partition, Arrow serializes the columns into Pandas Series, (3) the UDF receives these Series (e.g., arrays of power sequences), (4) we reshape to numpy → tensor, (5) batch forward pass through the CNN, (6) predictions returned as Pandas Series → Arrow → back to Spark column. The key insight: batching hundreds of sequences in one forward pass is dramatically faster than row-by-row.

**Q: Why broadcast the model? What if the model is too large to broadcast?**
> Broadcasting sends the model once to each executor's BlockManager (shared memory). Our CNN is ~500KB — trivial. For large models (>2GB): use model serving (TorchServe/Triton) and call it via HTTP from the UDF, or use `mapPartitions` with model loading per partition (loaded once, reused across rows in that partition).

**Q: How do you ensure predictions are physically valid?**
> Three-stage post-processing: (1) clip negatives to zero (appliance can't produce energy), (2) cap predictions at total consumption (appliance can't exceed total), (3) proportional scaling if sum of appliances > total (energy conservation). This guarantees `sum(all_appliances) ≤ total_consumption`.

---

### SLA Monitoring

**Q: Explain the SBD time-window flags. Why 24 + N hours?**
> Smart meters measure at various times. The SLA contract says "data must arrive within N hours of the measurement date." We standardize by computing deadline from midnight of measurement date: `measure_date + 24h + Nh`. So for a reading at 3PM on Jan 15 with 8h SLA: deadline = Jan 16 midnight + 8h = Jan 16 08:00. The reading at 3PM + 8h = 11PM Jan 15 would pass (receive_time < deadline).

**Q: How does the ODR script handle cumulative month-to-date without re-reading everything?**
> LRP tracking per (vendor, profile, date). On each run: (1) load previous LRP from HDFS, (2) for each date in the month, discover files newer than LRP, (3) read only new files, (4) merge counts with existing ODR aggregate via `unionByName` + `groupBy(sum)`, (5) persist updated aggregate. This is O(new_data) not O(all_month_data).

---

## 2. Apache Spark / PySpark

**Q: Explain how Spark partitioning works and its impact on performance.**
> Partitioning determines data distribution across tasks. Hash partitioning (`.repartition(col)`) distributes evenly by hash. Range partitioning orders data. **Impact:** too few partitions → underutilized cores; too many → scheduling overhead + small files. **In my projects:** I use 128 shuffle partitions for aggregation workloads, repartition by (device, date) before Cassandra writes (aligns with partition key), and coalesce(1) in the Janitor to solve small-file problems.

**Q: What causes shuffles in Spark? How do you minimize them?**
> Shuffles occur on: `groupBy`, `join`, `repartition`, `distinct`, `orderBy`. **Minimization strategies I've used:** (1) broadcast joins for small tables (metadata DataFrames < 100MB), (2) pre-partitioning data to avoid join shuffles, (3) AQE's coalesce partitions to merge post-shuffle small partitions, (4) `localCheckpoint()` to break lineage and avoid re-shuffle on reuse.

**Q: Explain broadcast joins. When would you NOT use them?**
> Broadcast join copies the small table to all executors, avoiding a full shuffle. **I used it for:** metadata DataFrames (device list, vendor config). **Don't use when:** the "small" table is >100MB (default threshold) — it would OOM executors. Also avoid in Structured Streaming (broadcast is static; doesn't refresh). In my pipeline: `broadcast(metadata_spark_df)` for the SLA metadata join.

**Q: What is Adaptive Query Execution (AQE)? How does it help?**
> AQE optimizes the query plan at runtime based on actual data statistics (after shuffle materialization). **Three features:** (1) coalesce shuffle partitions (merges small post-shuffle partitions), (2) convert sort-merge join to broadcast if one side is small, (3) optimize skewed joins by splitting large partitions. **In my config:** `spark.sql.adaptive.enabled=true` + `coalescePartitions.enabled=true` + `skewJoin.enabled=true`.

**Q: Explain the difference between `repartition()` and `coalesce()`.**
> `repartition(N)` creates exactly N partitions via full shuffle (can increase or decrease). `coalesce(N)` reduces partitions without full shuffle (merges adjacent partitions). **My usage:** `repartition("device", "date")` before Cassandra writes (need hash distribution), `coalesce(1)` in Janitor (reduce small files without expensive shuffle).

**Q: How does `applyInPandas` differ from regular UDFs?**
> Regular UDFs operate row-by-row. `applyInPandas` operates on entire groups — receives a Pandas DataFrame (all rows for one group), returns a Pandas DataFrame. **Advantages:** full Pandas API available, vectorized operations, natural for per-entity logic. **My usage:** per-device KPI computation in Battery Analytics, per-device timeline padding in Disaggregation.

**Q: How do you handle the small file problem?**
> **Cause:** Frequent writers (Kafka consumers) create many small files. **Impact:** slow Spark reads (high file handle overhead), inefficient NameNode usage. **My solutions:** (1) Janitor compaction job using `coalesce(1)` with atomic swap, (2) BufferedConsumer AM/PM file naming (max 2 files/consumer/day), (3) AQE coalesce partitions for shuffle outputs.

**Q: Explain Spark memory management (execution vs storage).**
> Unified Memory Manager splits executor memory into: execution (shuffles, joins, sorts) and storage (cached DataFrames). Default: `spark.memory.fraction=0.6` of heap, split by `storageFraction=0.5`. **My tuning:** `fraction=0.6, storageFraction=0.3` — biased toward execution since aggregation jobs do heavy shuffles and we persist strategically.

**Q: What's the Catalyst optimizer?**
> Spark's query optimizer that: (1) parses logical plan, (2) applies rule-based optimizations (predicate pushdown, column pruning, constant folding), (3) generates physical plans, (4) selects optimal via cost model. **Relevant to my work:** Parquet predicate pushdown filters partitions at file level; column pruning reads only needed columns from wide Parquet files.

---

## 3. Apache Kafka

**Q: Explain consumer groups and partition assignment.**
> A consumer group is a set of consumers that coordinate to consume a topic. Each partition is assigned to exactly one consumer in the group. If consumers > partitions, some sit idle. If consumers < partitions, some get multiple. **My setup:** single consumer group `energenie-events-consumer`, with ability to scale to 3 instances distributing partitions.

**Q: What's the difference between at-most-once, at-least-once, and exactly-once?**
> - **At-most-once:** Commit offset, then process. If processing fails, data is lost.
> - **At-least-once:** Process, then commit. If commit fails, data is re-processed (duplicates possible).
> - **Exactly-once:** Requires transactions (idempotent producer + transactional consumer) or external deduplication.
> **My implementation:** At-least-once (process → write HDFS → commit). Duplicates handled by downstream ETL deduplication.

**Q: How does manual offset management work? Why did you choose it?**
> With `enable_auto_commit=False`, the consumer must explicitly call `consumer.commit()`. This decouples offset advancement from message consumption. **Why:** I need to commit ONLY after successful HDFS write. Auto-commit would advance offsets on poll(), regardless of write success — risking data loss.

**Q: What is a consumer rebalance? How do you handle it gracefully?**
> Rebalance occurs when: consumer joins/leaves group, new partition added, or consumer misses heartbeat. During rebalance, consumption pauses. **My handling:** (1) session_timeout=60s (high enough for HDFS writes), (2) heartbeat_interval=10s (keeps consumer alive during processing), (3) `shutdown()` method flushes buffer on SIGTERM before closing consumer.

**Q: Design a dead letter queue for your Kafka pipeline.**
> Already implemented: `_write_failed_records()` writes unparseable messages to `{base_path}/failed_consumers/{consumer_id}_{date}.ndjson`. For a full DLQ: (1) produce failed messages to a separate Kafka topic (`events_data_dlq`), (2) include original offset, partition, error reason, (3) monitor DLQ depth as an alert metric, (4) build a replay tool that re-produces from DLQ to main topic after fixing.

**Q: How would you handle backpressure in your consumer?**
> Current design: if HDFS writes slow down, the buffer accumulates but is bounded by `max_messages`/`max_bytes`. If those are hit before the time threshold, flush is triggered. **Enhanced backpressure:** (1) pause consumer polling when buffer is full (`consumer.pause(partitions)`), (2) resume after successful flush, (3) expose buffer size as a metric for alerting.

---

## 4. System Design

**Q: Design a real-time IoT data pipeline (similar to your Kafka pipeline but at 100x scale).**
> **Answer outline:** 
> - **Ingestion:** Kafka with multiple partitions (partition by device_id for ordering). Use Kafka Connect or custom consumers with backpressure.
> - **Stream processing:** Spark Structured Streaming or Flink for windowed aggregation (tumbling/sliding windows for alerts).
> - **Storage:** Delta Lake on S3/HDFS for ACID, schema evolution, time travel. Hot path → Redis/Cassandra for real-time dashboards.
> - **Exactly-once:** Kafka transactions + idempotent Spark writes (checkpointing + WAL).
> - **Scaling:** Horizontal (more Kafka partitions + consumers), auto-scaling consumers based on lag metric.
> - **Monitoring:** Consumer lag, processing latency (end-to-end), HDFS write throughput, dead letter queue depth.

**Q: Design a data quality monitoring system.**
> **Answer outline:** 
> - **Dimensions:** Completeness (% records received), Timeliness (latency from measurement to arrival), Accuracy (value range checks), Consistency (cross-source reconciliation).
> - **Implementation:** (1) Lightweight checks inline (null counts, range checks during ETL), (2) Scheduled quality jobs (my SLA pipeline approach: compare expected vs actual), (3) Anomaly detection on quality metrics time series.
> - **Alerting:** Threshold-based (completeness < 90%) + trend-based (sudden drops). Route to PagerDuty/Slack.
> - **Dashboard:** Time-series of quality metrics per source/dimension. Drill-down to device level.
> - **Reference:** My SLA monitoring does exactly this — SBD for timeliness, ODR for completeness, categories for distribution.

**Q: How would you scale your Smart Meter pipeline to 40M meters (10x)?**
> - **Data tier:** Increase HDFS replication factor, use erasure coding. Consider S3/ADLS for cheaper storage.
> - **Processing:** More executors (dynamic allocation max → 20+), increase shuffle partitions (512+), consider per-vendor parallel Spark applications (already implemented).
> - **Serving:** Cassandra scales linearly; add nodes. Consider materialized views for pre-computed aggregates.
> - **Optimization:** Partition data by date+vendor on HDFS for better pruning. Use Delta Lake for MERGE operations instead of overwrite.
> - **Orchestration:** Move from cron to Airflow/Dagster for better dependency management and monitoring.

---

## 5. Data Pipeline Architecture

**Q: Batch vs streaming — when would you choose each?**
> **Batch:** (1) Historical reprocessing needed, (2) Complex aggregations across large windows, (3) Cost optimization (run on spot instances), (4) Latency tolerance > minutes. **My daily/monthly aggregations are batch.**
> **Streaming:** (1) Real-time alerts needed, (2) Event-driven architecture, (3) Continuous ingestion (my Kafka consumer is streaming-style). 
> **Hybrid (Lambda):** My architecture uses both — streaming ingestion (Kafka consumer) + batch processing (Spark aggregation).

**Q: How do you ensure idempotency in your pipelines?**
> (1) **Daily aggregation:** Overwrite mode for processed data files — re-running produces same result. (2) **Cassandra writes:** Append mode with deterministic (device, timestamp) keys — duplicate inserts are no-ops. (3) **ODR:** Aggregate uses sum(counts), so duplicate source files would inflate numbers — prevented by LRP tracking. (4) **Kafka consumer:** NDJSON append with unique filename (consumer_id + timestamp) — re-consumed messages append to same file (idempotent).

**Q: How do you handle schema evolution?**
> (1) **Parquet:** Schema embedded in file; new columns automatically appear as null in old files when read with a union schema. (2) **Marshmallow:** `@pre_load` handles field renames; `EXCLUDE` unknown handles additions. (3) **Spark:** `match_columns()` in my aggregation pipeline adds missing columns with nulls. (4) **Best practice:** Use Avro/Protobuf for schema registry in Kafka; Delta Lake for schema enforcement + evolution in storage.

**Q: Explain the medallion architecture (Bronze/Silver/Gold).**
> - **Bronze:** Raw ingested data (my HDFS NDJSON landing zone / raw Parquet)
> - **Silver:** Cleaned, validated, normalized (my ETL Spark output: schema-enforced Parquet)
> - **Gold:** Business-level aggregates (my Cassandra tables: dap_block, sla_data_completeness)
> 
> My pipeline naturally follows this: Kafka → NDJSON (Bronze) → ETL → Parquet (Silver) → Aggregation → Cassandra (Gold).

---

## 6. Airflow and Orchestration

**Q: How do you design Airflow DAGs for data pipelines?**
> (1) **Atomic tasks:** Each task does one thing (ingest, transform, load). (2) **Idempotent tasks:** Re-running doesn't create duplicates. (3) **Dependencies:** Use `>>` operator or `depends_on_past`. (4) **Retries:** Set retry count + delay for transient failures. (5) **Alerting:** `on_failure_callback` for Slack/email. **My Battery Analytics DAG:** ingest → spark_aggregation → generate_feeds, with 2 retries and 5-min delay.

**Q: How do you handle backfill in Airflow?**
> (1) `catchup=True` + `start_date` in the past triggers historical runs. (2) Manual trigger with `execution_date` parameter. (3) **In my design:** separate backfill scripts (`daily_30days_pyspark.py`, `block_7days_pyspark.py`) that iterate over date ranges independently of Airflow scheduling.

**Q: What's the difference between `depends_on_past` and `wait_for_downstream`?**
> - `depends_on_past=True`: Current task instance only runs if previous date's same task succeeded.
> - `wait_for_downstream=True`: Current task only runs if previous date's entire downstream chain completed.
> **Usage:** I'd use `depends_on_past` for the aggregation task (today's delta needs yesterday's data), but not for independent feed generation.

---

## 7. Performance Optimization

**Q: How did you achieve the 3x throughput improvement in the Smart Meter pipeline?**
> (1) **Distributed processing:** Moved from single-node Python (sequential) to PySpark on YARN (parallel across executors). (2) **Incremental reads:** LRP tracking reduced I/O by 60%. (3) **AQE:** Auto-optimized shuffle partitions and handled vendor-specific data skew. (4) **Broadcast joins:** Eliminated shuffle for metadata lookups. (5) **Repartition before write:** Aligned with Cassandra partition keys for batch inserts.

**Q: How do you diagnose a slow Spark job?**
> (1) **Spark UI:** Check stage timelines for stragglers, shuffle read/write sizes. (2) **Event log:** Look for GC pauses, spill to disk. (3) **Common culprits:** Data skew (one partition much larger), too many/few partitions, excessive shuffles, non-broadcast joins. (4) **My approach:** Start with `explain()` on the query plan, check for unnecessary shuffles, verify partition counts match parallelism.

**Q: Explain your Spark configuration tuning approach.**
> **Driver/Executor memory (8GB):** Sized for largest in-memory DataFrame (metadata + aggregated data).
> **Executor cores (4):** Balances parallelism vs memory per task.
> **Dynamic allocation (2-6):** Handles varying vendor sizes without over-provisioning.
> **Shuffle partitions (128):** Tuned based on data volume (~200-500 GB → 128 partitions of 1-4 GB each).
> **Memory fraction (0.6):** Standard; biased toward execution for aggregation-heavy workloads.
> **Network timeout (800s):** High for cluster stability; prevents false-positive task failures.

---

## 8. Behavioral / STAR Format

**Q: Tell me about a time you had to make a critical technical decision under uncertainty.**
> **Situation:** Needed to add Kafka consumer capability to the Battery Analytics platform; no existing Kafka infrastructure on the team.
> **Task:** Design and implement production-grade consumers handling 100K+ device telemetry.
> **Action:** Researched BufferedConsumer pattern for amortizing HDFS write overhead. Chose manual offset management for data safety. Built configurable flush thresholds so we could tune without code changes. Deployed across 4 environments with offset initialization tooling.
> **Result:** Zero data loss in 18+ months of production. Processed 6+ msg/sec reliably with graceful shutdown handling.

**Q: Describe a situation where you had to optimize a system that was too slow.**
> **Situation:** Legacy Python aggregation scripts took 6+ hours for daily processing of 4M meters.
> **Task:** Reduce processing time to meet the 3-run-per-day schedule (8-hour windows).
> **Action:** Migrated to PySpark with incremental ingestion (LRP), AQE optimization, broadcast joins, and vendor-parallel execution via shell schedulers.
> **Result:** 3x throughput improvement. Daily aggregation completes in 10-15 minutes per vendor. Full fleet processed well within each 8-hour window.

**Q: Tell me about a time you dealt with a production incident.**
> **Situation:** ODR script started producing inflated completeness numbers (>100%) for some vendors.
> **Task:** Identify root cause and fix without disrupting ongoing SLA reporting.
> **Action:** Investigated and found midnight-overlap readings being double-counted. Added the `when(percentage > 100, percentage / 2)` correction and fixed the root cause in the join logic with proper midnight vs non-midnight handling.
> **Result:** Metrics corrected within one business day. Added the handling as a permanent fix with unit-testable logic.

**Q: Describe how you handle competing priorities on a team.**
> **Situation:** Simultaneously needed to deliver disaggregation pipeline (new feature) and fix SLA monitoring bugs (production issue).
> **Task:** Balance feature delivery with production stability.
> **Action:** Prioritized SLA fix (production impact), delivered a quick fix within 1 day. Then context-switched to disaggregation with a clear plan. Communicated timeline expectations to both stakeholders.
> **Result:** SLA fix deployed same day. Disaggregation delivered on original timeline by working efficiently on the clear plan.

---

## Quick Reference: Key Numbers to Remember

| Metric | Value | Context |
|---|---|---|
| Smart meters | 4M+ | DAP pipeline scale |
| IoT devices | 100K+ | Battery analytics scale |
| Throughput improvement | 3x | Python → PySpark migration |
| LRP read reduction | 60% | Incremental ingestion benefit |
| Runtime reduction | 40% | Battery analytics migration |
| Kafka topics | 4 | Event pipeline consumers |
| Time windows | 6 | SLA monitoring thresholds |
| Vendors | 14 | SLA monitoring coverage |
| Appliances | 3 + 2 | Disaggregation outputs |
| CNN architecture | 3 Conv1d + 2 FC | Disaggregation model |
| Buffer thresholds | 3 | BufferedConsumer design |
| Environments | 4 | dev/sit/preprod/prod |

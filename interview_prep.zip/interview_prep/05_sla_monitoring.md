# Automated SLA Monitoring and Data Quality Framework

## Problem Statement and Business Context

Utility companies have contractual SLA obligations for smart meter data delivery. If a meter's data doesn't arrive within specified time windows (7h, 8h, 11h, 12h, 22h, 24h after measurement), the utility faces penalties. Jio's Data Analytics Pipeline must continuously monitor and report data completeness.

**Business Need:**
- Track **per-device, per-vendor SLA compliance** at multiple time thresholds
- Compute **ODR (Operational Data Reads)** — cumulative month-to-date completeness
- Generate **CSV reports** for utility stakeholders (uploaded to Azure Blob Storage)
- Categorize devices into completeness buckets ([100], [90-100), [50-90), (0-50), [0]) for KPI dashboards
- Write metrics to Cassandra for real-time dashboard consumption

**Scale:** 14 vendors, 4M+ meters, daily computation across the full month-to-date range.

---

## Architecture

```mermaid
flowchart TD
    subgraph input [Input Sources]
        HDFS["HDFS Parquet\n/NOC/SM/{Vendor}/{Profile}/{Date}"]
        MongoDB["MongoDB\nDeviceMetaData_{Vendor}"]
        Cassandra_In["Cassandra\n(previous aggregates)"]
    end

    subgraph sbd [Step 1: SBD Script]
        SBD_Fetch["Fetch new data\n+ track LRP"]
        SBD_Join["Join with metadata\n(broadcast)"]
        SBD_Flags["Compute time-window flags\n(7h, 8h, 11h, 12h, 22h, 24h)"]
        SBD_Agg["Device-level aggregate"]
        SBD_Report["Vendor-level report\n(mean completeness %)"]
    end

    subgraph odr [Step 2: ODR Script]
        ODR_Discover["Discover new files\n(per date in month)"]
        ODR_Track["Update LRP tracking"]
        ODR_Merge["Merge with existing\nODR aggregates"]
        ODR_Metrics["Compute month-to-date\ncompleteness"]
    end

    subgraph blob [Step 3: Blob Script]
        Blob_Read["Read SBD + ODR\naggregates"]
        Blob_CSV["Generate per-vendor\nCSV reports"]
        Blob_Cat["Categorize devices\ninto completeness buckets"]
    end

    subgraph output [Output Destinations]
        Cassandra_Out["Cassandra\n(day_sla_module, sla_data_completeness,\ndata_completeness_categories)"]
        Blob_Storage["Azure Blob Storage\n(CSV exports)"]
        HDFS_Out["HDFS\n(sbd_aggregate, odr_aggregate)"]
    end

    HDFS --> SBD_Fetch
    MongoDB --> SBD_Join
    SBD_Fetch --> SBD_Join --> SBD_Flags --> SBD_Agg --> SBD_Report
    SBD_Report --> Cassandra_Out
    SBD_Agg --> HDFS_Out

    HDFS --> ODR_Discover
    HDFS_Out --> ODR_Merge
    ODR_Discover --> ODR_Track --> ODR_Merge --> ODR_Metrics
    ODR_Metrics --> Cassandra_Out
    ODR_Metrics --> HDFS_Out

    HDFS_Out --> Blob_Read
    Blob_Read --> Blob_CSV --> Blob_Storage
    Blob_Read --> Blob_Cat --> Cassandra_Out
```

---

## Tech Stack and Why Each Was Chosen

| Technology | Role | Why |
|---|---|---|
| **PySpark** | Distributed metric computation | Millions of devices × multiple profiles × month-to-date range |
| **Apache Cassandra** | Real-time metrics serving | Low-latency reads for SLA dashboards |
| **Azure Blob Storage** | CSV export target | Stakeholder-facing reports; accessible via Azure portal |
| **MongoDB** | Device metadata | Installation dates for filtering active meters |
| **HDFS** | Intermediate aggregates | Persist SBD/ODR aggregates for incremental processing |
| **Shell/Cron** | Orchestration | Sequential execution: SBD → ODR → Blob |

---

## The Three Scripts Explained

### Script 1: SBD (Same-Business-Day Completeness)

**Purpose:** For a given date, determine what percentage of expected data packets arrived within each time window.

**Logic:**
1. Fetch all HDFS Parquet files for the date
2. Join with MongoDB metadata (only installed devices count)
3. For each device reading, check if `Receive_time < Measure_date + N hours` for N ∈ {7, 8, 11, 12, 22, 24}
4. Set flag=1 if within deadline, 0 otherwise
5. Aggregate: count distinct readings per device and sum flags
6. Compute percentages: `count / max_expected_packets × 100`
   - 15-min vendors: max = 96 packets/day (BLOCK profile)
   - 30-min vendors: max = 48 packets/day (BLOCK profile)
   - DAILY profile: max = 1 packet/day (so percentage = count × 100)

**Output:**
- Device-level: `sbd_aggregate` Parquet on HDFS
- Vendor-level: Cassandra `day_sla_module` table

### Script 2: ODR (Operational Data Reads — Cumulative)

**Purpose:** Track month-to-date cumulative completeness, incorporating late-arriving data.

**Logic:**
1. For each date in current month (1st to today):
   - Discover new files since last run (LRP tracking)
   - Read and parse new Parquet files
2. Merge new counts with existing ODR aggregate
3. Compute cumulative completeness percentage
4. Handle >100% edge case (divide by 2 — capped readings from midnight overlaps)
5. Generate vendor-level pivot report (Block vs Daily profile)

**Output:**
- Device-level: `odr_aggregate` Parquet on HDFS (updated in-place)
- Vendor-level: Cassandra `sla_data_completeness` table

### Script 3: Blob (Report Generation)

**Purpose:** Convert aggregates to CSV for utility stakeholders and categorize devices.

**Logic:**
1. Read SBD aggregate — pivot per device with hour columns for each profile
2. Read ODR aggregate — merge month-to-date across dates
3. Generate per-vendor CSV files:
   - `{date}_{VendorName}_Meterwise_SLA_Numbers_for_SBD.csv`
   - `{date}_{VendorName}_Meterwise_SLA_Numbers_for_Relaxed.csv`
4. Categorize devices into buckets: [100], [90-100), [50-90), (0-50), [0]
5. Write category proportions to Cassandra `data_completeness_categories`

---

## Key Code Snippets with Explanations

### SBD Time-Window Flag Computation

```python
def generate_sbd_aggregate(vendor, formatted_date, target_date, logger):
    # Join data with metadata (broadcast for efficiency)
    final_sbd_data_df = sbd_data_df.join(
        broadcast(metadata_spark_df), on=["IMEI", "Vendor", "Profile"], how="right"
    )
    
    # For each time window, compute a flag: did data arrive within N hours?
    hours = [7, 8, 11, 12, 22, 24]
    for hour in hours:
        deadline = col("date").cast("timestamp") + expr(f"INTERVAL {24 + hour} HOURS")
        work_df = work_df.withColumn(
            f"flag_{hour}",
            when(
                col("Receive_time").isNotNull() & (col("Receive_time") < deadline),
                lit(1)
            ).otherwise(lit(0))
        )
    
    # Aggregate per device: sum flags + count distinct timestamps
    sbd_count_df = work_df.groupBy(
        "IMEI", "date", "Profile", "Vendor", "Installation Date"
    ).agg(
        *[spark_sum(col(f"flag_{h}")).alias(str(h)) for h in hours],
        countDistinct(col("Measure_time")).alias("total_count"),
    )
```

**Why `24 + hour`:** The deadline is measured from midnight of the measurement day, not from the measurement time. So "7h window" means data must arrive by 7:00 AM the NEXT day (measurement_date + 24h + 7h = 31h from midnight).

### Percentage Calculation with Vendor-Specific Max

```python
# Different vendors have different expected packet counts
sbd_pct_df = sbd_count_df.withColumn(
    "max_count",
    when(col("vendor").isin(vendors_15), lit(96))   # 15-min interval: 96 packets/day
    .otherwise(lit(48))                              # 30-min interval: 48 packets/day
)

for c in hour_cols:
    sbd_pct_df = sbd_pct_df.withColumn(
        f"{c} %",
        when(col("profile") == "DAILY", col(c).cast("double") * 100.0)  # Daily: binary (0 or 100%)
        .otherwise(col(c).cast("double") * 100.0 / col("max_count").cast("double"))
    )
    # Clamp to [0, 100]
    sbd_pct_df = sbd_pct_df.withColumn(
        f"{c} %",
        least(greatest(spark_round(col(f"{c} %"), 3), lit(0.0)), lit(100.0))
    )
```

**Key insight:** DAILY profile has max 1 reading/day, so completeness is binary (0% or 100%). BLOCK profile has 96 or 48 readings depending on vendor frequency.

### ODR Incremental File Discovery

```python
def discover_and_track_files(vendor, profiles, formatted_date, data_parent_folder,
                             last_read_path_dict, exist_last_read_path, logger):
    for folder_path in folder_paths:
        vendor_p, profile, date_str, path = utils.parse_path(folder_path)
        key = f"{vendor_p}_{profile}"
        last_read_path = last_read_path_dict.get(key, None)
        
        all_files_df = spark.read.format("parquet").load(folder_path)
        all_files = all_files_df.inputFiles()
        
        if last_read_path:
            # Only process files newer than last read
            updated_paths = [p for p in all_files 
                           if p.split(config.hdfs['url_base_path'])[1] > last_read_path]
        else:
            # First time: process entire folder
            updated_paths = [folder_path]
        
        # Update tracking DataFrame
        exist_last_read_path = _update_last_read_tracking(
            spark, exist_last_read_path, vendor_p, profile, date_str, max_path
        )
    
    return updated_path_list, last_updated_paths_list, exist_last_read_path
```

**Why incremental:** ODR runs across the entire month-to-date (e.g., on day 15, it processes dates 1-15). Without LRP tracking, it would re-read all files for all 15 days every run. With LRP, it only reads files that arrived since the last run.

### Blob Category Bucketing

```python
def categorize_percentage(p):
    if p == 100:      return "[100]"
    elif p == 0:      return "[0]"
    elif 90 <= p < 100: return "[90, 100)"
    elif 50 <= p < 90:  return "[50, 90)"
    elif 0 < p < 50:    return "(0, 50)"
    else:             return "[0]"

# Apply categorization and compute proportions per vendor/profile/date
categorize_udf = F.udf("string")(categorize_percentage)
merged_df = merged_df.withColumn("category", categorize_udf("percentage_completeness"))

window_grp = Window.partitionBy('vendor', 'profile', 'timestamp')
df_counts = merged_df.groupBy('vendor', 'profile', 'timestamp', 'category').count()
df_totals = df_counts.withColumn('total_count', F.sum('count').over(window_grp))
df_proportions = df_totals.withColumn('proportion', 100 * (F.col('count') / F.col('total_count')))
```

**Output interpretation:** "For vendor MVVNL on Jan 15, 45% of devices are in [100] category (fully compliant), 30% in [90-100), 15% in [50-90), etc."

### Utility Functions — Safe HDFS Operations

```python
def remove_hdfs_file(spark, base_path, sbd_date, days_old, filename, logger):
    old_date = (sbd_date - timedelta(days=days_old)).strftime("%Y%m%d")
    old_path = f"{base_path}/{old_date}/{filename}"
    
    path_class, fs = _get_hdfs_filesystem(spark)
    hadoop_path = path_class(old_path)
    
    if fs.exists(hadoop_path):
        fs.delete(hadoop_path, True)  # recursive=True
        logger.info(f"Successfully removed: {old_path}")

def write_cassandra_timed(df, table, keyspace, description, logger):
    start_time = datetime.now()
    df.write.format("org.apache.spark.sql.cassandra") \
        .mode("append").options(table=table, keyspace=keyspace).save()
    logger.info(f"{description}, time: {datetime.now() - start_time}")
```

---

## Scale, Performance, and Optimization

| Metric | Value |
|---|---|
| Vendors monitored | 14 |
| Meters tracked | 4M+ |
| Profiles | 2 (BLOCK, DAILY) |
| SLA time windows | 6 (7h, 8h, 11h, 12h, 22h, 24h) |
| Completeness categories | 5 buckets |
| Cassandra tables written | 3 (day_sla_module, sla_data_completeness, data_completeness_categories) |
| Blob reports generated | 2 per vendor per day (SBD + Relaxed) |
| Retention | 8 days for logs; 5 days for SBD aggregate; 35 days for LRP |

**Optimizations:**
1. **Broadcast join** with metadata (small table) against large telemetry DataFrame
2. **Incremental LRP tracking** — Only read new files since last run
3. **Persist/unpersist pattern** — Explicit memory management for large intermediate DataFrames
4. **Backup before overwrite** — `hdfs_copy` creates backup of LRP before modification
5. **Previous month cleanup** — On day 8, remove last month's ODR files to save HDFS space

---

## Design Decisions and Trade-offs

| Decision | Reasoning | Trade-off |
|---|---|---|
| 3-script sequential execution | Each script depends on previous output; clear separation of concerns | Must run in order; failure in SBD blocks ODR/Blob |
| LRP as Parquet DataFrame | Integrates with Spark; supports complex queries | Must be overwritten atomically (backup + write pattern) |
| `right` join with metadata | Ensures all installed meters appear in report (even with no data) | Missing data → 0% completeness (correct behavior) |
| Category UDF | Simple Python logic | Minor overhead vs native Spark; acceptable for aggregated data |
| Azure Blob for CSV export | Stakeholders access reports via Azure portal | Requires account key management |
| 24+N hour deadline formula | Standardized across measurement times | Slightly lenient for early-morning measurements |

---

## Interview Talking Points (2-minute explanation)

> "I built the SLA monitoring pipeline that tracks data completeness for 4M+ smart meters across 14 vendors. The system computes per-device compliance at six time thresholds (7h through 24h) and generates both real-time metrics (Cassandra) and stakeholder reports (Azure Blob CSV).
>
> The pipeline runs in three stages: SBD computes same-day completeness by checking if each reading's receive time falls within the deadline window. ODR tracks month-to-date cumulative completeness using incremental file discovery with LRP tracking — so it only processes new data since the last run. Blob generates per-vendor CSV reports and categorizes devices into completeness buckets for KPI dashboards.
>
> The key technical challenge was handling the scale: 14 vendors × 2 profiles × 30 days × millions of devices. I optimized with broadcast joins for metadata, incremental processing via LRP, and explicit persist/unpersist for memory management."

---

## Common Follow-up Questions

1. **"Why 6 different time thresholds?"** → Different SLA contracts specify different deadlines. Some utilities require 8h delivery, others allow 24h. Computing all windows in one pass avoids re-running for each contract.

2. **"How do you handle devices that report no data?"** → The `right` join with metadata ensures every installed device appears in the result. If no readings match, all flags are 0, giving 0% completeness.

3. **"What's the backup pattern for LRP?"** → Before overwriting `last_read_path.parquet`, we copy it to `bkp_last_read_path.parquet` using `hadoop fs -cp`. If the write fails, the backup can be restored.

4. **"How do you avoid counting the same data twice in ODR?"** → LRP tracking ensures each file is processed only once across all runs in the month. The merge uses `unionByName` + `groupBy` with `sum(total_count)` to accumulate.

5. **"What triggers the pipeline?"** → Cron-scheduled shell script runs 2 days after data date (to allow late-arriving data). Vendors run sequentially: SBD first, then ODR, then Blob runs once for all vendors.

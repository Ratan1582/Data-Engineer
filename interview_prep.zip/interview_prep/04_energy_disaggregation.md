# Energy Disaggregation ML Pipeline

## Problem Statement and Business Context

Smart meters report total household energy consumption, but utilities and consumers want to know **which appliances** consume how much. Energy disaggregation (Non-Intrusive Load Monitoring / NILM) breaks down total consumption into appliance-level estimates without requiring sub-meters on each device.

**Business Need:**
- Provide appliance-level energy breakdown (Fridge, Washing Machine, Geyser, Night Base Load, Others) to consumers via a mobile app
- Enable demand-side management and targeted energy-saving recommendations
- Process disaggregation at scale across **4M+ smart meters** daily
- Support multiple meter frequencies (15-min and 30-min intervals) across vendors

**Technical Challenge:** Running PyTorch CNN inference at scale on a Spark cluster, where each device needs its own time-series window processed through the model.

---

## Architecture

```mermaid
flowchart TD
    subgraph input [Input Data]
        HDFS["HDFS Parquet\n/SM/{Vendor}/BLOCK/{Date}"]
        MongoDB["MongoDB\nDeviceMetaData_{Vendor}"]
    end

    subgraph preprocessing [Preprocessing]
        Parse["Parse Raw Data\n(Extract active energy)"]
        ActivePower["Compute Active Power\n(Energy × 60/frequency)"]
        DiffPower["Compute Power Diff\n(lag window)"]
        SeqWindow["Sequence Windowing\n(seq2point, length=7)"]
    end

    subgraph model [PyTorch Model Inference]
        Broadcast["Broadcast Model\n(to all executors)"]
        PandasUDF["pandas_udf\n(batch inference)"]
        CNN["1D CNN Model\n(Conv1d → FC → Output)"]
    end

    subgraph postprocessing [Post-processing]
        Unscale["Unscale Predictions\n(× std + mean)"]
        Clip["Clip Negatives & Cap\n(0 ≤ pred ≤ total)"]
        NightLoad["Night Base Load\n(12AM-5AM)"]
        Excess["Remove Excess\n(proportional scaling)"]
        Format["Format Output\n(kWh, dates, vendor)"]
    end

    subgraph output [Output]
        CSV["HDFS CSV\n(per-date results)"]
        Cassandra["Cassandra\n(disaggregation_model table)"]
    end

    HDFS --> Parse
    MongoDB --> Parse
    Parse --> ActivePower --> DiffPower --> SeqWindow
    SeqWindow --> PandasUDF
    Broadcast --> PandasUDF
    CNN --> Broadcast
    PandasUDF --> Unscale --> Clip --> NightLoad --> Excess --> Format
    Format --> CSV
    Format --> Cassandra
```

---

## Tech Stack and Why Each Was Chosen

| Technology | Role | Why |
|---|---|---|
| **PyTorch** | CNN model definition and inference | Flexible model architecture; supports CPU-only inference on Spark executors |
| **PySpark pandas_udf** | Distributed model inference | Vectorized UDF enables batch inference per partition without data serialization overhead |
| **SparkContext.broadcast** | Model distribution | Broadcast model weights to all executors once, avoiding repeated deserialization |
| **1D CNN (Conv1d)** | Sequence-to-point architecture | Proven effective for NILM; captures temporal patterns in power consumption |
| **MongoDB (Spark connector)** | Device metadata | Filter installed devices, get installation dates for temporal context |
| **HDFS** | Input/output storage | Block profile data already on HDFS; results written as CSV/Parquet |

---

## Data Flow (End-to-End)

### 1. Data Ingestion
- Read BLOCK profile Parquet from HDFS (15/30 min intervals)
- Fetch device metadata from MongoDB (installed devices only, filtered by installation date)
- Join telemetry with metadata via broadcast join

### 2. Preprocessing Pipeline
1. **Parse:** Extract IMEI, Timestamp, Register values from nested Parquet structure
2. **Filter:** Keep only active energy import register (`1-0.1.29.0.255`)
3. **Convert units:** Vendors reporting in kWh → multiply by 1000 to get Wh
4. **Active Power:** `Energy × (60/frequency)` converts Wh to instantaneous W
5. **Power Difference:** `lag(Active Power)` over device window — captures power transitions

### 3. Sequence Windowing (seq2point)
For each device:
1. Pad start/end with zeros (half-window on each side)
2. Fill missing intervals with zeros
3. Create sliding windows of length 7 (the sequence)
4. Compute auxiliary features: window mean, std, max, min

### 4. Model Inference
1. Load pre-trained PyTorch model weights
2. Broadcast model to all Spark executors
3. Apply `pandas_udf` that:
   - Converts sequence arrays to tensors
   - Runs forward pass through CNN
   - Returns scalar predictions

### 5. Post-processing
1. **Unscale:** Reverse standardization (prediction × std + mean)
2. **Clip:** Set negative predictions to 0; cap at total active power
3. **Night base load:** Aggregate 12AM-5AM predictions separately
4. **Excess removal:** If sum of appliances > total, proportionally scale down
5. **Format:** Convert Wh to kWh, add date fields, join vendor info

---

## Key Code Snippets with Explanations

### PyTorch CNN Model Architecture

```python
class Model(nn.Module):
    def __init__(self, sequence_length):
        super(Model, self).__init__()
        self.seq_length = sequence_length
        self.conv = nn.Sequential(
            nn.Conv1d(1, 32, 3, stride=1),   # 1→32 channels, kernel=3
            nn.ReLU(True),
            nn.Conv1d(32, 64, 2, stride=1),  # 32→64 channels, kernel=2
            nn.ReLU(True),
            nn.Conv1d(64, 64, 1, stride=1),  # 64→64 channels, kernel=1
            nn.ReLU(True)
        )
        # Auxiliary features (mean, std, max, min of window)
        self.fc_aux = nn.Linear(in_features=4, out_features=4)
        # Concatenate conv output + aux features → final prediction
        self.dense = nn.Sequential(
            nn.Linear(64 * (sequence_length - 3) + 4, 128),
            nn.ReLU(True),
            nn.Linear(128, 1)
        )
    
    def forward(self, x, x_aux):
        x = self.conv(x)                    # [batch, 64, seq_len-3]
        x = x.view(-1, 64 * (self.seq_length - 3))  # flatten
        x_aux = F.relu(self.fc_aux(x_aux))  # [batch, 4]
        x_combined = torch.cat((x, x_aux), dim=1)
        x = self.dense(x_combined)
        return x.view(-1, 1)
```

**Architecture explanation:**
- **3 Conv1d layers** progressively extract temporal features from the power sequence
- **Kernel sizes (3, 2, 1)** capture different temporal granularities
- **Auxiliary branch** adds statistical context (mean, std, max, min) that helps the model understand the overall power level
- **Concatenation** merges temporal features with statistical features for final prediction
- **Output:** Single value — the predicted appliance power at the midpoint of the window

### Broadcasting Model to Executors

```python
def predict(self, df, spark, model_weights):
    model = Model(self.sequence_length)
    checkpoint = torch.load(model_weights, map_location=device, weights_only=False)
    model.load_state_dict(checkpoint['model_state_dict'])
    model.eval()
    
    # Broadcast model to all executors (serialized once, shared in memory)
    Disaggregate.model_broadcast = spark.sparkContext.broadcast(model)
    
    predict_udf = self.create_predict_udf(Disaggregate.model_broadcast, self.sequence_length)
    predict_df = df.withColumn("predictions", predict_udf(df["grouped_power"], df["x_aux"]))
    return predict_df
```

**Why broadcast:** Without broadcasting, each executor would need to load model weights from disk for every partition. Broadcasting sends the model once to each executor's memory, amortizing the cost across all partitions.

### pandas_udf for Batch Inference

```python
@staticmethod
def create_predict_udf(model_broadcast, seq_len):
    @pandas_udf(DoubleType())
    def predict_udf(data_batch, aux_batch):
        # Convert Pandas Series of lists to numpy arrays
        input_data = np.array(data_batch.tolist(), dtype=np.float32).reshape(-1, 1, seq_len)
        aux_data = np.array(aux_batch.tolist(), dtype=np.float32).reshape(-1, 4)
        
        # Get broadcasted model
        model = model_broadcast.value
        model.to(device)
        
        # Batch inference (no gradient computation needed)
        with torch.no_grad():
            predictions = model(
                torch.tensor(input_data, device=device),
                torch.tensor(aux_data, device=device)
            ).cpu().numpy().flatten()
        
        return pd.Series(predictions)
    return predict_udf
```

**Why pandas_udf over regular UDF:**
- **Vectorized:** Processes entire column batches (Arrow-based), not row-by-row
- **Batch inference:** PyTorch is optimized for batch operations; processing 1000 samples at once is 100x faster than one-by-one
- **Zero-copy:** Arrow serialization avoids Python object overhead

### Sequence-to-Point Window Creation

```python
def seq2point_window_maker(self, df):
    def add_rows(key, pdf):
        """Pad timeline with zeros at boundaries and fill gaps."""
        pdf = pdf.drop_duplicates(subset=['Timestamp']).set_index('Timestamp')
        
        # Extend timeline by half-window on each side
        new_start = pdf.index.min() - pd.Timedelta(minutes=sequence_length // 2 * frequency)
        new_end = pdf.index.max() + pd.Timedelta(minutes=sequence_length // 2 * frequency)
        new_indexes = pd.date_range(new_start, new_end, freq=f'{frequency}T')
        
        # Reindex fills gaps with 0
        result = pdf.reindex(new_indexes, fill_value=0).reset_index()
        return result

    # Apply padding per device using applyInPandas
    processed_df = appliance_df.groupby("device").applyInPandas(add_rows, schema=...)

    # Create sliding window using Spark window functions
    window_spec = Window.partitionBy("device").orderBy("Timestamp").rowsBetween(
        Window.currentRow, Window.currentRow + self.sequence_length - 1
    )
    sequence_df = processed_df.withColumn(
        "grouped_power", SF.collect_list("Active Power Diff (W)").over(window_spec)
    ).filter(SF.size(col("grouped_power")) == self.sequence_length)

    # Compute auxiliary features from window
    sequence_df = sequence_df.withColumn("x_mean", SF.expr(
        "aggregate(grouped_power, 0D, (acc, x) -> acc + x) / size(grouped_power)"
    ))
    sequence_df = sequence_df.withColumn("x_std", SF.expr(
        "sqrt(aggregate(grouped_power, 0D, (acc, x) -> acc + pow(x - x_mean, 2)) / size(grouped_power))"
    ))
```

**Key design:**
- **applyInPandas for padding:** Timeline manipulation (reindex, fill gaps) is natural in Pandas
- **Spark window for sliding sequence:** `collect_list` with row range creates overlapping windows efficiently
- **Spark SQL `aggregate`:** Computes mean/std without UDF overhead (runs in JVM)

### Excess Disaggregation Correction

```python
def remove_excess_disaggregation(self, df):
    """If sum of predicted appliances > total consumption, scale proportionally."""
    result = df.withColumn("Fridge",
        when(df["current_sum"] > df["mains_consumption"],
             (df["Fridge"] / df["current_sum"]) * df["mains_consumption"])
        .otherwise(df["Fridge"])
    )
    # Same for Geyser, WM, night_base_load, otr (others)
    ...
```

**Why proportional scaling:** The model predicts each appliance independently. Their sum can exceed total consumption (physically impossible). Proportional scaling preserves relative proportions while ensuring conservation of energy.

---

## Scale, Performance, and Optimization

| Metric | Value |
|---|---|
| Devices processed | Up to 4M+ (vendor-parallel execution) |
| Appliances disaggregated | 3 (Fridge, Washing Machine, Geyser) + Night Base Load + Others |
| Model architecture | 1D CNN (3 conv layers + 2 FC layers) |
| Sequence length | 7 time steps |
| Supported frequencies | 15-min and 30-min intervals |
| Executor memory | 8 GB (accommodates model + batch data) |
| Spark configs | KryoSerializer, 400 shuffle partitions, 2-5 dynamic executors |

**Optimization techniques:**
1. **Broadcast model** — Single model copy shared across all executors
2. **pandas_udf** — Batch inference (vectorized, Arrow-based)
3. **`torch.no_grad()`** — Disables gradient tracking for inference (50% memory saving)
4. **`applyInPandas` for padding** — Per-device work stays in Pandas where it's natural
5. **Spark window functions for sequences** — `collect_list` over row range avoids Python shuffles
6. **Persist after preprocessing** — Avoids recomputing windowed sequences for each appliance

---

## Design Decisions and Trade-offs

| Decision | Reasoning | Trade-off |
|---|---|---|
| Separate model per appliance | Each appliance has different consumption patterns | 3x inference cost; but models are small (< 1MB each) |
| Sequence length = 7 | Captures 30-min to 3.5-hour patterns depending on frequency | Short context; but longer sequences increase compute quadratically |
| Power difference as input | Captures transitions (on/off events) better than absolute power | Loses baseline level info; compensated by auxiliary features |
| Broadcasting model state | Avoids per-partition model loading | Model must fit in broadcast variable (< 1 GB); our models are < 1 MB |
| Proportional excess removal | Maintains relative appliance proportions | May underestimate dominant appliance |
| Per-device padding in Pandas | Timeline manipulation complex in pure Spark | Requires shuffle to group by device |

---

## Interview Talking Points (2-minute explanation)

> "I implemented the energy disaggregation pipeline that breaks down total smart meter consumption into appliance-level estimates for 4M+ meters. The core ML model is a 1D CNN trained on labeled NILM datasets, deployed via Spark's pandas_udf for distributed inference.
>
> The key technical challenge was running PyTorch inference at scale on Spark. I solved this by broadcasting the model weights to all executors and using pandas_udf for vectorized batch inference — processing thousands of windows simultaneously rather than one-by-one.
>
> The preprocessing creates sliding windows of power differences using Spark window functions, with per-device timeline padding via applyInPandas. Post-processing includes unscaling predictions, clipping to physical bounds, computing night base load, and proportional scaling to ensure appliance estimates never exceed total consumption.
>
> The pipeline runs per-vendor on YARN with separate models for Fridge, Washing Machine, and Geyser, each with their own pre-trained weights distributed via SparkContext.broadcast."

---

## Common Follow-up Questions

1. **"How accurate is the disaggregation?"** → Accuracy varies by appliance: Fridge ~85% (consistent pattern), Geyser ~75% (seasonal), WM ~70% (irregular usage). We validate against sub-metered test homes.

2. **"Why CNN over LSTM/Transformer?"** → 1D CNN is faster for inference (no sequential dependency), works well for fixed-length windows, and our experiments showed comparable accuracy to LSTM for NILM with 10x faster inference.

3. **"How do you handle missing data?"** → `reindex()` fills gaps with zeros. The model is trained on data that includes zeros, so it learned to handle inactivity periods. Critical gaps (>2 hours) are flagged in post-processing.

4. **"Could this run in real-time (streaming)?"** → Current design is batch (daily). For streaming: replace window creation with Spark Structured Streaming's sliding window, and use TorchServe for model serving. The model itself supports single-sample inference.

5. **"Why not use Spark ML Pipeline instead of PyTorch?"** → Spark ML doesn't support custom CNN architectures. Our model was trained in PyTorch by the data science team; the engineering challenge was deploying it at scale, which pandas_udf solves elegantly.

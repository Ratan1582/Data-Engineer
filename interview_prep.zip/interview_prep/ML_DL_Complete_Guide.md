# Machine Learning & Deep Learning: Complete Guide from Beginner to Expert

---

# SECTION 1: FOUNDATION

---

## 1.1 What is Artificial Intelligence (AI)?

AI is the broad idea of making machines do things that would normally require human intelligence.

**Analogy**: Imagine you're teaching a dog tricks. The dog doesn't "understand" language, but through repeated training (treats for correct behavior, correction for wrong behavior), it learns to sit, shake, and roll over. AI is similar -- we don't program every rule explicitly; instead, we create systems that learn from experience.

```
AI (Artificial Intelligence)
├── Rule-Based Systems    ──> "If temperature > 100, turn on fan"  (hard-coded rules)
├── Machine Learning      ──> "Learn from data which temperature patterns need the fan"
│   ├── Classical ML      ──> Works on structured/tabular data
│   └── Deep Learning     ──> Works on images, text, audio, complex patterns
└── Other branches        ──> Robotics, Expert Systems, NLP, Computer Vision
```

**Real-world examples of AI**:
- Google Maps finding the fastest route
- Spam filters in your email
- Siri/Alexa understanding your voice
- Self-driving cars
- Chess-playing computers

---

## 1.2 What is Machine Learning (ML)?

Machine Learning is a **subset of AI** where the system learns patterns from data instead of being explicitly programmed with rules.

**Analogy**: Think about how you learned to recognize cats as a child. Nobody gave you a rulebook that said "if it has pointy ears AND whiskers AND a tail AND fur, it's a cat." Instead, your parents showed you hundreds of cats, and your brain automatically figured out the pattern. ML works the same way.

**Traditional Programming vs Machine Learning**:

```
Traditional Programming:
    INPUT (Data) + RULES (Program) ──────> OUTPUT (Result)
    Example: "If email contains 'lottery winner', mark as spam"

Machine Learning:
    INPUT (Data) + OUTPUT (Examples) ─────> RULES (Model)
    Example: "Here are 10,000 emails labeled spam/not-spam. Learn the pattern."
```

### Types of Machine Learning

```
Machine Learning
├── Supervised Learning      ──> You have labeled data (input + correct answer)
│   ├── Classification       ──> Predict a category (spam/not-spam, cat/dog)
│   └── Regression           ──> Predict a number (house price, temperature)
│
├── Unsupervised Learning    ──> You only have input data (no labels)
│   ├── Clustering           ──> Group similar items (customer segments)
│   └── Dimensionality Reduction ──> Compress features (PCA)
│
├── Semi-Supervised Learning ──> Small amount of labeled + large unlabeled data
│
└── Reinforcement Learning   ──> Agent learns by trial-and-error with rewards
    Example: Game-playing AI, Robot navigation
```

**Supervised Learning Analogy**: A teacher gives you practice problems WITH answer keys. You study the problems, check your answers, and learn from mistakes. At exam time, you solve new problems.

**Unsupervised Learning Analogy**: You're given a pile of 1000 photos with no labels. You naturally group them -- "these look like beach photos," "these are city photos," "these are food photos." Nobody told you the categories; you discovered them yourself.

**Reinforcement Learning Analogy**: A baby learning to walk. Nobody teaches exact muscle movements. The baby tries, falls (negative reward), tries again, takes a step (positive reward), and gradually improves.

---

## 1.3 What is Deep Learning (DL)?

Deep Learning is a **subset of Machine Learning** that uses neural networks with many layers (hence "deep") to learn increasingly complex patterns.

```
AI ⊃ Machine Learning ⊃ Deep Learning

       ┌──────────────────────────────────┐
       │           AI                      │
       │   ┌──────────────────────────┐   │
       │   │    Machine Learning       │   │
       │   │   ┌──────────────────┐   │   │
       │   │   │  Deep Learning    │   │   │
       │   │   │  (Neural Nets)    │   │   │
       │   │   └──────────────────┘   │   │
       │   └──────────────────────────┘   │
       └──────────────────────────────────┘
```

**Why "Deep"?**

```
Shallow Network:   Input ──> [Hidden Layer] ──> Output

Deep Network:      Input ──> [Layer 1] ──> [Layer 2] ──> [Layer 3] ──> ... ──> [Layer N] ──> Output
                              (edges)      (shapes)      (parts)               (objects)
```

Each layer learns progressively more abstract features:
- Layer 1: Detects edges and simple patterns
- Layer 2: Combines edges into shapes (circles, lines)
- Layer 3: Combines shapes into parts (eyes, ears, wheels)
- Layer N: Combines parts into objects (cat, car, face)

**When to use Classical ML vs Deep Learning**:

| Scenario | Classical ML | Deep Learning |
|----------|-------------|---------------|
| Tabular data (spreadsheets) | Best choice | Overkill |
| Small dataset (< 10K rows) | Best choice | Not enough data |
| Images, Video | Poor | Best choice |
| Text, NLP | Decent | Best choice |
| Audio, Speech | Decent | Best choice |
| Interpretability needed | Better | Black box |
| Limited compute | Works fine | Needs GPU |
| Large dataset (millions+) | Good | Excellent |

---

## 1.4 How Data Flows Through an ML System

```
Step 1: RAW DATA
    "I have 100,000 house sale records with price, area, bedrooms, location..."

        │
        ▼

Step 2: DATA CLEANING
    - Remove duplicates
    - Handle missing values (fill or remove)
    - Fix data types
    - Remove outliers

        │
        ▼

Step 3: FEATURE ENGINEERING
    - Select relevant columns
    - Create new features (e.g., price_per_sqft = price / area)
    - Encode categories (e.g., location "Mumbai" → 1, "Delhi" → 2)
    - Scale numbers to similar ranges

        │
        ▼

Step 4: SPLIT DATA
    ┌──────────────────────────────────────────────┐
    │  Training Set (70-80%)  │  Test Set (20-30%)  │
    │  Model learns from this │  Final evaluation   │
    └──────────────────────────────────────────────┘

        │
        ▼

Step 5: MODEL TRAINING
    The model sees training data thousands of times,
    adjusting its internal parameters to minimize errors.

        │
        ▼

Step 6: EVALUATION
    Test the model on data it has NEVER seen.
    Compute metrics: accuracy, error, etc.

        │
        ▼

Step 7: DEPLOYMENT
    Put the model into production (API, app, pipeline)

        │
        ▼

Step 8: MONITORING
    Watch for performance degradation over time
    Retrain when needed
```

---

### Section 1 Summary

| Concept | Definition | Example |
|---------|-----------|---------|
| AI | Machines mimicking human intelligence | Google Translate |
| ML | Systems that learn from data | Email spam filter |
| DL | Neural networks with many layers | Face recognition |
| Supervised | Learn from labeled examples | Predicting house prices |
| Unsupervised | Find patterns in unlabeled data | Customer segmentation |
| Reinforcement | Learn from rewards/penalties | Game-playing AI |

### Section 1 Interview Questions

1. **Q: What is the difference between AI, ML, and DL?**
   A: AI is the broadest field of making intelligent machines. ML is a subset where machines learn from data. DL is a further subset using deep neural networks.

2. **Q: When would you choose ML over DL?**
   A: When you have structured/tabular data, small datasets, limited compute, or need interpretability.

3. **Q: What are the three types of ML?**
   A: Supervised (labeled data), Unsupervised (no labels), Reinforcement (reward-based learning).

4. **Q: Give an example of each ML type.**
   A: Supervised: spam detection. Unsupervised: customer clustering. Reinforcement: robot navigation.

---

# SECTION 2: HOW MACHINE LEARNING WORKS

---

## 2.1 What is Training?

Training is the process where a model looks at data, makes predictions, checks how wrong it is, and adjusts itself to be less wrong next time. This cycle repeats thousands of times.

**Analogy**: Imagine learning to throw darts at a bullseye:
1. You throw a dart (make a prediction)
2. You see where it lands (compare to the target)
3. You calculate how far off you were (compute the error/loss)
4. You adjust your aim (update your parameters)
5. You throw again (next iteration)
6. After hundreds of throws, you consistently hit near the center

```
Training Loop:

    ┌──────────────────────────────────────────────┐
    │                                               │
    │   Data ──> Model ──> Prediction               │
    │                         │                     │
    │                         ▼                     │
    │              Compare with True Answer          │
    │                         │                     │
    │                         ▼                     │
    │                  Compute Error (Loss)          │
    │                         │                     │
    │                         ▼                     │
    │              Adjust Model Parameters           │
    │                         │                     │
    │                         ▼                     │
    │              ◄───── Repeat ──────►            │
    │                                               │
    └──────────────────────────────────────────────┘
```

---

## 2.2 Inputs, Outputs, Labels, and Predictions

Let's use a concrete example: **Predicting house prices**.

```
DATASET:
┌───────────┬──────────┬───────────┬─────────┬──────────────┐
│ Area(sqft)│ Bedrooms │ Location  │   Age   │ Price (₹ Cr) │
├───────────┼──────────┼───────────┼─────────┼──────────────┤
│   1200    │    2     │  Mumbai   │    5    │     1.5      │  ◄── Row 1
│   1800    │    3     │  Delhi    │    2    │     2.1      │  ◄── Row 2
│   2500    │    4     │  Mumbai   │   10    │     3.0      │  ◄── Row 3
│    800    │    1     │  Pune     │    1    │     0.6      │  ◄── Row 4
└───────────┴──────────┴───────────┴─────────┴──────────────┘

INPUTS (Features/X):                    LABELS (Target/y):
  Area, Bedrooms, Location, Age     →     Price

TERMINOLOGY:
  - Each ROW = one "sample" or "example" or "data point"
  - Each COLUMN (except target) = one "feature" or "input variable"
  - The PRICE column = "label" or "target" or "ground truth"
  - What the model outputs = "prediction" or "ŷ" (y-hat)
```

**Mathematically**:
- **X** = input matrix (all features) → shape: [n_samples, n_features]
- **y** = label vector (true answers) → shape: [n_samples]
- **ŷ** (y-hat) = prediction vector → shape: [n_samples]

```
For Row 1:
    X₁ = [1200, 2, "Mumbai", 5]    (input features)
    y₁ = 1.5                         (true price)
    ŷ₁ = model([1200, 2, "Mumbai", 5]) = 1.4   (prediction)
    error₁ = |1.5 - 1.4| = 0.1      (how wrong we were)
```

---

## 2.3 What is Loss / Error?

**Loss** (also called cost or error) is a single number that measures how bad the model's predictions are. The goal of training is to **minimize** this number.

**Analogy**: Loss is like your exam score, but inverted. A high loss means you did poorly. A low loss means you did well. Training is like studying to reduce your "error score."

### Common Loss Functions

**For Regression (predicting numbers)**:

```
Mean Squared Error (MSE):
    Loss = (1/n) × Σ(yᵢ - ŷᵢ)²

    Example with 3 houses:
    True prices:  [1.5, 2.1, 3.0]
    Predictions:  [1.4, 2.5, 2.8]
    Errors:       [0.1, -0.4, 0.2]
    Squared:      [0.01, 0.16, 0.04]
    MSE = (0.01 + 0.16 + 0.04) / 3 = 0.07

Mean Absolute Error (MAE):
    Loss = (1/n) × Σ|yᵢ - ŷᵢ|

    Using same example:
    Absolute errors: [0.1, 0.4, 0.2]
    MAE = (0.1 + 0.4 + 0.2) / 3 = 0.233
```

**Why squared in MSE?** Squaring does two things: (1) makes all errors positive, and (2) penalizes large errors much more than small ones. An error of 2 contributes 4 to the loss, while an error of 1 only contributes 1.

**For Classification (predicting categories)**:

```
Binary Cross-Entropy (for 2 classes):
    Loss = -(1/n) × Σ[yᵢ × log(ŷᵢ) + (1-yᵢ) × log(1-ŷᵢ)]

    Example: Email spam detection
    True labels:    [1,    0,    1,    0   ]  (1=spam, 0=not-spam)
    Predictions:    [0.9,  0.1,  0.7,  0.3 ]  (probability of spam)

    When true=1 and pred=0.9:  -log(0.9) = 0.105  (low loss, good!)
    When true=1 and pred=0.1:  -log(0.1) = 2.302  (high loss, bad!)
    When true=0 and pred=0.1:  -log(0.9) = 0.105  (low loss, good!)
```

---

## 2.4 What is Optimization?

Optimization is the process of **finding the best model parameters** (weights) that minimize the loss function.

**Analogy**: You're blindfolded on a hilly landscape and need to find the lowest valley. You can only feel the slope under your feet. Strategy: always take a step in the downhill direction. Eventually, you reach a valley (minimum loss).

```
Loss Landscape (imagine a 2D cross-section):

    Loss
    ▲
    │    *
    │   * *
    │  *   *           *
    │ *     *         * *
    │*       *       *   *
    │         *     *     *
    │          *   *       *
    │           * *         *
    │            *  ◄── Global minimum (best possible parameters)
    │
    └──────────────────────────────► Parameter value
```

---

## 2.5 What is Gradient Descent?

Gradient Descent is the **specific algorithm** used for optimization. It uses calculus (derivatives) to figure out which direction is "downhill."

### Intuitive Explanation

```
Step 1: Start with random parameter values (random position on the hill)

Step 2: Compute the GRADIENT (slope) at the current position
        - Gradient = derivative of Loss with respect to parameter
        - The gradient tells you: "if you increase this parameter slightly,
          the loss goes up by THIS much"
        - Negative gradient means: increasing the parameter REDUCES loss

Step 3: Update the parameter:
        new_parameter = old_parameter - learning_rate × gradient

Step 4: Repeat from Step 2

        The "-" sign means: go in the OPPOSITE direction of the gradient
        (move downhill, not uphill)
```

### Mathematical Explanation (Simple Linear Example)

Suppose we have the simplest model: `ŷ = w × x` (predicting y as a multiple of x)

```
Our model:        ŷ = w × x        (w is the parameter we want to learn)
Our loss:         L = (y - ŷ)²     (for one sample, using MSE)
Substitute:       L = (y - w×x)²

To find the gradient:
    dL/dw = 2(y - w×x) × (-x)
          = -2x(y - w×x)

Update rule:
    w_new = w_old - α × dL/dw
    w_new = w_old - α × [-2x(y - w×x)]
    w_new = w_old + 2α × x × (y - w×x)
                                  ▲
                                  │
                           This is the error (y - prediction)
```

Where **α (alpha)** is the **learning rate** -- how big a step we take each time.

### Visual Walkthrough

```
Iteration 1:  w = 5.0 (random start)
              Data: x=2, y=6  (true relationship: y = 3x)
              ŷ = 5.0 × 2 = 10
              Error = 6 - 10 = -4
              Gradient = -2 × 2 × (-4) = 16
              w_new = 5.0 - 0.01 × 16 = 4.84     (moved toward 3.0)

Iteration 2:  w = 4.84
              ŷ = 4.84 × 2 = 9.68
              Error = 6 - 9.68 = -3.68
              Gradient = -2 × 2 × (-3.68) = 14.72
              w_new = 4.84 - 0.01 × 14.72 = 4.69  (getting closer)

...after many iterations...

Iteration N:  w ≈ 3.0   ──> ŷ = 3.0 × 2 = 6.0  ──> Error ≈ 0  ✓
```

### Learning Rate: Why It Matters

```
Learning Rate TOO LARGE (α = 1.0):
    Step is so big you OVERSHOOT the minimum, bouncing back and forth
    Loss: 100 → 95 → 120 → 80 → 150 → DIVERGES!

    *                               *
     *                             *
      *         ←── bouncing ──► *
       *       *               *
        *     *               *
         * * *

Learning Rate TOO SMALL (α = 0.00001):
    Steps are tiny. Takes forever to converge.
    Loss: 100 → 99.99 → 99.98 → 99.97 → ... (1 million epochs later) ... → 0.01

Learning Rate JUST RIGHT (α = 0.001):
    Steady, smooth convergence.
    Loss: 100 → 85 → 60 → 35 → 15 → 5 → 1 → 0.2 → 0.05
```

### Types of Gradient Descent

```
1. BATCH Gradient Descent:
   - Uses ALL training data to compute one gradient update
   - Slow for large datasets, but smooth convergence
   - 10,000 samples → compute loss on all 10,000 → one update

2. STOCHASTIC Gradient Descent (SGD):
   - Uses ONE random sample per update
   - Very noisy (loss jumps around) but fast
   - 10,000 samples → 10,000 individual updates per epoch

3. MINI-BATCH Gradient Descent (Most Common):
   - Uses a small batch (32, 64, 128 samples) per update
   - Best of both worlds: reasonably smooth + fast
   - 10,000 samples, batch=32 → 312 updates per epoch
```

---

## 2.6 Epochs, Batches, and Iterations

These three terms describe how the training loop is organized.

```
DATASET: 10,000 training samples
BATCH SIZE: 100

One ITERATION = process one batch (100 samples)
    → Forward pass: compute predictions for 100 samples
    → Compute loss for those 100 samples
    → Backward pass: compute gradients
    → Update weights

One EPOCH = one complete pass through ALL training data
    → 10,000 / 100 = 100 iterations per epoch

TOTAL TRAINING = multiple epochs (say 30)
    → 30 epochs × 100 iterations = 3,000 total weight updates
```

**Visual Timeline**:

```
Epoch 1: [Batch 1][Batch 2][Batch 3]...[Batch 100]  ──> Loss: 2.5
Epoch 2: [Batch 1][Batch 2][Batch 3]...[Batch 100]  ──> Loss: 1.8
Epoch 3: [Batch 1][Batch 2][Batch 3]...[Batch 100]  ──> Loss: 1.2
...
Epoch 30: [Batch 1][Batch 2][Batch 3]...[Batch 100] ──> Loss: 0.05
```

**Why not just 1 epoch?** One pass through the data isn't enough. Each epoch, the model's parameters are slightly different, so it "sees" the data from a new perspective. It's like re-reading a textbook -- you understand more each time.

**Why not infinite epochs?** After a point, the model starts memorizing the training data instead of learning patterns. This is called **overfitting** (covered in Section 9).

---

### Section 2 Summary & Cheat Sheet

```
TRAINING CHEAT SHEET:
┌────────────────────────────────────────────────────┐
│ Training = repeatedly: predict → compute loss →     │
│            compute gradient → update parameters     │
│                                                     │
│ Loss = how wrong the predictions are (minimize it)  │
│ Gradient = direction of steepest increase in loss   │
│ Gradient Descent = move opposite to gradient        │
│ Learning Rate = step size (too big = overshoot,     │
│                            too small = too slow)    │
│                                                     │
│ Epoch = one pass through entire dataset             │
│ Batch = subset of data processed together           │
│ Iteration = one weight update (one batch)           │
│                                                     │
│ MSE = mean of squared errors (regression)           │
│ Cross-Entropy = log-based loss (classification)     │
│                                                     │
│ w_new = w_old - learning_rate × gradient            │
└────────────────────────────────────────────────────┘
```

### Section 2 Interview Questions

1. **Q: What is gradient descent? Explain intuitively.**
   A: It's an optimization algorithm that iteratively adjusts parameters by moving in the direction opposite to the gradient (steepest descent) to minimize the loss function. Like finding the lowest point in a valley while blindfolded.

2. **Q: What happens if the learning rate is too high?**
   A: The model overshoots the minimum, causing the loss to oscillate or even diverge.

3. **Q: Difference between epoch, batch, and iteration?**
   A: An epoch is one full pass through the dataset. A batch is a subset processed together. An iteration is one weight update (one batch processed).

4. **Q: Why do we use mini-batch gradient descent instead of full batch?**
   A: Full batch is too slow for large datasets. SGD is too noisy. Mini-batch balances speed and stability.

5. **Q: What is the difference between MSE and MAE?**
   A: MSE squares errors (penalizes large errors more, differentiable everywhere). MAE uses absolute values (robust to outliers, not differentiable at 0).

---

# SECTION 3: FEATURES

---

## 3.1 What Are Features?

Features are the **individual measurable properties** of your data that the model uses to make predictions. They are the columns in your dataset (excluding the target).

**Analogy**: When you're buying a phone, what "features" do you consider? RAM, camera quality, battery life, price, brand. Each of these is a measurable property that helps you make a decision. ML models work the same way -- they look at features to make predictions.

```
House Price Dataset:
┌─────────────────────────────────────────────────────────┐
│  FEATURES (inputs the model uses)        │  TARGET      │
├────────┬──────────┬──────────┬───────────┤──────────────┤
│ Area   │ Bedrooms │ Location │ Age       │ Price        │
│ (sqft) │ (count)  │ (city)   │ (years)   │ (₹ Crore)   │
├────────┼──────────┼──────────┼───────────┼──────────────┤
│  1200  │    2     │  Mumbai  │    5      │    1.5       │
│  1800  │    3     │  Delhi   │    2      │    2.1       │
└────────┴──────────┴──────────┴───────────┴──────────────┘
    ▲         ▲          ▲          ▲            ▲
 Feature 1  Feature 2  Feature 3  Feature 4    Label
(Numerical) (Numerical)(Categorical)(Numerical)
```

---

## 3.2 Why Features Matter

**The quality of your features determines the ceiling of your model's performance.** No matter how sophisticated your algorithm, if the features are garbage, the predictions will be garbage. This is often called **"Garbage In, Garbage Out."**

```
Scenario: Predict if a student will pass an exam

GOOD FEATURES:                          BAD FEATURES:
- Hours studied                         - Student's shoe size
- Attendance percentage                 - Favorite color
- Previous test scores                  - Number of pets
- Number of practice problems solved    - Distance from equator

With good features:  Even a simple model gets 90% accuracy
With bad features:   Even a complex model gets 50% (random guessing)
```

**The hierarchy of impact**:

```
Impact on Model Performance:

    Better DATA           ████████████████████████████  (highest impact)
    Better FEATURES       ██████████████████████
    More DATA             ███████████████
    Better MODEL          ████████████
    Better HYPERPARAMETERS████████
    Fancier TRICKS        ███
```

---

## 3.3 Good Features vs Bad Features

```
GOOD FEATURE properties:
  ✓ Correlated with the target (area IS related to house price)
  ✓ Available at prediction time (you KNOW the area before predicting price)
  ✓ Not redundant with other features (don't include both area_sqft AND area_sqm)
  ✓ Sufficient variation (if all houses have 2 bedrooms, that feature is useless)
  ✓ Not leaking the target (including "final_price" as a feature to predict price)

BAD FEATURE properties:
  ✗ No correlation with target (wall color vs house price)
  ✗ Too many missing values (80% of rows have no value)
  ✗ Highly correlated with another feature (redundant)
  ✗ Data leakage (contains future information)
  ✗ Too noisy (random number generator)
```

---

## 3.4 Feature Engineering

Feature engineering is the process of **creating new features from existing data** to give the model more useful information.

```
ORIGINAL DATA:
┌────────────┬────────────┐
│ birth_date │ signup_date│
│ 1995-03-15 │ 2024-01-10 │
└────────────┴────────────┘

ENGINEERED FEATURES:
┌──────┬─────────────┬──────────────┬──────────────┬────────────┐
│ age  │ signup_month│ signup_year  │ days_as_user │ is_weekend │
│  29  │     1       │    2024      │     365      │   false    │
└──────┴─────────────┴──────────────┴──────────────┴────────────┘
```

### Common Feature Engineering Techniques

**1. Mathematical transformations**:
```python
df['price_per_sqft'] = df['price'] / df['area']
df['total_rooms'] = df['bedrooms'] + df['bathrooms']
df['log_income'] = np.log(df['income'])           # reduce skewness
df['age_squared'] = df['age'] ** 2                 # capture non-linear relationship
```

**2. Date/Time decomposition**:
```python
df['hour'] = df['timestamp'].dt.hour
df['day_of_week'] = df['timestamp'].dt.dayofweek
df['is_weekend'] = df['day_of_week'].isin([5, 6])
df['month'] = df['timestamp'].dt.month
df['quarter'] = df['timestamp'].dt.quarter
```

**3. Text features**:
```python
df['email_length'] = df['email_text'].str.len()
df['num_exclamations'] = df['email_text'].str.count('!')
df['has_urgent'] = df['email_text'].str.contains('urgent', case=False)
```

**4. Aggregation features**:
```python
df['avg_purchase_per_customer'] = df.groupby('customer_id')['amount'].transform('mean')
df['total_orders'] = df.groupby('customer_id')['order_id'].transform('count')
```

**5. Interaction features**:
```python
df['area_x_bedrooms'] = df['area'] * df['bedrooms']
df['income_to_debt_ratio'] = df['income'] / (df['debt'] + 1)
```

---

## 3.5 Feature Selection

Feature selection is choosing WHICH features to keep. Too many features cause problems (overfitting, slow training, noise).

```
Methods:

1. FILTER METHODS (before training):
   - Correlation: Drop features with low correlation to target
   - Variance: Drop features with near-zero variance
   - Chi-squared test: For categorical features

   Correlation Matrix:
   ┌──────────┬───────┬──────────┬─────────┬───────┐
   │          │ Area  │ Bedrooms │  Color  │ Price │
   ├──────────┼───────┼──────────┼─────────┼───────┤
   │ Area     │ 1.00  │  0.82    │  0.02   │ 0.91  │ ◄── High correlation with Price
   │ Bedrooms │ 0.82  │  1.00    │  0.01   │ 0.78  │ ◄── High correlation
   │ Color    │ 0.02  │  0.01    │  1.00   │ 0.03  │ ◄── Near-zero → DROP IT
   │ Price    │ 0.91  │  0.78    │  0.03   │ 1.00  │
   └──────────┴───────┴──────────┴─────────┴───────┘

2. WRAPPER METHODS (use model performance):
   - Forward selection: Start empty, add best feature one by one
   - Backward elimination: Start with all, remove worst one by one
   - Recursive Feature Elimination (RFE)

3. EMBEDDED METHODS (during training):
   - Lasso (L1 regularization): Automatically zeros out useless features
   - Tree-based importance: Random Forest / XGBoost tell you which features matter
```

---

## 3.6 Numerical vs Categorical Features

```
NUMERICAL FEATURES:               CATEGORICAL FEATURES:
(Numbers with mathematical         (Labels/categories, no mathematical
 meaning — you can add/average)     meaning — cannot add/average)

- Age: 25, 30, 45                  - Color: Red, Blue, Green
- Temperature: 32.5°C              - City: Mumbai, Delhi, Pune
- Salary: ₹50,000                  - Gender: Male, Female
- Count: 3 items                   - Day: Monday, Tuesday

  Can be continuous (any value)      Can be nominal (no order):
  or discrete (whole numbers)          Red, Blue, Green

                                     Or ordinal (has order):
                                       Low < Medium < High
                                       Small < Medium < Large
```

---

## 3.7 Encoding Techniques (Converting Categories to Numbers)

ML models only understand numbers. Categories must be converted.

### Label Encoding

```
City:     Mumbai → 0,  Delhi → 1,  Pune → 2

Problem: The model might think Pune (2) > Delhi (1) > Mumbai (0),
         implying an order that doesn't exist.

Use when: The category HAS a natural order (Low/Medium/High)
```

### One-Hot Encoding (Most Common)

```
Original:                    One-Hot Encoded:
┌──────────┐                 ┌─────────┬────────┬───────┐
│  City    │                 │ Mumbai  │ Delhi  │ Pune  │
├──────────┤                 ├─────────┼────────┼───────┤
│  Mumbai  │      ──>        │    1    │   0    │   0   │
│  Delhi   │      ──>        │    0    │   1    │   0   │
│  Pune    │      ──>        │    0    │   0    │   1   │
│  Mumbai  │      ──>        │    1    │   0    │   0   │
└──────────┘                 └─────────┴────────┴───────┘

Each category becomes a separate binary (0/1) column.
No false ordering is introduced.

Problem: If you have 1000 unique categories, you get 1000 new columns.
         This is called the "curse of dimensionality."
```

### Target Encoding

```
Replace each category with the MEAN of the target for that category.

City     │ Price      City_Encoded │ Price
─────────┼──────      ─────────────┼──────
Mumbai   │ 2.0   →       2.5      │ 2.0
Delhi    │ 1.5   →       1.5      │ 1.5
Mumbai   │ 3.0   →       2.5      │ 3.0
Delhi    │ 1.5   →       1.5      │ 1.5

Mumbai mean price = (2.0 + 3.0) / 2 = 2.5
Delhi mean price = (1.5 + 1.5) / 2 = 1.5

Use when: High cardinality (many categories like zip codes)
Caution: Risk of data leakage — use only on training set
```

---

## 3.8 Scaling and Normalization

Different features can have wildly different ranges. This causes problems for many algorithms.

```
WITHOUT Scaling:
  Feature: Salary (₹)    = 50,000
  Feature: Age (years)    = 25
  Feature: Rooms (count)  = 3

  The model thinks Salary is 20,000x more "important" than Rooms
  just because the numbers are bigger. This is wrong!
```

### Min-Max Normalization (scales to [0, 1])

```
Formula: X_scaled = (X - X_min) / (X_max - X_min)

Example:
  Ages: [20, 25, 30, 40, 60]
  Min = 20, Max = 60

  20 → (20-20)/(60-20) = 0.00
  25 → (25-20)/(60-20) = 0.125
  30 → (30-20)/(60-20) = 0.25
  40 → (40-20)/(60-20) = 0.50
  60 → (60-20)/(60-20) = 1.00

Use when: You want values between 0 and 1
          Algorithm: KNN, SVM, Neural Networks
Caution:  Sensitive to outliers (one age=200 would squash everything)
```

### Standardization / Z-Score (scales to mean=0, std=1)

```
Formula: X_scaled = (X - mean) / std

Example:
  Ages: [20, 25, 30, 40, 60]
  Mean = 35, Std = 14.58

  20 → (20-35)/14.58 = -1.03
  25 → (25-35)/14.58 = -0.69
  30 → (30-35)/14.58 = -0.34
  40 → (40-35)/14.58 =  0.34
  60 → (60-35)/14.58 =  1.71

Use when: Data has outliers (more robust than Min-Max)
          Algorithm: Linear Regression, Logistic Regression, SVM
Result:   Mean becomes 0, standard deviation becomes 1
```

### When to Scale

```
NEED Scaling:                    DON'T Need Scaling:
- Linear Regression              - Decision Trees
- Logistic Regression            - Random Forest
- SVM                           - XGBoost / Gradient Boosting
- KNN                           - Naive Bayes
- Neural Networks
- PCA
```

---

### Section 3 Summary & Cheat Sheet

```
FEATURE ENGINEERING CHEAT SHEET:
┌────────────────────────────────────────────────────────┐
│ Feature = individual measurable property of data        │
│ Feature Engineering = create new useful features         │
│ Feature Selection = choose which features to keep        │
│                                                         │
│ Encoding:                                               │
│   Label Encoding → ordinal categories (Low/Med/High)    │
│   One-Hot Encoding → nominal categories (Red/Blue/Green)│
│   Target Encoding → high-cardinality (1000+ categories) │
│                                                         │
│ Scaling:                                                │
│   Min-Max → scales to [0, 1], sensitive to outliers     │
│   Z-Score → scales to mean=0 std=1, handles outliers    │
│   Required for: KNN, SVM, Neural Nets, Linear models    │
│   Not needed for: Trees, Random Forest, XGBoost         │
└────────────────────────────────────────────────────────┘
```

### Section 3 Interview Questions

1. **Q: What is feature engineering? Give 3 examples.**
   A: Creating new features from raw data. Examples: extracting hour/day from timestamps, computing price_per_sqft from price and area, computing interaction features like income-to-debt ratio.

2. **Q: When would you use One-Hot encoding vs Label encoding?**
   A: One-Hot for nominal categories (no order). Label for ordinal categories (has natural order like Low/Med/High).

3. **Q: Why do we need feature scaling?**
   A: Features with larger ranges dominate distance-based calculations. Scaling puts all features on equal footing.

4. **Q: What is the difference between normalization and standardization?**
   A: Normalization (Min-Max) scales to [0,1]. Standardization (Z-score) centers to mean=0, std=1. Standardization is more robust to outliers.

5. **Q: What is multicollinearity and why is it a problem?**
   A: When two features are highly correlated (e.g., area in sqft and area in sqm). It makes model coefficients unstable and hard to interpret. Remove one of the correlated features.

---

# SECTION 4: MODELS (Part A -- Classical Machine Learning)

---

## 4.1 Linear Regression

### Intuition

Linear Regression draws the **best-fitting straight line** through your data points to predict a continuous number.

**Analogy**: Your electricity bill is roughly proportional to your usage. If you plot months of bills vs kWh, the points form a rough line. Linear Regression finds that line so you can predict next month's bill.

### Architecture

```
Input Features: x₁, x₂, ..., xₙ

Model:  ŷ = w₁x₁ + w₂x₂ + ... + wₙxₙ + b

        where:
          w₁, w₂, ..., wₙ = weights (slopes)
          b = bias (y-intercept)
          ŷ = predicted value

Simple (1 feature):     ŷ = wx + b    ──> a straight line
Multiple (n features):  ŷ = W·X + b   ──> a hyperplane in n dimensions
```

**Visual (1 feature)**:
```
Price (₹)
    ▲
    │         *    *
    │       *    /
    │     *   /  *
    │   *  /  *
    │    / *         ← Best fit line: ŷ = 0.5x + 10
    │  /*
    │ /  *
    │/ *
    └──────────────────► Area (sqft)
```

### How It Learns

1. Start with random weights (w=0, b=0)
2. For each training sample, predict ŷ = wx + b
3. Compute loss: MSE = (1/n)Σ(y - ŷ)²
4. Compute gradients: ∂MSE/∂w and ∂MSE/∂b
5. Update: w = w - α × ∂MSE/∂w, b = b - α × ∂MSE/∂b
6. Repeat until convergence

**There's also a direct mathematical solution (no iteration needed)**:

```
Normal Equation: w = (XᵀX)⁻¹Xᵀy

This directly computes the optimal weights by solving a system of equations.
Works well for small datasets but is O(n³) — too slow for millions of features.
```

### Mathematical Derivation

```
Given:  ŷᵢ = w × xᵢ + b        (model)
Loss:   L = (1/n) Σᵢ (yᵢ - ŷᵢ)²  (MSE)

Expand: L = (1/n) Σ (yᵢ - wxᵢ - b)²

Gradient w.r.t. w:
    ∂L/∂w = (1/n) Σ 2(yᵢ - wxᵢ - b)(-xᵢ)
           = -(2/n) Σ xᵢ(yᵢ - wxᵢ - b)

Gradient w.r.t. b:
    ∂L/∂b = -(2/n) Σ (yᵢ - wxᵢ - b)

Set both to 0 and solve → gives the normal equation.
Or use gradient descent iteratively.
```

### Advantages / Disadvantages

```
✅ Advantages:                    ❌ Disadvantages:
- Simple to understand             - Assumes LINEAR relationship
- Fast to train                    - Sensitive to outliers
- Interpretable (each weight       - Cannot capture complex patterns
  tells you feature importance)    - Assumes features are independent
- Works well when relationship     - Performs poorly with categorical
  is actually linear                 variables (need encoding first)
- No hyperparameters to tune

⏱️ Computational Cost: O(n × d) for gradient descent, O(d³) for normal equation
   where n = samples, d = features. Very fast.

✓ USE WHEN: Relationship is approximately linear, interpretability needed,
            baseline model, small to medium datasets
✗ DON'T USE: Non-linear relationships, outlier-heavy data, complex interactions
```

### Real-world Use Cases
- Predicting house prices based on area
- Estimating salary based on years of experience
- Forecasting sales based on advertising spend

---

## 4.2 Logistic Regression

### Intuition

Despite the name, Logistic Regression is a **classification** algorithm. It predicts the **probability** that something belongs to a category (0 or 1).

**Analogy**: A doctor checks symptoms (fever, cough, test results) and estimates the PROBABILITY of having a disease. If probability > 50%, they diagnose positive. That's logistic regression.

### Architecture

```
Step 1: Compute a linear score (same as Linear Regression):
    z = w₁x₁ + w₂x₂ + ... + wₙxₙ + b

Step 2: Pass through the SIGMOID function to get a probability:
    ŷ = σ(z) = 1 / (1 + e⁻ᶻ)

    This squashes any number into the range (0, 1)

Step 3: Apply a threshold (usually 0.5):
    if ŷ ≥ 0.5 → predict class 1 (positive)
    if ŷ < 0.5  → predict class 0 (negative)
```

**The Sigmoid Function**:
```
    1.0 ┤                    ___________
        │                 /
    0.5 ┤- - - - - - - -/- - - - - - - - - (decision boundary)
        │             /
    0.0 ┤____________/
        └────────────┼────────────────────►  z
                     0

  When z is very negative → σ(z) ≈ 0  (confidently class 0)
  When z = 0             → σ(z) = 0.5  (uncertain)
  When z is very positive → σ(z) ≈ 1  (confidently class 1)
```

### How It Learns

Loss function: **Binary Cross-Entropy** (not MSE, because MSE + sigmoid creates a non-convex surface)

```
Loss = -(1/n) Σ [yᵢ × log(ŷᵢ) + (1-yᵢ) × log(1-ŷᵢ)]

Why this works:
  If true label y=1 and prediction ŷ=0.9:  -log(0.9) = 0.105  (small loss ✓)
  If true label y=1 and prediction ŷ=0.01: -log(0.01) = 4.605 (huge loss ✗)
  If true label y=0 and prediction ŷ=0.1:  -log(0.9) = 0.105  (small loss ✓)
  If true label y=0 and prediction ŷ=0.99: -log(0.01) = 4.605 (huge loss ✗)
```

Gradients are computed and weights updated with gradient descent, same as linear regression.

### Advantages / Disadvantages

```
✅ Advantages:                     ❌ Disadvantages:
- Outputs probabilities (not        - Assumes LINEAR decision boundary
  just classes)                     - Cannot solve non-linear problems
- Simple, fast, interpretable         (e.g., XOR problem)
- Coefficients show feature         - Requires feature engineering
  importance with direction         - Sensitive to multicollinearity
- Great baseline for classification - Underfits complex data
- Regularization available (L1/L2)

⏱️ Computational Cost: O(n × d) — very fast
✓ USE WHEN: Binary classification, need probabilities, interpretability needed
✗ DON'T USE: Non-linear boundaries, highly complex data
```

### Real-world Use Cases
- Email spam detection (spam / not spam)
- Disease diagnosis (positive / negative)
- Customer churn prediction (will leave / won't leave)
- Credit card fraud detection (fraud / legitimate)

---

## 4.3 Decision Trees

### Intuition

A Decision Tree makes predictions by asking a **series of yes/no questions** about the features, creating a flowchart-like structure.

**Analogy**: Think of the game "20 Questions." You ask "Is it alive?" → "Is it bigger than a cat?" → "Can it fly?" Each question narrows down the answer. A Decision Tree does exactly this with data.

### Architecture

```
EXAMPLE: Should I play tennis today?

                    [Outlook?]
                   /    |      \
                sunny  overcast  rainy
                /        |         \
         [Humidity?]    YES     [Windy?]
          /      \              /      \
      high     normal       true    false
       /          \          /         \
      NO          YES       NO         YES


Each internal node = a QUESTION about one feature
Each branch = an ANSWER to that question
Each leaf node = a PREDICTION (class label or value)
```

### How It Learns

The tree is built **top-down** by choosing the best feature to split on at each node. "Best" means the split that most effectively separates the classes.

**Key Concept: Impurity**

```
GINI IMPURITY (for classification):
    Gini = 1 - Σ(pᵢ²)    where pᵢ = proportion of class i

    Pure node (all same class):  Gini = 1 - 1² = 0       (perfect!)
    50-50 split:                 Gini = 1 - (0.5² + 0.5²) = 0.5 (worst)

INFORMATION GAIN / ENTROPY (alternative):
    Entropy = -Σ pᵢ × log₂(pᵢ)

    Pure node:    Entropy = 0
    50-50 split:  Entropy = 1 (maximum uncertainty)
```

**How splitting works**:

```
BEFORE SPLIT:  10 samples [6 Yes, 4 No]  Gini = 1 - (0.6² + 0.4²) = 0.48

Split on "Outlook = Sunny":
    LEFT child:   [2 Yes, 3 No]   Gini = 1 - (0.4² + 0.6²) = 0.48
    RIGHT child:  [4 Yes, 1 No]   Gini = 1 - (0.8² + 0.2²) = 0.32

Weighted average Gini after split = (5/10)×0.48 + (5/10)×0.32 = 0.40
Information Gain = 0.48 - 0.40 = 0.08

The algorithm tries ALL possible features and ALL possible split points,
picks the one with the HIGHEST information gain.
```

### Advantages / Disadvantages

```
✅ Advantages:                     ❌ Disadvantages:
- Extremely interpretable           - Prone to OVERFITTING (memorizes
  (can visualize the tree)            training data)
- No scaling needed                 - Unstable (small data change →
- Handles both numerical and          completely different tree)
  categorical features              - Greedy algorithm (local optima,
- Handles non-linear relationships    not guaranteed global best)
- Can capture feature interactions  - Poor generalization alone
- Fast training and prediction      - Biased toward features with
                                      many unique values

⏱️ Computational Cost: O(n × d × log(n)) — fast
✓ USE WHEN: Need interpretability, exploratory analysis, feature importance
✗ DON'T USE: When you need high accuracy (use ensemble instead), high-dim data
```

### Real-world Use Cases
- Credit risk scoring (approve/deny loan)
- Medical diagnosis decision support
- Customer segmentation

---

## 4.4 Random Forest

### Intuition

A Random Forest is an **ensemble of many Decision Trees** that vote together. Each tree is slightly different (trained on different random subsets of data and features), and the final prediction is the majority vote (classification) or average (regression).

**Analogy**: Instead of asking one expert for advice, you ask 100 different experts. Each expert has seen slightly different information. You take a vote -- the majority answer is usually better than any single expert's answer. This is the "wisdom of crowds."

### Architecture

```
Training Data
     │
     ├──> Bootstrap Sample 1 + Random Features ──> Tree 1 ──> Prediction 1
     ├──> Bootstrap Sample 2 + Random Features ──> Tree 2 ──> Prediction 2
     ├──> Bootstrap Sample 3 + Random Features ──> Tree 3 ──> Prediction 3
     │    ...
     └──> Bootstrap Sample N + Random Features ──> Tree N ──> Prediction N
                                                                    │
                                                            ┌───────┴────────┐
                                                            │   AGGREGATE     │
                                                            │ Classification: │
                                                            │  Majority Vote  │
                                                            │ Regression:     │
                                                            │  Average        │
                                                            └────────────────┘
```

**Two key sources of randomness**:

1. **Bootstrap sampling (Bagging)**: Each tree gets a random sample WITH replacement from the training data. If you have 10,000 rows, each tree might get a random 10,000 rows (some repeated, some missing).

2. **Random feature subset**: At each split, the tree only considers a random subset of features (typically √d for classification, d/3 for regression). This ensures trees are diverse.

### How It Learns

```
For each tree (say 100 trees total):
    1. Draw a bootstrap sample (random subset with replacement)
    2. Build a decision tree, but at each split:
       - Only consider √d random features (not all d)
       - Pick the best split among those random features
    3. Grow the tree fully (no pruning usually)

For prediction:
    - Classification: Each tree votes → majority wins
    - Regression: Each tree predicts → take the average
```

### Advantages / Disadvantages

```
✅ Advantages:                     ❌ Disadvantages:
- Much better accuracy than         - Less interpretable than a single
  a single tree                       tree (100 trees = black box)
- Resistant to overfitting          - Slower than a single tree
  (averaging reduces variance)      - Higher memory usage
- Handles missing values well       - Cannot extrapolate (predicts
- Feature importance built-in         within range of training data)
- No scaling needed                 - Not great for very high-dim
- Robust to outliers                  sparse data (use XGBoost instead)
- Parallelizable (trees are
  independent)

⏱️ Computational Cost: O(n_trees × n × d × log(n)) — moderate
✓ USE WHEN: Tabular data, need good accuracy with minimal tuning,
            feature importance analysis, don't need extreme speed
✗ DON'T USE: Real-time low-latency inference, need interpretability,
             very large datasets where speed matters
```

### Real-world Use Cases
- Credit scoring
- Medical diagnosis
- Stock market prediction
- Insurance claim prediction
- Customer churn

---

## 4.5 XGBoost (Extreme Gradient Boosting)

### Intuition

XGBoost builds trees **sequentially**, where each new tree focuses on correcting the mistakes of the previous trees. Instead of many independent trees (Random Forest), XGBoost builds an **additive sequence** of weak learners.

**Analogy**: Imagine writing an essay. First draft is rough (Tree 1). A reviewer highlights errors (residuals). You write a second draft fixing ONLY those errors (Tree 2). Another review finds remaining issues (Tree 3). Each revision focuses on what's still wrong. After 100 revisions, the essay is excellent.

### Architecture

```
RANDOM FOREST (parallel):            XGBoost (sequential):

  Data ──┬──> Tree 1 ──┐             Data ──> Tree 1 ──> residuals₁
         ├──> Tree 2 ──┤ → Average         ──> Tree 2 ──> residuals₂
         ├──> Tree 3 ──┤                    ──> Tree 3 ──> residuals₃
         └──> Tree N ──┘                    ...
                                            ──> Tree N
  Trees are INDEPENDENT                     
                                     Final: ŷ = Tree1 + Tree2 + ... + TreeN
                                     Each tree CORRECTS previous errors
```

### How It Learns

```
Step 1: Start with a simple prediction (e.g., average of all y values)
        ŷ₀ = mean(y) = 150  (say, average house price)

Step 2: Compute RESIDUALS (errors):
        residual₁ = y - ŷ₀ = [200-150, 100-150, 180-150] = [50, -50, 30]

Step 3: Build Tree 1 to predict the RESIDUALS (not the original target)
        Tree 1 predicts: [40, -45, 25]

Step 4: Update predictions:
        ŷ₁ = ŷ₀ + α × Tree1 = 150 + 0.1 × [40, -45, 25]
             = [154, 145.5, 152.5]
        (α = learning rate, small value like 0.1 to prevent overfitting)

Step 5: Compute new residuals:
        residual₂ = y - ŷ₁ = [46, -45.5, 27.5]

Step 6: Build Tree 2 to predict residual₂
...repeat for N trees...

Final prediction: ŷ = initial + α×Tree₁ + α×Tree₂ + ... + α×TreeN
```

### What Makes XGBoost Special (vs regular Gradient Boosting)

```
1. REGULARIZATION: Adds penalty terms to prevent overfitting
   Objective = Loss + Ω(complexity)
   Ω = γT + (1/2)λΣwⱼ²
   where T = number of leaves, wⱼ = leaf weights

2. SECOND-ORDER GRADIENTS: Uses both first derivative (gradient)
   and second derivative (Hessian) for more precise optimization

3. COLUMN SUBSAMPLING: Like Random Forest, randomly samples features
   at each split (reduces overfitting + speeds up)

4. BUILT-IN HANDLING of missing values

5. PARALLEL PROCESSING: Even though trees are sequential,
   the split-finding within each tree is parallelized

6. TREE PRUNING: Uses max_depth and prunes from bottom up
```

### Advantages / Disadvantages

```
✅ Advantages:                     ❌ Disadvantages:
- STATE OF THE ART for tabular      - More hyperparameters to tune
  data (wins most Kaggle comps)     - Can overfit if not regularized
- Built-in regularization           - Slower than Random Forest
- Handles missing values              (sequential nature)
- Feature importance                - Less interpretable than
- Very flexible (many parameters)     single trees
- GPU support                       - Requires careful tuning for
- Faster than plain Gradient          best performance
  Boosting

⏱️ Computational Cost: O(n_trees × n × d) — moderate to high
✓ USE WHEN: Tabular data competitions, need best accuracy,
            structured data with many features
✗ DON'T USE: Image/text data (use DL), tiny datasets, need simplicity
```

### Key Hyperparameters

```
n_estimators:  Number of trees (100-1000)
max_depth:     Tree depth (3-10, usually 6)
learning_rate: Step size (0.01-0.3, usually 0.1)
subsample:     Fraction of rows per tree (0.5-1.0)
colsample_bytree: Fraction of features per tree (0.5-1.0)
min_child_weight: Minimum samples in a leaf
gamma:         Minimum loss reduction for a split
reg_alpha:     L1 regularization
reg_lambda:    L2 regularization
```

### Real-world Use Cases
- Kaggle competition winner
- Fraud detection
- Click-through rate prediction
- Customer lifetime value
- Risk modeling in finance

---

## 4.6 Support Vector Machine (SVM)

### Intuition

SVM finds the **optimal hyperplane** that separates two classes with the **maximum margin** (largest gap between the classes).

**Analogy**: Imagine you have red balls and blue balls on a table. You want to place a stick (line) between them so that the gap between the closest red and blue balls to the stick is as wide as possible. SVM finds that optimal stick placement.

### Architecture

```
2D Example (two features):

    Feature 2
      ▲
      │    ○ ○                      ○ = Class A
      │   ○  ○                      ● = Class B
      │  ○    ○
      │ ─ ─ ─ ─ ─ MARGIN ─ ─ ─
      │  ●   ●  ←─ Support Vectors (closest points to the boundary)
      │   ● ●        │
      │  ●  ●        │
      │ ● ● ●        ▼
      │          DECISION BOUNDARY (hyperplane)
      └─────────────────────────────► Feature 1

The "support vectors" are the data points CLOSEST to the boundary.
Only these points determine where the boundary goes.
If you remove any non-support-vector point, the boundary doesn't change.
```

### The Kernel Trick (for non-linear data)

```
Problem: Data isn't always linearly separable in the original space.

Original 2D space (not separable):     After Kernel mapping to 3D:
      ○ ○ ○                                   ○   ○
    ○ ● ● ○                                ○   ●  ● ○
    ○ ● ● ○                               ────────────── (can separate!)
      ○ ○ ○                                   ● ●

Common Kernels:
  Linear:      K(x,y) = xᵀy               (for linearly separable data)
  Polynomial:  K(x,y) = (xᵀy + c)ᵈ        (for polynomial boundaries)
  RBF/Gaussian: K(x,y) = exp(-γ||x-y||²)  (most flexible, default choice)
```

### Mathematical Foundation

```
Objective: Maximize the margin width = 2/||w||

Minimize:   (1/2)||w||² + C × Σξᵢ

Subject to: yᵢ(w·xᵢ + b) ≥ 1 - ξᵢ   for all i
            ξᵢ ≥ 0

Where:
  w = weight vector (normal to hyperplane)
  b = bias
  C = regularization parameter (tradeoff: wide margin vs fewer errors)
  ξᵢ = slack variables (allow some misclassifications)
```

### Advantages / Disadvantages

```
✅ Advantages:                     ❌ Disadvantages:
- Effective in high-dimensional     - VERY slow on large datasets
  spaces                              O(n² to n³)
- Memory efficient (only stores     - Does not scale well (>100K samples
  support vectors)                    becomes impractical)
- Kernel trick for non-linear data  - Sensitive to feature scaling
- Good generalization (maximizes    - Does not output probabilities
  margin)                             natively (need Platt scaling)
- Robust to overfitting in          - Hard to interpret
  high-dim spaces                   - Choice of kernel and C is tricky

⏱️ Computational Cost: O(n² × d) to O(n³) — SLOW for large data
✓ USE WHEN: Small to medium datasets, high-dimensional data,
            clear margin of separation
✗ DON'T USE: Large datasets (>100K), need probabilities, need speed
```

### Real-world Use Cases
- Text classification
- Image classification (before deep learning era)
- Bioinformatics (gene classification)
- Handwriting recognition

---

## 4.7 K-Nearest Neighbors (KNN)

### Intuition

KNN makes predictions based on the **K most similar** data points in the training set. It doesn't learn anything during training -- it just memorizes the data and compares at prediction time.

**Analogy**: You move to a new neighborhood and want to know if house prices are high or low. You look at the 5 closest houses (K=5) and check their prices. If 4 out of 5 are expensive, you conclude yours is probably expensive too.

### Architecture

```
K=3 Example (Classification):

    Feature 2
      ▲
      │     ●
      │   ○    ●
      │  ○  ★────────── New point to classify
      │     ○  ●        Look at K=3 nearest neighbors
      │   ●     ○       2 are ○ (blue), 1 is ● (red)
      │                 → Predict: ○ (blue) ← majority vote
      └─────────────────► Feature 1

K=3 Example (Regression):
    3 nearest neighbors have values: [100, 120, 110]
    Prediction = average = 110
```

### How Distance is Computed

```
Euclidean Distance (most common):
    d(a, b) = √[(a₁-b₁)² + (a₂-b₂)² + ... + (aₙ-bₙ)²]

Manhattan Distance:
    d(a, b) = |a₁-b₁| + |a₂-b₂| + ... + |aₙ-bₙ|

Minkowski Distance (generalization):
    d(a, b) = (Σ|aᵢ-bᵢ|ᵖ)^(1/p)
    p=2: Euclidean, p=1: Manhattan
```

### Choosing K

```
K too small (K=1):  Overfitting. Noisy. Follows every single data point.
K too large (K=N):  Underfitting. Always predicts the majority class.
Sweet spot:         Usually K=3 to K=√n. Use cross-validation to find best K.

Use ODD K for binary classification to avoid ties.
```

### Advantages / Disadvantages

```
✅ Advantages:                     ❌ Disadvantages:
- No training phase (lazy learner)  - VERY slow at prediction time
- Simple to understand                O(n × d) per prediction
- No assumptions about data         - Sensitive to irrelevant features
  distribution                      - Requires feature scaling (distance
- Naturally handles multi-class       based — large features dominate)
- Can be used for both              - High memory (stores all data)
  classification and regression     - Curse of dimensionality (distances
                                      become meaningless in high-dim)

⏱️ Computational Cost:
   Training: O(1) — just stores data
   Prediction: O(n × d) per query — SLOW
✓ USE WHEN: Small datasets, need a quick baseline, non-linear boundaries
✗ DON'T USE: Large datasets, high dimensions, need fast predictions
```

### Real-world Use Cases
- Recommendation systems (similar users → similar preferences)
- Missing value imputation
- Anomaly detection (far from all neighbors = anomaly)

---

## 4.8 Naive Bayes

### Intuition

Naive Bayes uses **Bayes' Theorem** from probability to classify data. It calculates the probability of each class given the features and picks the most probable class.

The "naive" part: it assumes all features are **independent** of each other (which is rarely true in practice, but it works surprisingly well anyway).

**Analogy**: A doctor diagnoses diseases. They know that 1% of people have Disease X. They also know: if you have Disease X, there's a 90% chance of having a fever, and 80% chance of a cough. You come in with both fever and cough. The doctor calculates: what's the probability you have Disease X given these symptoms? That's Bayes' Theorem.

### The Math: Bayes' Theorem

```
P(Class | Features) = P(Features | Class) × P(Class) / P(Features)

In words:
  Posterior = (Likelihood × Prior) / Evidence

Example: Spam Detection
  Features: email contains "free", "winner", "click here"

  P(Spam | "free", "winner", "click here")
    = P("free" | Spam) × P("winner" | Spam) × P("click here" | Spam) × P(Spam)
      ────────────────────────────────────────────────────────────────────────────
                              P("free", "winner", "click here")

  P(Spam) = 0.3           (30% of emails are spam — the PRIOR)
  P("free" | Spam) = 0.8  (80% of spam emails contain "free")
  P("winner" | Spam) = 0.6
  P("click here" | Spam) = 0.7

  Numerator for Spam = 0.8 × 0.6 × 0.7 × 0.3 = 0.1008

  Compare with:
  P(Not Spam) = 0.7
  P("free" | Not Spam) = 0.05
  P("winner" | Not Spam) = 0.02
  P("click here" | Not Spam) = 0.1

  Numerator for Not Spam = 0.05 × 0.02 × 0.1 × 0.7 = 0.00007

  Since 0.1008 >> 0.00007 → classify as SPAM ✓
```

### Types of Naive Bayes

```
1. Gaussian NB:     Features are continuous (assumes normal distribution)
                    Used for: general numeric data

2. Multinomial NB:  Features are counts/frequencies
                    Used for: text classification (word counts)

3. Bernoulli NB:    Features are binary (0/1)
                    Used for: text (word present or not)
```

### Advantages / Disadvantages

```
✅ Advantages:                     ❌ Disadvantages:
- Extremely FAST (both train       - "Naive" independence assumption
  and predict)                       is often violated
- Works well with small data       - Cannot learn feature interactions
- Excellent for text classification- Bad estimator of probabilities
- Simple to implement                (the actual P values are unreliable,
- Not affected by irrelevant         but the ranking/ordering is good)
  features (they cancel out)       - Sensitive to feature distribution
- Scales linearly O(n × d)          assumptions

⏱️ Computational Cost: O(n × d) — VERY FAST
✓ USE WHEN: Text classification, small datasets, need speed,
            many features (high dimensional)
✗ DON'T USE: Features are highly correlated, need accurate probabilities
```

### Real-world Use Cases
- Email spam filtering (the classic application)
- Sentiment analysis
- Document categorization
- Medical diagnosis

---

### Section 4A Comparison Table

| Model | Type | Speed | Accuracy | Interpretability | Handles Non-Linear | Needs Scaling |
|-------|------|-------|----------|-----------------|-------------------|---------------|
| Linear Regression | Regression | Very Fast | Low-Medium | Very High | No | Yes |
| Logistic Regression | Classification | Very Fast | Low-Medium | Very High | No | Yes |
| Decision Tree | Both | Fast | Medium | Very High | Yes | No |
| Random Forest | Both | Medium | High | Low | Yes | No |
| XGBoost | Both | Medium | Very High | Low | Yes | No |
| SVM | Both | Slow | High | Low | Yes (kernel) | Yes |
| KNN | Both | Slow (predict) | Medium | Medium | Yes | Yes |
| Naive Bayes | Classification | Very Fast | Medium | High | No | No |

### Section 4A Interview Questions

1. **Q: What is the bias-variance tradeoff?**
   A: High bias = underfitting (model too simple). High variance = overfitting (model too complex). We want the sweet spot. Decision Trees have high variance (overfit); Linear Regression has high bias (underfit). Random Forest reduces variance through averaging.

2. **Q: Why does Random Forest work better than a single Decision Tree?**
   A: By training many diverse trees on random subsets and averaging, it reduces variance (overfitting) while maintaining low bias. This is the principle of bagging.

3. **Q: Explain the difference between bagging and boosting.**
   A: Bagging (Random Forest): trains trees independently in parallel, reduces variance. Boosting (XGBoost): trains trees sequentially, each correcting the previous errors, reduces bias.

4. **Q: When would you use SVM over Logistic Regression?**
   A: When the data has a clear margin of separation, when working in high-dimensional spaces, or when using the kernel trick for non-linear boundaries. Use Logistic Regression when you need probabilities and interpretability.

5. **Q: Why is KNN called a "lazy learner"?**
   A: It does NO computation during training — just stores the data. All the work happens at prediction time when it computes distances to all training points.

6. **Q: What makes Naive Bayes "naive"?**
   A: It assumes all features are conditionally independent given the class label. This is almost never true in practice (e.g., "free" and "winner" in spam emails are correlated), but the algorithm works well despite this assumption.

---

# SECTION 4: MODELS (Part B -- Deep Learning)

---

## 4.9 Neural Networks (Fully Connected / Multi-Layer Perceptron)

### Intuition

A Neural Network is a system of interconnected "neurons" organized in layers. Each neuron takes inputs, multiplies them by weights, adds a bias, and passes the result through an activation function. Stacking layers of these neurons allows the network to learn **any** complex pattern.

**Analogy**: Think of a neural network like a company:
- **Input layer** = the data collection team (gathers raw information)
- **Hidden layers** = middle management (processes and transforms information, each layer finding higher-level patterns)
- **Output layer** = the CEO (makes the final decision)

Each "neuron" is like an employee who takes in information, weighs its importance, and passes along a summary to the next layer.

### Architecture

```
INPUT LAYER          HIDDEN LAYER 1        HIDDEN LAYER 2         OUTPUT LAYER
(features)           (learned features)    (deeper features)      (prediction)

  x₁ ──────┐
            ├──→ [h₁] ──┐
  x₂ ──────┤            ├──→ [h₃] ──┐
            ├──→ [h₂] ──┤            ├──→ [ŷ]
  x₃ ──────┘            └──→ [h₄] ──┘
                                    

Every neuron in one layer connects to EVERY neuron in the next layer.
That's why it's called "Fully Connected" or "Dense" network.
```

### What Happens Inside One Neuron

```
            x₁ ──(w₁)──┐
                         │
            x₂ ──(w₂)──├──→ z = w₁x₁ + w₂x₂ + w₃x₃ + b ──→ a = f(z) ──→ output
                         │          ▲                              ▲
            x₃ ──(w₃)──┘          │                              │
                              (weighted sum + bias)       (activation function)

Step 1: Weighted sum:  z = Σ(wᵢ × xᵢ) + b
Step 2: Activation:    a = f(z)     where f is ReLU, Sigmoid, etc.
Step 3: Pass 'a' as input to the next layer
```

### Activation Functions (Why We Need Them)

Without activation functions, a neural network is just stacked linear transformations, which collapse into a single linear transformation. Activation functions introduce **non-linearity**, allowing the network to learn curves, bends, and complex shapes.

```
ReLU (Rectified Linear Unit): f(z) = max(0, z)
    │            /
    │           /
    │          /
    │─────────/
    └────────────── z
    Most popular. Simple. Solves vanishing gradient problem.
    Problem: "dying neurons" (output stuck at 0 for negative inputs)

Sigmoid: f(z) = 1 / (1 + e⁻ᶻ)
    │         ___________
    │        /
    │───────/
    │      /
    └────────────── z
    Squashes to (0,1). Used for binary classification output.
    Problem: vanishing gradients for large |z|

Tanh: f(z) = (eᶻ - e⁻ᶻ) / (eᶻ + e⁻ᶻ)
    │         ___________
    │        /
    │──0────/
    │      /
    │_____/
    └────────────── z
    Squashes to (-1, 1). Zero-centered. Better than sigmoid for hidden layers.

Softmax: f(zᵢ) = eᶻⁱ / Σeᶻʲ
    Converts a vector of numbers into probabilities that sum to 1.
    Used for MULTI-CLASS classification output layer.
    Example: [2.0, 1.0, 0.1] → [0.659, 0.242, 0.099] (probabilities)
```

### Forward Propagation

```
Data flows LEFT to RIGHT through the network:

Input x = [1.0, 2.0]

Hidden Layer (2 neurons):
    h₁ = ReLU(w₁₁×1.0 + w₁₂×2.0 + b₁) = ReLU(0.5×1 + 0.3×2 + 0.1) = ReLU(1.2) = 1.2
    h₂ = ReLU(w₂₁×1.0 + w₂₂×2.0 + b₂) = ReLU(-0.2×1 + 0.8×2 + 0.0) = ReLU(1.4) = 1.4

Output Layer (1 neuron):
    ŷ = Sigmoid(w₃₁×1.2 + w₃₂×1.4 + b₃) = Sigmoid(0.6×1.2 + 0.4×1.4 - 0.5)
      = Sigmoid(0.72 + 0.56 - 0.5) = Sigmoid(0.78) = 0.686

Loss = CrossEntropy(y=1, ŷ=0.686) = -log(0.686) = 0.377
```

### Backpropagation (How It Learns)

Backpropagation is the algorithm that computes gradients layer by layer, from output back to input, using the **chain rule** of calculus.

```
Data flows RIGHT to LEFT to compute gradients:

Step 1: Compute ∂Loss/∂ŷ (how does loss change with prediction?)

Step 2: Compute ∂ŷ/∂z_output (how does prediction change with pre-activation?)

Step 3: Compute ∂z_output/∂w_output (how does pre-activation change with weights?)
        Compute ∂z_output/∂h (how does pre-activation change with hidden values?)

Step 4: Propagate backward through hidden layer using chain rule:
        ∂Loss/∂w_hidden = ∂Loss/∂ŷ × ∂ŷ/∂z_output × ∂z_output/∂h × ∂h/∂z_hidden × ∂z_hidden/∂w_hidden

Step 5: Update ALL weights:
        w_new = w_old - learning_rate × gradient

The CHAIN RULE is the key:
    ∂Loss/∂w = ∂Loss/∂ŷ × ∂ŷ/∂h₂ × ∂h₂/∂h₁ × ∂h₁/∂w
    "How does wiggling w affect h₁, which affects h₂, which affects ŷ, which affects Loss?"
```

### Advantages / Disadvantages

```
✅ Advantages:                       ❌ Disadvantages:
- Universal approximator (can         - Needs lots of data
  learn ANY function given enough     - Computationally expensive
  neurons and data)                   - Black box (hard to interpret)
- Handles non-linear relationships    - Many hyperparameters (layers,
- Flexible architecture                 neurons, learning rate, etc.)
- Foundation for all deep learning    - Can overfit easily
                                      - Requires GPU for large models

⏱️ Computational Cost: O(n × d × h × L) where h=neurons, L=layers
✓ USE WHEN: Complex non-linear patterns, enough data (>10K), tabular data
            where trees don't work well
✗ DON'T USE: Small datasets, need interpretability, tabular data (try XGBoost first)
```

---

## 4.10 Convolutional Neural Network (CNN)

### Intuition

CNNs are specialized neural networks designed for **grid-like data** (images, time series). Instead of connecting every neuron to every input, they use small **sliding filters** that scan across the input, detecting local patterns.

**Analogy**: When you look at a photo, you don't examine every pixel independently. Your brain detects local patterns first -- edges, then shapes, then objects. A CNN works the same way, using small filters that slide across the image to detect features hierarchically.

### Architecture

```
INPUT IMAGE               CONVOLUTION          POOLING          DENSE LAYERS
(32×32×3 RGB)             (Feature Maps)       (Downsample)     (Classification)

┌──────────┐         ┌──────────┐          ┌──────┐         ┌────┐
│          │  Filter  │ ░░░░░░░░ │  Pool    │ ░░░░ │ Flatten │    │
│  Image   │ ──────> │ ░░░░░░░░ │ ──────> │ ░░░░ │ ──────> │ FC │ ──> [Cat: 0.92]
│  (raw    │  3×3    │ ░░░░░░░░ │  2×2    │ ░░░░ │         │    │     [Dog: 0.08]
│  pixels) │         │ (edges)   │         │(small)│         │    │
└──────────┘         └──────────┘          └──────┘         └────┘

Layer 1: Detects EDGES (horizontal, vertical, diagonal)
Layer 2: Detects SHAPES (circles, corners, textures)
Layer 3: Detects PARTS (eyes, ears, wheels)
Layer 4: Detects OBJECTS (face, car, cat)
```

### How Convolution Works

```
Input (5×5 image):           Filter (3×3):         Output (3×3):
┌───┬───┬───┬───┬───┐       ┌───┬───┬───┐
│ 1 │ 0 │ 1 │ 0 │ 1 │       │ 1 │ 0 │ 1 │
├───┼───┼───┼───┼───┤       ├───┼───┼───┤
│ 0 │ 1 │ 0 │ 1 │ 0 │       │ 0 │ 1 │ 0 │
├───┼───┼───┼───┼───┤       ├───┼───┼───┤        Step 1: Place filter on top-left
│ 1 │ 0 │ 1 │ 0 │ 1 │       │ 1 │ 0 │ 1 │        Step 2: Element-wise multiply
├───┼───┼───┼───┼───┤       └───┴───┴───┘        Step 3: Sum all products
│ 0 │ 1 │ 0 │ 1 │ 0 │                              Step 4: Slide filter right/down
├───┼───┼───┼───┼───┤                              Step 5: Repeat
│ 1 │ 0 │ 1 │ 0 │ 1 │
└───┴───┴───┴───┴───┘

Position (0,0): (1×1)+(0×0)+(1×1)+(0×0)+(1×1)+(0×0)+(1×1)+(0×0)+(1×1) = 4

The FILTER WEIGHTS are LEARNED during training (not hand-designed).
The model discovers that certain filters detect useful patterns.
```

### Key CNN Concepts

```
PADDING: Add zeros around the border so output size = input size
    Without padding: 5×5 input + 3×3 filter = 3×3 output (shrinks!)
    With padding=1:  5×5 input + 3×3 filter = 5×5 output (preserved!)

STRIDE: How many pixels the filter moves each step
    Stride=1: filter moves 1 pixel → output is large
    Stride=2: filter moves 2 pixels → output is halved

POOLING (Downsampling):
    Max Pooling: Take the MAXIMUM value in each 2×2 region
    ┌───┬───┬───┬───┐         ┌───┬───┐
    │ 1 │ 3 │ 2 │ 1 │         │ 4 │ 6 │
    ├───┼───┼───┼───┤  Max    ├───┼───┤
    │ 4 │ 2 │ 6 │ 4 │ ──────>│ 8 │ 7 │
    ├───┼───┼───┼───┤  Pool   └───┴───┘
    │ 1 │ 8 │ 3 │ 7 │  2×2
    ├───┼───┼───┼───┤
    │ 5 │ 2 │ 1 │ 3 │
    └───┴───┴───┴───┘
    Purpose: Reduces spatial dimensions, adds translation invariance
```

### Why CNNs Work for Images (and 1D signals)

```
Two key properties:

1. LOCAL CONNECTIVITY: Each neuron only looks at a small region
   (the 3×3 filter), not the entire image.
   → Captures local patterns efficiently

2. WEIGHT SHARING: The SAME filter is used across the entire image.
   → Dramatically reduces parameters
   → If a filter can detect a cat's ear in the top-left,
     it can detect it anywhere in the image

Normal Dense Layer for 100×100 image: 10,000 × 10,000 = 100M parameters!
CNN with 32 filters of 3×3: 32 × 3 × 3 = 288 parameters  (350,000× fewer)
```

### 1D CNN (for time series — used in your disaggregation project)

```
Instead of sliding a 2D filter over an image,
slide a 1D filter over a time series:

Input: [power_t1, power_t2, power_t3, power_t4, power_t5, power_t6, power_t7]
Filter: [w1, w2, w3]  (kernel_size=3)

Output[0] = w1×power_t1 + w2×power_t2 + w3×power_t3
Output[1] = w1×power_t2 + w2×power_t3 + w3×power_t4
...

This detects temporal patterns like "sudden spike" or "gradual rise"
```

### Advantages / Disadvantages

```
✅ Advantages:                       ❌ Disadvantages:
- STATE OF THE ART for images         - Needs lots of data for training
- Parameter efficient (weight          - Computationally expensive (GPU)
  sharing)                            - Fixed input size typically
- Translation invariant               - Not great for sequential data
- Hierarchical feature learning          (use RNN/LSTM instead)
- Transfer learning works great       - Architecture design can be complex
  (use pre-trained models)

⏱️ Computational Cost: O(n × k² × C_in × C_out × H × W) per layer
✓ USE WHEN: Image classification, object detection, time series,
            any grid-like data
✗ DON'T USE: Tabular data, variable-length sequences, small datasets
```

### Real-world Use Cases
- Image classification (cat vs dog)
- Object detection (self-driving cars)
- Face recognition
- Medical image analysis (X-ray, MRI)
- Your energy disaggregation project (1D CNN on power time series)

---

## 4.11 Recurrent Neural Network (RNN)

### Intuition

RNNs are designed for **sequential data** where the order matters. Unlike a regular neural network that processes each input independently, an RNN has a **memory** that passes information from one step to the next.

**Analogy**: When you read a sentence, you don't start from scratch at each word. You carry context from previous words. "The cat sat on the ___" — your brain uses all the previous words to predict "mat." An RNN works exactly like this.

### Architecture

```
UNROLLED RNN (showing how it processes a sequence):

     x₁            x₂            x₃            x₄
     │              │              │              │
     ▼              ▼              ▼              ▼
  ┌──────┐      ┌──────┐      ┌──────┐      ┌──────┐
  │      │─h₁─→│      │─h₂─→│      │─h₃─→│      │─h₄─→
  │ RNN  │      │ RNN  │      │ RNN  │      │ RNN  │
  │ Cell │      │ Cell │      │ Cell │      │ Cell │
  └──────┘      └──────┘      └──────┘      └──────┘
     │              │              │              │
     ▼              ▼              ▼              ▼
     y₁            y₂            y₃            y₄

Key: ALL FOUR BOXES ARE THE SAME CELL (shared weights)!
     The hidden state hₜ carries "memory" from past steps.
```

### What Happens Inside an RNN Cell

```
At each time step t:

    hₜ = tanh(W_h × hₜ₋₁ + W_x × xₜ + b)

    Where:
      xₜ    = input at time t
      hₜ₋₁  = hidden state from previous step (the "memory")
      W_h    = weight matrix for hidden-to-hidden connections
      W_x    = weight matrix for input-to-hidden connections
      b      = bias
      tanh   = activation function (squashes to [-1, 1])
      hₜ     = new hidden state (becomes both output and memory)
```

### The Vanishing Gradient Problem

```
Problem with RNNs for LONG sequences:

During backpropagation, gradients are multiplied at each time step.
If the gradient multiplier is < 1, after many steps it approaches ZERO.

    ∂Loss/∂w = ∂Loss/∂h₁₀₀ × ∂h₁₀₀/∂h₉₉ × ∂h₉₉/∂h₉₈ × ... × ∂h₂/∂h₁ × ∂h₁/∂w
                              \_______________ 100 multiplications _______________/
                              If each factor ≈ 0.9: 0.9¹⁰⁰ ≈ 0.0000266 → VANISHES!

Result: The model CANNOT learn long-range dependencies.
        "The cat, which we saw yesterday at the park near the lake, was ___"
        By the time the RNN reaches "was", it has forgotten "cat."

Solution: LSTM and GRU (next section)
```

### Advantages / Disadvantages

```
✅ Advantages:                       ❌ Disadvantages:
- Handles variable-length sequences   - Vanishing gradient problem
- Captures temporal dependencies      - Cannot capture LONG-RANGE
- Weight sharing across time             dependencies (> ~20 steps)
- Works well for short sequences      - Slow to train (sequential,
                                        cannot parallelize)
                                      - Largely superseded by LSTM/GRU

✓ USE WHEN: Very short sequences, educational purposes
✗ DON'T USE: Long sequences (use LSTM/Transformer instead)
```

---

## 4.12 Long Short-Term Memory (LSTM)

### Intuition

LSTM is a special kind of RNN designed to solve the vanishing gradient problem. It has a **cell state** (long-term memory highway) and **gates** that control what information to keep, forget, or output.

**Analogy**: Think of LSTM as your brain with three abilities:
1. **Forget gate**: "I'm reading about a new topic; let me forget the old context."
2. **Input gate**: "This new information is important; let me store it."
3. **Output gate**: "For this current task, I need to retrieve this specific memory."

### Architecture

```
                                    Cell State (Cₜ) ← long-term memory highway
    ─────────────────────────────────────────────────────────────────────
         │               │                  │              │
         │     ┌─────────┴──────┐    ┌──────┴─────┐       │
         │     │  FORGET GATE   │    │ INPUT GATE  │       │
         │     │ fₜ = σ(Wf·[hₜ₋₁,xₜ]+bf) │ iₜ = σ(Wi·[hₜ₋₁,xₜ]+bi)│
         │     │ "What to forget"│    │ "What to add"│      │
         │     └────────────────┘    └─────────────┘       │
         │            │                    │                │
         │        Cₜ = fₜ × Cₜ₋₁    +   iₜ × C̃ₜ          │
         │        (forget old)       (add new)             │
         │                                                  │
         │                                    ┌─────────────┴──────┐
         │                                    │   OUTPUT GATE       │
         │                                    │ oₜ = σ(Wo·[hₜ₋₁,xₜ]+bo)│
         │                                    │ "What to output"    │
         │                                    └────────────────────┘
         │                                           │
         └───────────────────────────────── hₜ = oₜ × tanh(Cₜ)

Where:
  σ = sigmoid (outputs 0-1, acts as a "gate valve")
  × = element-wise multiplication
  C̃ₜ = tanh(Wc·[hₜ₋₁, xₜ] + bc)  ← candidate new information
```

### Why LSTM Solves Vanishing Gradients

```
The cell state Cₜ is like a CONVEYOR BELT running through time.
Information can flow along it unchanged for many steps.

The forget gate can be close to 1 (keep everything) or close to 0 (forget all).
When the forget gate ≈ 1, gradients flow through Cₜ WITHOUT being multiplied
by weight matrices, preventing them from vanishing.

Regular RNN:  gradient × W × W × W × W × ... → vanishes
LSTM:         gradient × fₜ × fₜ × fₜ × ... → if fₜ ≈ 1, gradient preserved!
```

### Advantages / Disadvantages

```
✅ Advantages:                       ❌ Disadvantages:
- Solves vanishing gradient            - More parameters than vanilla RNN
- Learns long-range dependencies        (4× more: 3 gates + candidate)
  (100-500+ time steps)               - Still sequential (cannot parallelize
- State of the art for sequences         like Transformers)
  before Transformers                  - Slower to train than Transformers
- Bidirectional variant captures       - Complex architecture
  both past and future context

⏱️ Computational Cost: O(T × d²) per layer, where T=seq length, d=hidden size
✓ USE WHEN: Time series, speech recognition, text generation (pre-transformer era)
✗ DON'T USE: When Transformers are available (they're usually better for text/NLP)
```

### GRU (Gated Recurrent Unit) — Simplified LSTM

```
GRU merges the forget and input gates into a single "update gate"
and merges the cell state and hidden state.

Result: Fewer parameters, faster training, similar performance to LSTM.
Use GRU as a simpler alternative when LSTM is overkill.
```

### Real-world Use Cases
- Machine translation (before Transformers)
- Speech recognition
- Time series forecasting
- Music generation
- Handwriting recognition
- Your disaggregation project used BiLSTM in the Attention model

---

## 4.13 Transformers

### Intuition

Transformers process the ENTIRE sequence at once (not step-by-step like RNNs). They use **self-attention** to figure out which parts of the input are relevant to each other, regardless of distance.

**Analogy**: Imagine reading a document. An RNN reads word by word, left to right, struggling to remember the beginning by the time it reaches the end. A Transformer is like having the entire document spread out on a table -- you can look at any word and instantly see how it relates to any other word, even if they're far apart.

### The Self-Attention Mechanism

```
Input: "The cat sat on the mat"

For each word, compute:
  Q (Query): "What am I looking for?"
  K (Key):   "What do I contain?"
  V (Value): "What information do I carry?"

Attention(Q, K, V) = softmax(Q × Kᵀ / √dₖ) × V

Step-by-step for the word "sat":
  Q_sat asks: "Who is doing the sitting?"
  K_cat replies: "I'm the subject!"     (high attention score)
  K_mat replies: "I'm the location!"    (high attention score)
  K_the replies: "I'm just an article." (low attention score)

Attention Matrix (simplified):
            The   cat   sat   on    the   mat
    The   [ 0.1   0.1   0.1   0.1   0.5   0.1 ]
    cat   [ 0.1   0.2   0.4   0.1   0.1   0.1 ]  ← "cat" attends to "sat"
    sat   [ 0.05  0.4   0.1   0.05  0.05  0.35]  ← "sat" attends to "cat" and "mat"
    on    [ 0.1   0.1   0.1   0.3   0.1   0.3 ]
    the   [ 0.1   0.1   0.1   0.1   0.2   0.4 ]
    mat   [ 0.1   0.1   0.3   0.2   0.1   0.2 ]
```

### Transformer Architecture

```
┌─────────────────────────────────────────────────────┐
│                     TRANSFORMER                      │
│                                                      │
│  ENCODER (understanding input)   DECODER (generating)│
│  ┌──────────────────────┐       ┌──────────────────┐│
│  │ Multi-Head Attention  │       │ Masked Attention  ││
│  │         ↓             │       │        ↓          ││
│  │ Add & Normalize       │       │ Cross-Attention   ││
│  │         ↓             │       │ (attend to encoder)│
│  │ Feed-Forward Network  │       │        ↓          ││
│  │         ↓             │       │ Feed-Forward      ││
│  │ Add & Normalize       │       │        ↓          ││
│  │                       │       │ Linear + Softmax  ││
│  │  (× N layers)         │       │  (× N layers)     ││
│  └──────────────────────┘       └──────────────────┘│
│                                                      │
│  + Positional Encoding (since no sequential processing│
│    the model needs position info explicitly)          │
└─────────────────────────────────────────────────────┘
```

### Key Components Explained

```
1. MULTI-HEAD ATTENTION:
   Instead of one attention function, run several in parallel
   (typically 8 heads). Each head learns different relationships.
   Head 1: grammatical relationships (subject-verb)
   Head 2: semantic relationships (cat-animal)
   Head 3: positional relationships (nearby words)
   ...
   Results are concatenated and linearly projected.

2. POSITIONAL ENCODING:
   Since attention looks at ALL positions simultaneously,
   the model doesn't inherently know word ORDER.
   Positional encoding adds a unique signal to each position:
   PE(pos, 2i) = sin(pos / 10000^(2i/d_model))
   PE(pos, 2i+1) = cos(pos / 10000^(2i/d_model))

3. FEED-FORWARD NETWORK:
   Two linear layers with ReLU in between, applied to each position:
   FFN(x) = max(0, xW₁ + b₁)W₂ + b₂
   This adds non-linearity and allows the model to transform features.

4. RESIDUAL CONNECTIONS + LAYER NORMALIZATION:
   output = LayerNorm(x + Sublayer(x))
   The "+x" is a skip connection that helps gradients flow directly.
```

### Advantages / Disadvantages

```
✅ Advantages:                       ❌ Disadvantages:
- PARALLELIZABLE (process entire      - O(n²) memory for attention
  sequence at once, unlike RNNs)        (quadratic with sequence length)
- Captures long-range dependencies   - Requires enormous amounts of data
  perfectly (no vanishing gradient)  - Computationally very expensive
- STATE OF THE ART for NLP            - Complex architecture
- Scalable (just add more layers)    - Pre-training requires massive GPU
- Foundation for GPT, BERT, etc.       clusters
- Transfer learning works amazingly  - Overkill for simple tasks

⏱️ Computational Cost: O(n² × d) per layer — quadratic in sequence length
✓ USE WHEN: NLP tasks, large datasets, text generation, translation,
            any task where attention patterns matter
✗ DON'T USE: Very long sequences (>10K tokens without special tricks),
             small datasets, simple tabular data
```

### Famous Transformer Models

```
BERT (Encoder-only):     Understanding text (classification, Q&A)
GPT (Decoder-only):      Generating text (ChatGPT, copilot)
T5 (Encoder-Decoder):    Text-to-text (translation, summarization)
ViT (Vision Transformer): Image classification (replacing CNNs)
```

### Real-world Use Cases
- ChatGPT / Claude / Gemini (language generation)
- Google Search (BERT for understanding queries)
- Machine translation
- Code generation (GitHub Copilot)
- Image generation (Stable Diffusion uses Transformer blocks)
- Protein structure prediction (AlphaFold)

---

### Section 4 Complete Comparison Table

| Model | Input Type | Learns Non-linear | Parallelizable | Memory | Parameters | Interpretable | Best For |
|-------|-----------|-------------------|----------------|--------|-----------|---------------|----------|
| Linear Regression | Tabular | No | Yes | Low | Few | Very High | Linear trends |
| Logistic Regression | Tabular | No | Yes | Low | Few | Very High | Binary classification |
| Decision Tree | Tabular | Yes | Yes | Low | Few | Very High | Interpretable rules |
| Random Forest | Tabular | Yes | Yes | Medium | Medium | Low | General tabular |
| XGBoost | Tabular | Yes | Partial | Medium | Medium | Low | Competitions, tabular |
| SVM | Tabular | Yes(kernel) | No | High(n²) | n_sv × d | Low | Small, high-dim |
| KNN | Tabular | Yes | Yes | High(stores all) | 0 | Medium | Small datasets |
| Naive Bayes | Tabular/Text | No | Yes | Low | Few | High | Text, speed |
| Neural Network | Any | Yes | Yes | Medium | Many | Very Low | Complex patterns |
| CNN | Grid (image/1D) | Yes | Yes | Medium | Medium | Low | Images, time series |
| RNN | Sequential | Yes | No | Medium | Medium | Low | Short sequences |
| LSTM | Sequential | Yes | No | High | Many | Low | Long sequences |
| Transformer | Sequential | Yes | Yes | Very High | Very Many | Low | NLP, large data |

### Section 4 Interview Questions

1. **Q: Why are CNNs better than fully connected networks for images?**
   A: CNNs exploit spatial locality (local patterns) and weight sharing (same filter across the image), requiring far fewer parameters. A dense layer for a 100x100 image needs 10M connections per neuron; a CNN filter needs only 9 weights.

2. **Q: What is the vanishing gradient problem and how does LSTM solve it?**
   A: In RNNs, gradients are multiplied at each time step during backpropagation. If multipliers are < 1, gradients vanish over long sequences. LSTM uses a cell state (highway) with gates that can preserve gradients by keeping the forget gate near 1.

3. **Q: What is self-attention? Why is it powerful?**
   A: Self-attention computes relevance scores between every pair of positions in a sequence. This allows the model to directly relate distant elements without processing intermediate steps, solving the long-range dependency problem.

4. **Q: Compare CNN vs RNN vs Transformer for sequence data.**
   A: CNN captures local patterns efficiently but has a fixed receptive field. RNN processes sequentially and captures order but suffers from vanishing gradients. Transformer captures all pairwise relationships in parallel but has O(n^2) memory cost.

5. **Q: What is the difference between encoder and decoder in a Transformer?**
   A: The encoder processes the full input and builds representations (bidirectional attention). The decoder generates output one token at a time using masked attention (can only see past tokens) plus cross-attention to the encoder output.

---

# SECTION 5: HOW MODELS ARE CHOSEN

---

## 5.1 Decision Framework

Choosing the right model is one of the most important skills in ML. Here's a systematic approach.

### Step 1: Understand Your Problem Type

```
What are you predicting?
    │
    ├── A NUMBER (continuous)? ──────────────────→ REGRESSION
    │   (house price, temperature, sales)
    │
    ├── A CATEGORY? ──────────────────────────────→ CLASSIFICATION
    │   │
    │   ├── 2 categories (yes/no, spam/ham) ─────→ Binary Classification
    │   └── 3+ categories (cat/dog/bird) ────────→ Multi-class Classification
    │
    ├── GROUP similar items? ────────────────────→ CLUSTERING (Unsupervised)
    │   (customer segments)
    │
    └── DETECT anomalies? ──────────────────────→ ANOMALY DETECTION
        (fraud, defective products)
```

### Step 2: Understand Your Data

```
┌─────────────────────┬───────────────────────────────────────────────┐
│ Question             │ Impact on Model Choice                        │
├─────────────────────┼───────────────────────────────────────────────┤
│ Structured/Tabular?  │ Yes → XGBoost, Random Forest, Linear models  │
│                      │ No  → Deep Learning (CNN, RNN, Transformer)  │
├─────────────────────┼───────────────────────────────────────────────┤
│ How much data?       │ < 1K  → Simple models (Linear, KNN, NB)     │
│                      │ 1K-100K → Tree-based (RF, XGBoost, SVM)     │
│                      │ > 100K → Neural Networks / XGBoost            │
│                      │ > 1M  → Deep Learning shines                 │
├─────────────────────┼───────────────────────────────────────────────┤
│ How many features?   │ < 10 → Any model works                       │
│                      │ 10-100 → Tree-based, SVM                     │
│                      │ > 1000 → Linear with regularization, NB      │
│                      │ Images → CNN, Transformer                     │
├─────────────────────┼───────────────────────────────────────────────┤
│ Sequential/Temporal? │ Yes → LSTM, Transformer, 1D-CNN               │
│                      │ No  → Standard models                         │
├─────────────────────┼───────────────────────────────────────────────┤
│ Missing values?      │ Many → Tree-based (XGBoost handles natively) │
│                      │ Few  → Impute, then any model                │
└─────────────────────┴───────────────────────────────────────────────┘
```

### Step 3: Consider Your Constraints

```
NEED INTERPRETABILITY?
    ├── Must explain every prediction → Linear/Logistic Regression, Decision Tree
    ├── Need feature importance → Random Forest, XGBoost (SHAP values)
    └── Black box is OK → Neural Networks, ensemble methods

NEED SPEED (LATENCY)?
    ├── Real-time (< 10ms) → Linear models, small trees, KNN with indexing
    ├── Near-real-time → XGBoost, small NNs
    └── Batch (offline) → Any model, including large NNs

LIMITED COMPUTE / NO GPU?
    ├── CPU only → Classical ML (all), small NNs
    └── GPU available → Deep Learning viable

NEED CALIBRATED PROBABILITIES?
    ├── Yes → Logistic Regression (naturally calibrated), Platt-scaled SVM
    └── No → Any model
```

### The Practitioner's Flowchart

```
START
  │
  ├── Is data TABULAR (spreadsheet-like)?
  │     ├── YES ──→ Try XGBoost FIRST (usually wins)
  │     │           Then try: Random Forest, LightGBM
  │     │           Baseline: Logistic/Linear Regression
  │     │           If interpretability needed: Decision Tree, Linear
  │     │
  │     └── NO ──→ What type of data?
  │                  ├── IMAGES ──→ CNN (ResNet, EfficientNet) or ViT
  │                  ├── TEXT ──→ Transformer (BERT, GPT)
  │                  ├── AUDIO ──→ 1D CNN + LSTM, or Transformer
  │                  ├── TIME SERIES ──→ 1D CNN, LSTM, or Transformer
  │                  └── GRAPH ──→ Graph Neural Networks
  │
  └── Is the dataset TINY (< 500 rows)?
        ├── YES ──→ Simple models: Logistic Regression, KNN, Naive Bayes
        │           Avoid: Deep Learning (will overfit)
        └── NO ──→ Follow the flowchart above
```

### Industry Decision Making in Practice

```
STEP 1: Start with a BASELINE (simplest possible model)
        - Classification: Logistic Regression
        - Regression: Linear Regression
        - Time Series: Moving Average
        This gives you a performance floor to beat.

STEP 2: Try the GO-TO models:
        - Tabular: XGBoost or LightGBM
        - Text: Fine-tuned BERT
        - Image: Pre-trained ResNet or EfficientNet

STEP 3: Iterate:
        - Feature engineering (usually biggest improvement)
        - Hyperparameter tuning
        - Ensemble multiple models

STEP 4: Production constraints:
        - Model size (edge devices need small models)
        - Latency (real-time needs fast inference)
        - Maintenance (simple models are easier to maintain)

Real companies often deploy simpler models (Logistic Regression, XGBoost)
because they are faster, cheaper, more interpretable, and easier to debug.
The fancy deep learning model that's 2% better may not be worth the
10× increase in infrastructure cost.
```

---

# SECTION 6: DEEP LEARNING LAYERS IN DETAIL

---

## 6.1 The Neuron — The Fundamental Unit

```
A single neuron computes:

    Inputs:  x₁=0.5, x₂=0.3, x₃=0.8
    Weights: w₁=0.4, w₂=-0.2, w₃=0.6
    Bias:    b = 0.1

    Step 1 (Weighted Sum):
        z = (0.5×0.4) + (0.3×(-0.2)) + (0.8×0.6) + 0.1
        z = 0.20 + (-0.06) + 0.48 + 0.1
        z = 0.72

    Step 2 (Activation):
        a = ReLU(0.72) = 0.72   (positive, so passes through)

    This neuron's output: 0.72

    WHAT THE WEIGHTS MEAN:
    w₁ = 0.4 (positive) → x₁ is positively important
    w₂ = -0.2 (negative) → x₂ is negatively important (more x₂ = less output)
    w₃ = 0.6 (largest) → x₃ is the most important input
    b = 0.1 → baseline activation even when all inputs are 0
```

## 6.2 Weights and Biases — What Are They Really?

```
WEIGHTS = the "importance" or "sensitivity" of each input
          Large positive weight → this input strongly increases the output
          Large negative weight → this input strongly decreases the output
          Near-zero weight → this input doesn't matter much

BIASES = the "threshold" or "default" activation
         Without bias: the neuron can only model functions through the origin
         With bias: the neuron can shift its activation threshold
         Think of it as: "how easily does this neuron fire?"

In total, a network with:
  - 784 inputs (28×28 image)
  - 128 hidden neurons
  - 10 output neurons
Has: (784×128 + 128) + (128×10 + 10) = 100,480 + 1,290 = 101,770 parameters

These 101,770 numbers are ALL that the model learns during training.
The "intelligence" lives entirely in these weight and bias values.
```

## 6.3 Layer Types

### Input Layer

```
Simply passes the raw features into the network. No computation here.
Shape = number of features.

Image 28×28 pixels → Input layer of 784 neurons (flattened)
Tabular data with 10 features → Input layer of 10 neurons
```

### Hidden Layers

```
Where the actual learning happens. Each layer transforms data
into increasingly useful representations.

Common types:
  Dense (Fully Connected): Every neuron connects to every neuron in previous layer
  Convolutional: Neurons only connect to local spatial regions
  Recurrent: Neurons connect to themselves across time steps

HOW MANY hidden layers?
  0 hidden layers → Linear model (can't learn non-linear patterns)
  1 hidden layer → Can approximate any continuous function (universal approximation)
  2+ hidden layers → Can learn hierarchical features (more abstract)
  Very deep (50-200+ layers) → Required for complex tasks (images, language)

HOW MANY neurons per layer?
  Rule of thumb: start with 2/3 of input + output size
  Or try: 128, 256, 512 (powers of 2 for GPU efficiency)
  Wider = more capacity but more risk of overfitting
```

### Output Layer

```
Shape and activation depend on the task:

Binary Classification (spam/not-spam):
    1 neuron + Sigmoid activation → outputs P(positive class)

Multi-class Classification (cat/dog/bird):
    N neurons (one per class) + Softmax activation → outputs probability distribution
    [0.7, 0.2, 0.1] = 70% cat, 20% dog, 10% bird

Regression (house price):
    1 neuron + No activation (linear) → outputs any real number

Multi-label Classification (tags: funny, cute, animal):
    N neurons + Sigmoid on each → independent probabilities
    [0.9, 0.8, 0.3] = 90% funny, 80% cute, 30% animal
```

## 6.4 How Gradients Flow (Deep Dive)

```
FORWARD PASS (compute predictions):
    Input → Layer 1 → Layer 2 → ... → Layer N → Loss

BACKWARD PASS (compute gradients using chain rule):
    ∂Loss/∂wₙ     ← directly from loss
    ∂Loss/∂wₙ₋₁   ← gradient flows back through layer N
    ∂Loss/∂wₙ₋₂   ← gradient flows back through layers N and N-1
    ...
    ∂Loss/∂w₁     ← gradient has passed through ALL layers

PROBLEMS THAT ARISE:
    Vanishing Gradients: Each layer multiplies gradient by activation derivative.
      Sigmoid derivative max = 0.25. After 10 layers: 0.25¹⁰ ≈ 0.000001
      → Early layers barely update → model doesn't learn!
      SOLUTION: Use ReLU (derivative = 1 for positive values), use skip connections

    Exploding Gradients: If weight matrices have large eigenvalues,
      gradients grow exponentially through layers.
      SOLUTION: Gradient clipping (cap gradient magnitude), weight initialization

WHY DEEP NETWORKS WORK despite these issues:
    1. ReLU activation (gradient = 1 when active)
    2. Skip/Residual connections (gradient bypasses layers)
    3. Batch Normalization (stabilizes distributions between layers)
    4. Careful initialization (Xavier/He initialization)
    5. Modern optimizers (Adam adapts learning rates per parameter)
```

## 6.5 CNN Layers in Detail

### Convolution Layer

```
Parameters:
    in_channels:  How many input feature maps (3 for RGB image, 1 for grayscale)
    out_channels: How many filters (each learns a different pattern)
    kernel_size:  Filter dimensions (3×3 is most common)
    stride:       Step size (1 = move 1 pixel, 2 = skip every other)
    padding:      Zeros added around border ("same" padding preserves dimensions)

Example: nn.Conv2d(in_channels=3, out_channels=32, kernel_size=3, padding=1)

    Input:  [Batch, 3, 224, 224]    ← 3-channel RGB image
    Output: [Batch, 32, 224, 224]   ← 32 feature maps (one per filter)

    Each of the 32 filters is a [3, 3, 3] tensor (3×3 spatial × 3 channels)
    Total parameters: 32 × (3 × 3 × 3 + 1 bias) = 32 × 28 = 896
```

### Feature Maps

```
After convolution, each filter produces a FEATURE MAP:

Filter 1 (edge detector):    Filter 2 (corner detector):
┌───────────────┐             ┌───────────────┐
│ ░░░    ░░░░░  │             │     ░░░       │
│ ░░░    ░░░░░  │             │    ░░░░░      │
│ ░░░    ░░░░░  │             │   ░░  ░░░     │
│ ░░░    ░░░░░  │             │        ░░     │
│               │             │               │
└───────────────┘             └───────────────┘
  (bright = high activation, this filter "fires" when it sees edges)
```

### Pooling Layer

```
Max Pooling 2×2 (most common):
    Takes the MAX value in each 2×2 window
    Reduces spatial dimensions by half
    Makes the network slightly invariant to small shifts

    [1, 3, 2, 4]         [3, 4]
    [5, 6, 7, 8]   →     [6, 8]
    [1, 2, 3, 4]
    [5, 6, 7, 8]

Average Pooling:
    Takes the AVERAGE instead of max
    Used more in modern architectures (especially at the end)

Global Average Pooling:
    Averages the ENTIRE feature map into one number
    Used to replace large fully-connected layers
    [32, 7, 7] → [32] (one number per channel)
```

## 6.6 Attention and Transformer Blocks in Detail

### Scaled Dot-Product Attention

```
Given:
  Q = Queries [seq_len, d_k]
  K = Keys    [seq_len, d_k]
  V = Values  [seq_len, d_v]

Attention(Q, K, V) = softmax(Q × Kᵀ / √d_k) × V

Step 1: Q × Kᵀ → [seq_len, seq_len] (attention scores matrix)
        Score(i,j) = how much position i should attend to position j

Step 2: Divide by √d_k (prevents scores from becoming too large,
        which would make softmax output nearly one-hot)

Step 3: softmax → normalize each row to sum to 1
        Each row is now a probability distribution over all positions

Step 4: Multiply by V → weighted combination of values
        Each position gets a mixture of information from all positions,
        weighted by how "relevant" they are
```

### Multi-Head Attention

```
Instead of one set of Q, K, V:

    Head 1: Q₁ = X × Wq₁,  K₁ = X × Wk₁,  V₁ = X × Wv₁ → Attention₁
    Head 2: Q₂ = X × Wq₂,  K₂ = X × Wk₂,  V₂ = X × Wv₂ → Attention₂
    ...
    Head H: Qh = X × Wqh,  Kh = X × Wkh,  Vh = X × Wvh → Attentionₕ

    Concatenate: [Attention₁; Attention₂; ...; Attentionₕ]
    Project: Output = Concat × W_o

Each head can learn different types of relationships:
    Head 1 might learn syntactic relationships
    Head 2 might learn semantic relationships
    Head 3 might learn positional relationships
```

### Embeddings

```
Embeddings convert discrete tokens (words, IDs) into dense vectors.

Word "cat" → ID 4523 → Embedding[4523] → [0.23, -0.45, 0.78, ..., 0.12]
                                           (a 768-dimensional vector)

The embedding matrix is LEARNED during training.
Similar words end up with SIMILAR vectors:
    "cat" ≈ "kitten" (close in vector space)
    "cat" ≠ "car" (far apart in vector space)

Embedding dimensions: 128-1024 (larger = more expressive but more parameters)
Vocabulary size × embedding dim = parameter count
    50,000 words × 768 dims = 38.4 million parameters (just for embeddings!)
```

---

### Section 5-6 Summary

```
MODEL SELECTION CHEAT SHEET:
┌────────────────────────────────────────────────────────┐
│ Tabular data → XGBoost (first choice), Random Forest    │
│ Images → CNN (ResNet, EfficientNet) or ViT              │
│ Text → Transformer (BERT, GPT)                          │
│ Time Series → 1D CNN, LSTM, Transformer                 │
│ Small data → Linear models, KNN, Naive Bayes            │
│ Need speed → Linear models, small trees                 │
│ Need interpretability → Linear, Decision Tree, SHAP     │
│ Always start with a simple baseline!                     │
└────────────────────────────────────────────────────────┘

DEEP LEARNING LAYERS CHEAT SHEET:
┌────────────────────────────────────────────────────────┐
│ Dense/FC: Every neuron connected to every previous      │
│ Conv: Local connectivity + weight sharing → images      │
│ Recurrent: Memory across time → sequences               │
│ Attention: Relate any position to any other position    │
│ Pooling: Downsample spatial dimensions                  │
│ BatchNorm: Stabilize training                           │
│ Dropout: Prevent overfitting                            │
│ Embedding: Discrete tokens → dense vectors              │
│ Residual: Skip connections → train very deep networks   │
└────────────────────────────────────────────────────────┘
```

---

# SECTION 7: MODEL TRAINING PIPELINE (End-to-End)

---

## 7.1 Complete Pipeline Overview

```
┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐
│  Data     │───→│  Data    │───→│  Feature │───→│  Model   │───→│  Model   │
│Collection │    │ Cleaning │    │Engineering│    │ Training │    │Evaluation│
└──────────┘    └──────────┘    └──────────┘    └──────────┘    └──────────┘
                                                                       │
┌──────────┐    ┌──────────┐    ┌──────────┐                          │
│Monitoring│◄───│Production│◄───│Deployment│◄──────────────────────────┘
└──────────┘    └──────────┘    └──────────┘
```

## 7.2 Data Collection

```
Sources:
  - Databases (SQL, NoSQL)
  - APIs (REST, GraphQL)
  - Files (CSV, JSON, Parquet)
  - Streaming (Kafka, Kinesis)
  - Web scraping
  - Third-party data providers
  - Manual labeling

Key considerations:
  - Data quality > Data quantity
  - Ensure representative sampling (avoid bias)
  - Check for data freshness (stale data = stale model)
  - Legal/privacy compliance (GDPR, PII handling)
```

## 7.3 Data Cleaning

```
Common issues and fixes:

MISSING VALUES:
  - Drop rows (if few missing)
  - Fill with mean/median (numerical)
  - Fill with mode (categorical)
  - Forward/backward fill (time series)
  - Model-based imputation (KNN imputer)

DUPLICATES:
  - df.drop_duplicates()
  - Check for near-duplicates (fuzzy matching)

OUTLIERS:
  - IQR method: values outside [Q1 - 1.5×IQR, Q3 + 1.5×IQR]
  - Z-score method: values with |z| > 3
  - Domain knowledge: "a human can't be 500 years old"
  - Options: remove, cap/clip, or keep (depends on context)

DATA TYPE ISSUES:
  - Strings that should be numbers ("123" → 123)
  - Dates in wrong format
  - Mixed types in a column
  - Inconsistent categories ("USA", "US", "United States" → "US")

EXAMPLE:
  Before: df['age'] = [25, None, 30, -5, 999, 28, 25, None]
  After:  df['age'] = [25, 27,   30, NaN dropped, NaN dropped, 28, 25, 27]
          (filled NaN with median=27, removed impossible values)
```

## 7.4 Exploratory Data Analysis (EDA)

```
EDA = understanding your data BEFORE modeling

Key analyses:
  1. Shape: df.shape → (rows, columns)
  2. Types: df.dtypes → numerical, categorical, datetime
  3. Statistics: df.describe() → mean, std, min, max, quartiles
  4. Missing values: df.isnull().sum()
  5. Distribution: histograms for each feature
  6. Correlations: heatmap of feature correlations
  7. Target distribution: balanced or imbalanced?
  8. Outliers: box plots
  9. Feature vs target: scatter plots, bar plots

Questions to answer:
  - Is the target balanced? (50-50 for binary, or 99-1?)
  - Which features correlate with the target?
  - Are there obvious patterns or clusters?
  - What's the data quality like?
```

## 7.5 Train-Test Split

```
NEVER evaluate on data the model has seen during training!

Common splits:

Simple split:
  ┌────────────────────────────┬──────────────┐
  │    Training Set (80%)      │  Test (20%)   │
  └────────────────────────────┴──────────────┘

With validation:
  ┌───────────────────┬─────────────┬──────────┐
  │  Training (60%)   │  Val (20%)  │ Test(20%)│
  └───────────────────┴─────────────┴──────────┘
  Training: model learns on this
  Validation: tune hyperparameters using this
  Test: FINAL evaluation only (touch ONCE at the end)

For TIME SERIES (never shuffle — must preserve order):
  ┌───── Past ─────┬── Recent ──┬── Future ──┐
  │   Training      │ Validation │    Test    │
  └────────────────┴────────────┴────────────┘

K-Fold Cross-Validation (K=5):
  Fold 1: [TEST][Train][Train][Train][Train]
  Fold 2: [Train][TEST][Train][Train][Train]
  Fold 3: [Train][Train][TEST][Train][Train]
  Fold 4: [Train][Train][Train][TEST][Train]
  Fold 5: [Train][Train][Train][Train][TEST]
  Average the 5 test scores → more reliable estimate
```

## 7.6 Hyperparameter Tuning

```
HYPERPARAMETERS = settings you choose BEFORE training
(not learned from data)

Examples:
  - Learning rate
  - Number of layers
  - Number of neurons per layer
  - Batch size
  - Number of trees (Random Forest)
  - Max depth (Decision Tree)
  - Regularization strength

Tuning methods:

1. GRID SEARCH:
   Try every combination:
   lr = [0.001, 0.01, 0.1] × batch = [32, 64] × depth = [3, 5, 7]
   Total: 3 × 2 × 3 = 18 experiments
   ✅ Thorough  ❌ Slow for many parameters

2. RANDOM SEARCH:
   Randomly sample N combinations from the parameter space
   ✅ Faster, often finds good results  ❌ Not exhaustive

3. BAYESIAN OPTIMIZATION (Optuna, Hyperopt):
   Uses previous results to intelligently choose next parameters
   ✅ Most efficient  ❌ More complex to set up
```

## 7.7 Deployment and Monitoring

```
DEPLOYMENT OPTIONS:
  - REST API (Flask, FastAPI) → model served as HTTP endpoint
  - Batch pipeline (Spark, Airflow) → run predictions on schedule
  - Edge deployment (ONNX, TFLite) → on mobile/IoT devices
  - Streaming (Kafka + model) → real-time predictions

MONITORING (after deployment):
  - Data drift: Is incoming data different from training data?
  - Model drift: Is model accuracy declining over time?
  - Latency: Is prediction speed acceptable?
  - Error rates: Are there more errors than expected?
  - Business metrics: Is the model achieving its business goal?

  When to RETRAIN:
    - Accuracy drops below threshold
    - Significant data drift detected
    - New features/data sources available
    - Scheduled (monthly/quarterly)
```

---

# SECTION 8: EVALUATION METRICS

---

## 8.1 Classification Metrics

### Confusion Matrix (The Foundation)

```
                        PREDICTED
                   Positive    Negative
              ┌────────────┬────────────┐
   ACTUAL     │     TP     │     FN     │
   Positive   │ (correct!) │ (missed!)  │
              ├────────────┼────────────┤
   ACTUAL     │     FP     │     TN     │
   Negative   │ (false     │ (correct!) │
              │  alarm!)   │            │
              └────────────┴────────────┘

TP (True Positive):  Model said YES, actually YES  ✓
TN (True Negative):  Model said NO, actually NO    ✓
FP (False Positive): Model said YES, actually NO   ✗ (Type I error)
FN (False Negative): Model said NO, actually YES   ✗ (Type II error)

Example: Disease Detection (100 patients, 10 actually sick)
    Model predicts 12 as sick:
      TP = 8 (correctly identified sick)
      FP = 4 (healthy but flagged as sick — unnecessary tests)
      FN = 2 (sick but missed — DANGEROUS!)
      TN = 86 (correctly identified healthy)
```

### Accuracy

```
Accuracy = (TP + TN) / (TP + TN + FP + FN)

Example: (8 + 86) / 100 = 94%  ← sounds great!

BUT WAIT — this is MISLEADING for imbalanced datasets:
    If 99% of emails are not spam, a model that ALWAYS says "not spam"
    gets 99% accuracy but catches ZERO spam!

USE WHEN: Classes are roughly balanced (50-50)
DON'T USE: Imbalanced datasets (fraud detection: 0.1% fraud)
```

### Precision

```
Precision = TP / (TP + FP)
"Of all the things I said were positive, how many actually were?"

Example: 8 / (8 + 4) = 66.7%
"Of 12 patients I flagged as sick, only 8 actually were."

HIGH PRECISION means few false alarms.
USE WHEN: False positives are COSTLY
  - Spam filter: marking a real email as spam is annoying
  - Criminal justice: wrongly convicting an innocent person
```

### Recall (Sensitivity / True Positive Rate)

```
Recall = TP / (TP + FN)
"Of all the actually positive cases, how many did I catch?"

Example: 8 / (8 + 2) = 80%
"Of 10 actually sick patients, I caught 8."

HIGH RECALL means few missed positives.
USE WHEN: False negatives are COSTLY
  - Cancer detection: missing a cancer patient could be fatal
  - Fraud detection: missing a fraud case = financial loss
```

### F1-Score (Harmonic Mean of Precision and Recall)

```
F1 = 2 × (Precision × Recall) / (Precision + Recall)

Example: 2 × (0.667 × 0.80) / (0.667 + 0.80) = 0.727

WHY harmonic mean (not arithmetic)?
  Arithmetic mean of 0% and 100% = 50% (seems decent)
  Harmonic mean of 0% and 100% = 0% (correctly shows one metric is terrible)
  F1 penalizes when either precision or recall is low.

USE WHEN: You want a single metric that balances precision and recall,
          especially with imbalanced data.
```

### Precision-Recall Tradeoff

```
By adjusting the THRESHOLD (default 0.5), you trade precision for recall:

    High threshold (0.9): "Only flag if I'm very sure"
      → High precision, low recall (fewer predictions, but more accurate)
      → You'll miss some positives but rarely make false alarms

    Low threshold (0.1): "Flag anything remotely suspicious"
      → Low precision, high recall (catch almost everything, but many false alarms)
      → You'll catch most positives but also flag many negatives

    Precision
    ▲
    │*
    │ *
    │  *
    │    *
    │       *
    │           *
    │                *
    └─────────────────────► Recall
```

### ROC-AUC

```
ROC Curve: plots True Positive Rate (Recall) vs False Positive Rate
           at different thresholds

    TPR
    ▲
    │       ___________
    │      /
    │    /
    │   /     ← Good model (area under curve is large)
    │  /
    │ /
    │/ - - - - - - -  ← Random model (diagonal line, AUC = 0.5)
    └────────────────► FPR

AUC = Area Under the ROC Curve
  AUC = 1.0 → Perfect model
  AUC = 0.5 → Random guessing (useless)
  AUC < 0.5 → Worse than random (something is wrong)

USE WHEN: Binary classification, need threshold-independent evaluation
DON'T USE: Highly imbalanced datasets (use Precision-Recall AUC instead)
```

---

## 8.2 Regression Metrics

### MAE (Mean Absolute Error)

```
MAE = (1/n) × Σ|yᵢ - ŷᵢ|

Interpretation: "On average, predictions are off by MAE units"
Example: MAE = ₹2.5 lakhs → predictions are off by ₹2.5L on average

✅ Easy to interpret
✅ Robust to outliers
❌ Doesn't penalize large errors more than small ones
```

### RMSE (Root Mean Squared Error)

```
RMSE = √[(1/n) × Σ(yᵢ - ŷᵢ)²]

Example: Predictions off by [1, 1, 1, 10]
  MAE  = (1+1+1+10)/4 = 3.25
  RMSE = √[(1+1+1+100)/4] = √25.75 = 5.07

RMSE > MAE always (unless all errors are equal)
The BIGGER the gap between RMSE and MAE, the MORE outlier errors you have.

✅ Penalizes large errors heavily (useful when big errors are costly)
❌ Sensitive to outliers
❌ Harder to interpret (units are squared, then rooted)
```

### R² (R-Squared / Coefficient of Determination)

```
R² = 1 - [Σ(yᵢ - ŷᵢ)² / Σ(yᵢ - ȳ)²]
       = 1 - (SS_residual / SS_total)

Interpretation: "What fraction of the variance does the model explain?"

R² = 1.0 → Model explains ALL the variance (perfect)
R² = 0.0 → Model is as good as predicting the mean (useless)
R² < 0.0 → Model is WORSE than predicting the mean (terrible)

R² = 0.85 → "The model explains 85% of the variance in the target"

✅ Scale-independent (works for any target range)
✅ Intuitive percentage interpretation
❌ Can be misleading for non-linear relationships
❌ Always increases with more features (use Adjusted R² instead)
```

### When to Use Each Metric

```
┌──────────────┬────────────────────────────────────────────────┐
│ Metric       │ Use When                                       │
├──────────────┼────────────────────────────────────────────────┤
│ Accuracy     │ Balanced classes, quick overview                │
│ Precision    │ False positives are costly (spam filter)        │
│ Recall       │ False negatives are costly (cancer detection)   │
│ F1-Score     │ Imbalanced data, need balance of P and R       │
│ ROC-AUC      │ Binary classification, threshold-independent   │
│ MAE          │ Regression, outliers present, interpretability  │
│ RMSE         │ Regression, large errors are unacceptable       │
│ R²           │ Regression, want to know variance explained     │
└──────────────┴────────────────────────────────────────────────┘
```

---

### Section 7-8 Interview Questions

1. **Q: What is data leakage and how do you prevent it?**
   A: Data leakage occurs when information from the test set (or future data) leaks into the training process. Examples: normalizing before splitting, using target-derived features. Prevention: always split first, then preprocess. Use pipelines.

2. **Q: Explain the precision-recall tradeoff.**
   A: By lowering the classification threshold, you increase recall (catch more positives) but decrease precision (more false alarms), and vice versa. The optimal threshold depends on the business cost of FP vs FN.

3. **Q: When would you use RMSE over MAE?**
   A: When large errors are disproportionately costly. RMSE penalizes large errors more because of squaring. If all errors are equally bad, use MAE (more robust to outliers).

4. **Q: Why is accuracy a bad metric for imbalanced datasets?**
   A: A model predicting the majority class always achieves high accuracy. For 99% negative data, always predicting "negative" gives 99% accuracy but catches zero positives. Use F1 or AUC instead.

5. **Q: What is K-fold cross-validation and why use it?**
   A: Data is split into K folds. Each fold takes turns as the test set while the rest train. Results are averaged. This gives a more reliable estimate of model performance than a single train-test split, especially with small datasets.

---

# SECTION 9: OVERFITTING & UNDERFITTING

---

## 9.1 What Are They?

```
UNDERFITTING (High Bias):
    The model is TOO SIMPLE to capture the patterns in the data.
    Training performance: BAD
    Test performance: BAD
    
    Example: Fitting a straight line to clearly curved data
    
    Price
    ▲       * *
    │     *     *
    │   *  ─────────── ← straight line (underfits the curve)
    │  * *
    │ *
    └───────────────► Area


OVERFITTING (High Variance):
    The model is TOO COMPLEX and memorizes the training data,
    including its noise and outliers.
    Training performance: EXCELLENT
    Test performance: BAD

    Example: Fitting a crazy wiggly curve through every single point
    
    Price
    ▲       * *
    │     *╱   ╲*
    │   *╱      ╲*    ← wiggly curve (overfits to every point)
    │  *╱         ╲*
    │ *╱
    └───────────────► Area


GOOD FIT (Just Right):
    Training performance: GOOD
    Test performance: GOOD (similar to training)

    Price
    ▲       * *
    │     *  ╱╲  *
    │   *  ╱    ╲  *    ← smooth curve (captures the real pattern)
    │  * ╱        ╲ *
    │ *╱
    └───────────────► Area
```

## 9.2 How to Identify Them

```
LEARNING CURVES (Loss vs Epochs):

UNDERFITTING:                  OVERFITTING:                   GOOD FIT:
Loss                           Loss                           Loss
▲                              ▲                              ▲
│ ─── Train                    │ ─── Train                    │ ─── Train
│ - - Val                      │ - - Val                      │ - - Val
│                              │                              │
│── ── ── ── ──                │     - - - - - -              │── ── ── ──
│─ ─ ─ ─ ─ ─ ─                │                              │- - - - - -
│                              │     ──────────               │
│  Both high,                  │  Train keeps dropping        │  Both converge
│  not converging              │  Val stops or rises          │  to low values
└──────────────►               └──────────────►               └──────────────►
    Epochs                         Epochs                         Epochs

KEY DIAGNOSTIC:
  If training loss << validation loss → OVERFITTING
  If training loss ≈ validation loss (both high) → UNDERFITTING
  If training loss ≈ validation loss (both low) → GOOD FIT
```

## 9.3 Solutions

### For Underfitting

```
1. Use a more complex model (more layers, more neurons, deeper trees)
2. Add more features (feature engineering)
3. Reduce regularization
4. Train longer (more epochs)
5. Remove constraints (increase max_depth for trees)
```

### For Overfitting

```
1. GET MORE DATA (single most effective solution)
2. REGULARIZATION (add penalty for complex models)
3. DROPOUT (neural networks)
4. EARLY STOPPING
5. SIMPLIFY MODEL (fewer layers, fewer neurons)
6. CROSS-VALIDATION
7. DATA AUGMENTATION (for images)
8. FEATURE SELECTION (remove noisy features)
```

## 9.4 Regularization

```
CONCEPT: Add a penalty term to the loss function that discourages
         large or complex weights.

Total Loss = Original Loss + λ × Penalty

L1 REGULARIZATION (Lasso):
    Penalty = λ × Σ|wᵢ|
    Effect: Drives some weights EXACTLY to zero → automatic feature selection
    Use when: You suspect many features are irrelevant

L2 REGULARIZATION (Ridge):
    Penalty = λ × Σwᵢ²
    Effect: Makes all weights SMALL (but not zero) → smoother model
    Use when: All features might be somewhat relevant

ELASTIC NET:
    Penalty = λ₁ × Σ|wᵢ| + λ₂ × Σwᵢ²
    Combines L1 and L2. Best of both worlds.

λ (lambda) controls STRENGTH:
    λ = 0:     No regularization (pure original model)
    λ small:   Light regularization
    λ large:   Heavy regularization (model becomes very simple)
    λ = ∞:     All weights forced to zero (predicts a constant)
```

## 9.5 Dropout (Neural Networks)

```
During TRAINING: Randomly set a fraction p of neuron outputs to ZERO.
During TESTING: Use all neurons (but scale outputs by 1-p).

    Training (p=0.5):           Testing:
    [h₁] ──→ [h₃] ──→ ŷ       [h₁] ──→ [h₃] ──→ ŷ
    [h₂] ──X  [h₄]            [h₂] ──→ [h₄]
         (h₂ and h₄ dropped)        (all neurons active)

WHY it works:
    - Forces the network to not rely on any single neuron
    - Each training step uses a different "sub-network"
    - Effectively trains an ENSEMBLE of many thin networks
    - Prevents co-adaptation (neurons can't memorize together)

    Think of it like: studying for an exam where you don't know which
    chapters will be tested. You're forced to learn everything broadly
    instead of memorizing specific answers.

Typical values: p = 0.2 to 0.5 (20% to 50% dropout)
```

## 9.6 Early Stopping

```
Monitor validation loss during training.
Stop when it starts INCREASING (even if training loss keeps decreasing).

    Loss
    ▲
    │    Training loss keeps going down
    │    ──────────────────────────────
    │
    │    Validation loss:
    │      ──── ──── ────┐
    │                     │ ← STOP HERE! (validation loss starts rising)
    │                     │    (past this point = overfitting)
    │                     └─── ── ── ── ──
    │
    └──────────────────────────────────────► Epochs
                  │
                  ▼
           Best model checkpoint

Implementation:
    patience = 5  (wait 5 epochs for improvement)
    If val_loss hasn't improved for 5 epochs → stop training
    Restore weights from the epoch with the LOWEST val_loss
```

---

### Section 9 Cheat Sheet

```
OVERFITTING vs UNDERFITTING:
┌──────────────────┬─────────────────────┬──────────────────────┐
│                  │ UNDERFITTING         │ OVERFITTING           │
├──────────────────┼─────────────────────┼──────────────────────┤
│ Train Error      │ High                │ Very Low              │
│ Test Error       │ High                │ High                  │
│ Gap              │ Small               │ LARGE                 │
│ Cause            │ Model too simple    │ Model too complex     │
│ Fix              │ More complex model  │ Regularization, more  │
│                  │ More features       │ data, dropout, early  │
│                  │ Less regularization │ stopping              │
└──────────────────┴─────────────────────┴──────────────────────┘
```

---

# SECTION 10: INDUSTRY PRACTICALS

---

## 10.1 How Models Are Used in Companies

```
REALITY CHECK: Most companies don't use the fanciest models.

What ACADEMIC papers use:     What COMPANIES actually deploy:
  Custom Transformer           XGBoost / Logistic Regression
  Novel architecture           Pre-trained model + fine-tuning
  State-of-the-art             Whatever works and is maintainable

Why? Because in production:
  - Simpler models are easier to debug
  - Faster inference = lower infrastructure cost
  - Interpretability helps with compliance and trust
  - The biggest gains come from BETTER DATA, not better models
```

## 10.2 Recommendation Systems

```
"People who bought X also bought Y"

TWO MAIN APPROACHES:

1. COLLABORATIVE FILTERING:
   Based on USER BEHAVIOR similarity.
   
   "Users A and B both liked movies 1, 2, 3.
    User A also liked movie 4.
    → Recommend movie 4 to User B."
   
   User-Item Matrix:
              Movie1  Movie2  Movie3  Movie4
   User A:    5       4       5       4       ← likes movie 4
   User B:    5       4       5       ?       ← similar to A → recommend movie 4
   User C:    1       2       1       3       ← different taste, ignore

2. CONTENT-BASED FILTERING:
   Based on ITEM FEATURES similarity.
   
   "You liked Action movies with Tom Cruise.
    Here's another Action movie with Tom Cruise."

3. HYBRID (most production systems):
   Combine both approaches + deep learning
   
   Netflix/Amazon/YouTube architecture:
   ┌──────────────┐      ┌──────────────┐      ┌──────────┐
   │  Candidate    │ ───→│   Ranking     │ ───→ │ Final    │
   │  Generation   │      │   Model       │      │ Results  │
   │ (retrieve     │      │ (score each   │      │ (top 10) │
   │  1000 items)  │      │  candidate)   │      │          │
   └──────────────┘      └──────────────┘      └──────────┘
```

## 10.3 Fraud Detection

```
CHALLENGE: Extremely imbalanced data (99.9% legitimate, 0.1% fraud)

Pipeline:
  1. Feature Engineering:
     - Transaction amount vs average for this user
     - Time since last transaction
     - Geographic distance from last transaction
     - Device fingerprint match
     - Number of transactions in last hour

  2. Model: Usually ensemble (XGBoost + Neural Network)
     - Trained with oversampling (SMOTE) or class weights
     - Optimized for RECALL (catching fraud is more important
       than avoiding false alarms)

  3. Real-time scoring:
     Transaction → Feature extraction → Model → Score (0-1)
     Score > 0.7 → Block transaction
     Score 0.3-0.7 → Send for manual review
     Score < 0.3 → Approve

  4. Feedback loop:
     Human reviewers verify flagged transactions → labels feed back to retrain
```

## 10.4 Search / Ranking Systems

```
Google Search ranking (simplified):

  Query: "best pizza near me"
       │
       ▼
  Stage 1: RETRIEVAL (fast, rough filter)
     Search index → find 10,000 matching pages (keyword matching, BM25)
       │
       ▼
  Stage 2: RANKING (ML model)
     Features: relevance score, page quality, freshness, user location,
               click-through rate, dwell time
     Model: Learning to Rank (LambdaMART, Neural ranker)
     → Score and sort the 10,000 candidates
       │
       ▼
  Stage 3: RE-RANKING (fine-tune with personal context)
     User history, preferences, diversity requirements
     → Final ordered list of ~10 results shown to user
```

## 10.5 ChatGPT-like Systems

```
Architecture: Decoder-only Transformer (GPT architecture)

Training pipeline:
  1. PRE-TRAINING (unsupervised, massive compute):
     - Train on trillions of tokens from the internet
     - Objective: predict the next word
     - "The cat sat on the ___" → "mat" (85%), "table" (10%), ...
     - This learns language, facts, reasoning patterns
     - Cost: millions of dollars, thousands of GPUs

  2. SUPERVISED FINE-TUNING (SFT):
     - Human annotators write ideal responses to prompts
     - Fine-tune the model on (prompt, ideal_response) pairs
     - Makes the model follow instructions

  3. RLHF (Reinforcement Learning from Human Feedback):
     - Model generates multiple responses
     - Humans rank them (A > B > C)
     - Train a REWARD MODEL on these rankings
     - Use PPO (reinforcement learning) to optimize the language model
       to produce responses the reward model rates highly

How inference works:
  Input: "What is machine learning?"
  → Tokenize into IDs: [What][is][machine][learning][?]
  → Feed through transformer layers
  → Output: probability distribution over vocabulary for NEXT token
  → Sample/select next token: "Machine"
  → Append and repeat: [What][is][machine][learning][?][Machine]
  → Continue until [END] token or max length
  → "Machine learning is a subset of AI where..."
```

## 10.6 Real ML Pipelines in Production

```
TYPICAL PRODUCTION PIPELINE (e.g., your disaggregation project):

┌──────────────┐
│ Data Source   │ (HDFS Parquet files, MongoDB metadata)
└──────┬───────┘
       ▼
┌──────────────┐
│ Spark ETL    │ (Read, clean, join, preprocess)
│              │ (Convert energy→power, compute diffs)
└──────┬───────┘
       ▼
┌──────────────┐
│ Feature Eng  │ (Sliding windows, aux features)
│              │ (Spark window functions, applyInPandas)
└──────┬───────┘
       ▼
┌──────────────┐
│ Inference    │ (Broadcast model, pandas_udf for batch prediction)
│              │ (PyTorch CNN running on Spark executors)
└──────┬───────┘
       ▼
┌──────────────┐
│ Post-process │ (Unscale, clip negatives, cap at total, energy conversion)
└──────┬───────┘
       ▼
┌──────────────┐
│ Output       │ (Write CSV, update Cassandra, store on HDFS)
└──────┬───────┘
       ▼
┌──────────────┐
│ Scheduling   │ (Cron job, YARN cluster, daily execution)
└──────────────┘

Key production concerns:
  - Fault tolerance (what if Spark executor dies mid-job?)
  - Data validation (what if input schema changes?)
  - Monitoring (did today's run succeed? Was accuracy normal?)
  - Model versioning (which model weights are in production?)
  - Rollback plan (if new model performs worse, revert to old one)
```

---

# SECTION 11: COMPLETE COMPARISON TABLES

---

## 11.1 All ML Models Comparison

```
┌──────────────────┬───────────┬────────┬─────────┬──────────┬───────────┬──────────┐
│ Model            │ Type      │ Speed  │Accuracy │Interpret.│Handles    │Needs     │
│                  │           │(Train) │(General)│          │Non-Linear │Scaling   │
├──────────────────┼───────────┼────────┼─────────┼──────────┼───────────┼──────────┤
│ Linear Regression│ Regression│ ★★★★★ │ ★★      │ ★★★★★   │ No        │ Yes      │
│ Logistic Regress.│ Classif.  │ ★★★★★ │ ★★★    │ ★★★★★   │ No        │ Yes      │
│ Decision Tree    │ Both      │ ★★★★  │ ★★      │ ★★★★★   │ Yes       │ No       │
│ Random Forest    │ Both      │ ★★★   │ ★★★★   │ ★★       │ Yes       │ No       │
│ XGBoost          │ Both      │ ★★★   │ ★★★★★  │ ★★       │ Yes       │ No       │
│ SVM              │ Both      │ ★★     │ ★★★★   │ ★        │ Yes(kern.)│ Yes      │
│ KNN              │ Both      │ ★★★★★*│ ★★★    │ ★★★     │ Yes       │ Yes      │
│ Naive Bayes      │ Classif.  │ ★★★★★ │ ★★★    │ ★★★★    │ No        │ No       │
│ Neural Network   │ Both      │ ★★     │ ★★★★   │ ★        │ Yes       │ Yes      │
│ CNN              │ Both      │ ★      │ ★★★★★  │ ★        │ Yes       │ Yes      │
│ LSTM             │ Both      │ ★      │ ★★★★★  │ ★        │ Yes       │ Yes      │
│ Transformer      │ Both      │ ★      │ ★★★★★  │ ★        │ Yes       │ Yes      │
└──────────────────┴───────────┴────────┴─────────┴──────────┴───────────┴──────────┘
* KNN: Training is instant (just store data), but prediction is slow
```

## 11.2 Deep Learning Architectures Comparison

```
┌──────────────┬─────────────┬────────────┬────────────┬──────────────┬────────────┐
│ Architecture │ Best For     │ Paralleliz.│ Long-Range │ Parameters   │ Data Need  │
├──────────────┼─────────────┼────────────┼────────────┼──────────────┼────────────┤
│ MLP (Dense)  │ Tabular      │ ★★★★★    │ N/A        │ Medium       │ Medium     │
│ CNN          │ Images,      │ ★★★★★    │ Limited    │ Medium       │ Large      │
│              │ Time Series  │            │ (kernel)   │ (shared)     │            │
│ RNN          │ Short        │ ★          │ Poor       │ Medium       │ Medium     │
│              │ sequences    │            │ (vanishing)│              │            │
│ LSTM/GRU     │ Time series, │ ★          │ Good       │ Large        │ Medium-    │
│              │ Medium seq.  │            │ (gates)    │ (4× RNN)     │ Large      │
│ Transformer  │ NLP, Long    │ ★★★★★    │ Excellent  │ Very Large   │ Very Large │
│              │ sequences    │            │ (attention)│              │            │
│ ViT          │ Images       │ ★★★★★    │ Excellent  │ Very Large   │ Very Large │
│ U-Net        │ Segmentation │ ★★★★     │ Good       │ Large        │ Medium     │
│ GAN          │ Generation   │ ★★★★     │ N/A        │ Large×2      │ Large      │
│ Autoencoder  │ Compression, │ ★★★★★    │ N/A        │ Medium       │ Medium     │
│              │ Anomaly det. │            │            │              │            │
└──────────────┴─────────────┴────────────┴────────────┴──────────────┴────────────┘
```

## 11.3 Feature Selection Methods Comparison

```
┌────────────────────┬──────────┬───────────┬────────────┬───────────────────┐
│ Method             │ Speed    │ Accuracy  │ Type       │ When to Use        │
├────────────────────┼──────────┼───────────┼────────────┼───────────────────┤
│ Correlation Filter │ ★★★★★  │ ★★       │ Filter     │ Quick EDA          │
│ Variance Threshold │ ★★★★★  │ ★★       │ Filter     │ Remove constants   │
│ Chi-Squared        │ ★★★★   │ ★★★     │ Filter     │ Categorical target │
│ Mutual Information │ ★★★★   │ ★★★★    │ Filter     │ Non-linear deps    │
│ RFE (Recursive FE) │ ★★     │ ★★★★    │ Wrapper    │ Small feature set  │
│ Forward Selection  │ ★★      │ ★★★★    │ Wrapper    │ Small feature set  │
│ Backward Elim.     │ ★★      │ ★★★★    │ Wrapper    │ Medium feature set │
│ Lasso (L1)         │ ★★★★   │ ★★★★    │ Embedded   │ Linear models      │
│ Tree Importance    │ ★★★★   │ ★★★★★   │ Embedded   │ Tree-based models  │
│ SHAP Values        │ ★★★    │ ★★★★★   │ Post-hoc   │ Any model, explain.│
│ PCA                │ ★★★★   │ ★★★     │ Transform  │ High dimensionality│
└────────────────────┴──────────┴───────────┴────────────┴───────────────────┘
```

## 11.4 Evaluation Metrics Comparison

```
┌──────────────┬──────────────┬────────────────────────┬──────────────────────┐
│ Metric       │ Task         │ Sensitive To           │ Best When             │
├──────────────┼──────────────┼────────────────────────┼──────────────────────┤
│ Accuracy     │ Classification│ Class imbalance        │ Balanced classes      │
│ Precision    │ Classification│ False Positives        │ FP is costly          │
│ Recall       │ Classification│ False Negatives        │ FN is costly          │
│ F1-Score     │ Classification│ Both FP and FN         │ Imbalanced data       │
│ ROC-AUC      │ Binary Class │ Threshold choice       │ Comparing models      │
│ PR-AUC       │ Binary Class │ Class imbalance        │ Very imbalanced data  │
│ Log Loss     │ Classification│ Probability calibration│ Need good probabilities│
│ MAE          │ Regression   │ Nothing (robust)       │ Outliers present      │
│ RMSE         │ Regression   │ Outliers               │ Large errors costly   │
│ R²           │ Regression   │ Feature count          │ Variance explanation  │
│ MAPE         │ Regression   │ Near-zero values       │ Percentage error      │
└──────────────┴──────────────┴────────────────────────┴──────────────────────┘
```

---

# SECTION 12: LEARNING ROADMAP

---

## 12.1 Best Order to Learn Topics

```
PHASE 1: FOUNDATIONS (Weeks 1-4)
├── Python programming (NumPy, Pandas, Matplotlib)
├── Basic statistics (mean, median, std, distributions)
├── Linear algebra basics (vectors, matrices, dot products)
├── Calculus basics (derivatives, chain rule)
└── Probability basics (Bayes theorem, distributions)

PHASE 2: CLASSICAL ML (Weeks 5-10)
├── Linear Regression (implement from scratch)
├── Logistic Regression (implement from scratch)
├── Decision Trees and Random Forests
├── Gradient Boosting (XGBoost)
├── SVM, KNN, Naive Bayes
├── Feature engineering and selection
├── Evaluation metrics
├── Cross-validation and hyperparameter tuning
└── Scikit-learn mastery

PHASE 3: DEEP LEARNING FOUNDATIONS (Weeks 11-16)
├── Neural networks from scratch (forward/backward prop)
├── PyTorch or TensorFlow basics
├── Activation functions, loss functions, optimizers
├── Regularization, dropout, batch normalization
├── CNNs (image classification)
├── Transfer learning
├── RNNs and LSTMs (time series, text)
└── Build 2-3 projects

PHASE 4: ADVANCED TOPICS (Weeks 17-24)
├── Transformers and attention mechanism
├── NLP with BERT, GPT
├── Generative models (GANs, VAEs, Diffusion)
├── Reinforcement Learning basics
├── MLOps (deployment, monitoring, CI/CD)
├── Distributed training (Spark ML, Horovod)
├── Model optimization (quantization, pruning, distillation)
└── Build production-grade projects

PHASE 5: SPECIALIZATION (Ongoing)
├── Choose a domain (NLP, CV, Time Series, RecSys)
├── Read research papers
├── Contribute to open source
├── Kaggle competitions
└── Build a portfolio
```

## 12.2 Project Ideas

### Beginner Projects

```
1. HOUSE PRICE PREDICTION
   Dataset: Kaggle's Boston Housing / Ames Housing
   Models: Linear Regression → Random Forest → XGBoost
   Learn: Feature engineering, evaluation, comparison

2. TITANIC SURVIVAL PREDICTION
   Dataset: Kaggle Titanic
   Models: Logistic Regression → Decision Tree → Random Forest
   Learn: Classification, handling missing values, encoding

3. IRIS FLOWER CLASSIFICATION
   Dataset: Scikit-learn built-in
   Models: KNN → SVM → Naive Bayes
   Learn: Multi-class classification, visualization

4. CUSTOMER CHURN PREDICTION
   Dataset: Kaggle Telco Customer Churn
   Models: Logistic Regression → XGBoost
   Learn: Imbalanced data, business metrics, threshold tuning
```

### Intermediate Projects

```
5. SENTIMENT ANALYSIS
   Dataset: IMDB Movie Reviews / Amazon Reviews
   Models: Naive Bayes → LSTM → BERT
   Learn: Text preprocessing, embeddings, transfer learning

6. IMAGE CLASSIFICATION
   Dataset: CIFAR-10 / Fashion-MNIST
   Models: CNN from scratch → Transfer learning (ResNet)
   Learn: Conv layers, augmentation, fine-tuning

7. TIME SERIES FORECASTING
   Dataset: Stock prices / Weather data / Energy consumption
   Models: ARIMA → LSTM → Transformer
   Learn: Temporal patterns, sequence modeling, sliding windows

8. RECOMMENDATION SYSTEM
   Dataset: MovieLens
   Models: Collaborative Filtering → Matrix Factorization → Neural CF
   Learn: User-item interactions, cold start problem
```

### Advanced Projects

```
9. END-TO-END ML PIPELINE
   Build: Data ingestion → Feature store → Training → Serving → Monitoring
   Tools: Airflow, MLflow, Docker, FastAPI, Prometheus
   Learn: Production ML, MLOps

10. REAL-TIME FRAUD DETECTION
    Build: Kafka stream → Feature extraction → Model inference → Alert
    Tools: Kafka, Spark Streaming, XGBoost/Neural Network
    Learn: Streaming ML, class imbalance at scale

11. ENERGY DISAGGREGATION (like your project!)
    Build: Power data → CNN model → Appliance predictions
    Tools: PyTorch, PySpark, HDFS
    Learn: 1D CNN, distributed inference, domain ML

12. FINE-TUNE A LARGE LANGUAGE MODEL
    Build: Take a pre-trained LLM → fine-tune on domain data → deploy as API
    Tools: Hugging Face, LoRA, PEFT, vLLM
    Learn: Transfer learning, parameter-efficient fine-tuning
```

## 12.3 Best Datasets

```
CLASSIFICATION:
  - Titanic (Kaggle) — binary, small, great for beginners
  - MNIST / Fashion-MNIST — image classification, 70K samples
  - CIFAR-10/100 — color images, 60K samples
  - IMDB Reviews — text sentiment, 50K samples
  - Adult Income — tabular, predict income >/$50K

REGRESSION:
  - Ames Housing — house prices, 80+ features
  - California Housing — scikit-learn built-in
  - Bike Sharing — demand prediction, time-based

TIME SERIES:
  - UCI Household Power Consumption — energy data
  - Weather data (Kaggle) — temperature forecasting
  - Stock market data (Yahoo Finance)

NLP:
  - SQuAD — question answering
  - GLUE Benchmark — multiple NLP tasks
  - Common Crawl — web text for pre-training

RECOMMENDATION:
  - MovieLens — movie ratings
  - Amazon Reviews — product ratings
  - Last.fm — music recommendations

COMPETITIONS:
  - Kaggle (kaggle.com) — largest ML competition platform
  - DrivenData — social impact challenges
```

## 12.4 Best Resources

```
FREE COURSES:
  - Andrew Ng's Machine Learning (Coursera) — THE classic
  - fast.ai — practical deep learning, top-down approach
  - Stanford CS229 (YouTube) — ML theory
  - Stanford CS231n (YouTube) — Computer Vision
  - Stanford CS224n (YouTube) — NLP
  - 3Blue1Brown Neural Networks series (YouTube) — visual intuition

BOOKS:
  - "Hands-On Machine Learning" by Aurélien Géron — best practical book
  - "Deep Learning" by Goodfellow et al. — the DL bible (free online)
  - "Pattern Recognition and ML" by Bishop — theory heavy
  - "The Hundred-Page Machine Learning Book" by Andriy Burkov — concise

PRACTICE:
  - Kaggle.com — competitions, datasets, notebooks
  - LeetCode (ML section) — coding practice
  - Papers With Code — find papers + implementations
  - Hugging Face — pre-trained models and datasets

TOOLS TO MASTER:
  - Python (NumPy, Pandas, Matplotlib, Seaborn)
  - Scikit-learn (classical ML)
  - PyTorch or TensorFlow (deep learning)
  - XGBoost / LightGBM (competitions)
  - Hugging Face Transformers (NLP)
  - MLflow / Weights & Biases (experiment tracking)
  - Docker + FastAPI (deployment)
```

## 12.5 Interview Preparation Roadmap

```
WEEK 1-2: FUNDAMENTALS
  □ Bias-variance tradeoff
  □ Overfitting vs underfitting
  □ All evaluation metrics
  □ Cross-validation
  □ Feature engineering techniques
  □ Data preprocessing steps

WEEK 3-4: CLASSICAL ML
  □ Explain each algorithm (intuition + math)
  □ When to use which algorithm
  □ Bagging vs Boosting
  □ Regularization (L1 vs L2)
  □ Handle imbalanced data (SMOTE, class weights)
  □ Feature importance methods

WEEK 5-6: DEEP LEARNING
  □ Backpropagation derivation
  □ CNN architecture explained
  □ RNN → LSTM → Transformer evolution
  □ Attention mechanism
  □ Optimizers (SGD, Adam, RMSprop)
  □ Batch normalization
  □ Transfer learning

WEEK 7-8: SYSTEM DESIGN + PRACTICALS
  □ Design a recommendation system
  □ Design a fraud detection system
  □ Design a search ranking system
  □ ML pipeline design
  □ A/B testing
  □ Handling data drift

WEEK 9-10: CODING + PROJECTS
  □ Implement Linear Regression from scratch
  □ Implement Logistic Regression from scratch
  □ Implement a neural network from scratch
  □ Kaggle competition (aim for top 20%)
  □ Deploy a model as an API
  □ Be able to explain your projects in STAR format

TOP 20 MUST-KNOW INTERVIEW QUESTIONS:
  1. Explain the bias-variance tradeoff
  2. What is gradient descent? Types?
  3. How does backpropagation work?
  4. Compare Random Forest vs XGBoost
  5. What is regularization? L1 vs L2?
  6. How do you handle imbalanced data?
  7. Explain precision, recall, F1
  8. When would you use CNN vs RNN vs Transformer?
  9. What is attention mechanism?
  10. How do you prevent overfitting?
  11. Explain the Transformer architecture
  12. What is transfer learning?
  13. How would you design a recommendation system?
  14. What is batch normalization and why is it useful?
  15. Explain cross-validation
  16. What is data leakage?
  17. How do you handle missing values?
  18. What is feature importance and how do you compute it?
  19. Explain the end-to-end ML pipeline
  20. How do you monitor a model in production?
```

---

# FINAL MASTER CHEAT SHEET

```
┌─────────────────────────────────────────────────────────────────┐
│                    ML/DL MASTER CHEAT SHEET                     │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  WORKFLOW: Data → Clean → Features → Split → Train → Evaluate   │
│                                                                  │
│  TABULAR DATA: XGBoost > Random Forest > Logistic Regression    │
│  IMAGES: CNN (ResNet) > ViT > MLP                               │
│  TEXT: Transformer (BERT/GPT) > LSTM > Naive Bayes              │
│  TIME SERIES: Transformer > LSTM > 1D CNN > ARIMA               │
│  SMALL DATA: Linear/Logistic > KNN > Tree (avoid DL)            │
│                                                                  │
│  OVERFITTING: More data, regularization, dropout, early stop    │
│  UNDERFITTING: More complex model, more features, less reg.     │
│                                                                  │
│  IMBALANCED: F1/AUC (not accuracy), SMOTE, class weights       │
│  REGRESSION: RMSE if large errors bad, MAE if outliers present  │
│                                                                  │
│  GRADIENT DESCENT: w = w - lr × gradient                        │
│  BACKPROPAGATION: Chain rule from output to input               │
│  ATTENTION: score = softmax(QKᵀ/√d) × V                        │
│                                                                  │
│  ALWAYS: Start simple → Iterate → Feature engineer → Tune      │
│  NEVER: Skip EDA, test on training data, ignore business goal   │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

*This guide covers the complete ML/DL landscape from foundations to production. Revisit sections as needed — each re-read will deepen your understanding. Good luck with your interviews!*
